# 基于开源项目二次开发与AI编程全流程实践指南_V1.2

> 本指南不仅围绕如何基于开源项目高效完成品牌定制和二次开发，更强调利用 Cursor / Claude Code 等 AI 编程助手“全流程工作法”来辅助你的项目演进。通过合理分工、人机协作、工程 Skills 支持，实现需求对齐、PRD 明确、Issue 拆解、TDD（测试驱动开发）、架构治理等项目全链路流程自动化与智能加速，让二次开发事半功倍，并助力团队长期维护与快速升级。

> 面向对象：要用 Cursor / Claude Code 等 AI 编程助手，基于开源项目做**品牌定制**（改名称/Logo、闭源商用）并长期维护自己版本的开发者。  
> 本文提供一套可跟做闭环：克隆官方 → 推到私有仓库与 `custom/main` → 接入工程 Skills（需求对齐 / PRD / 拆 Issue / TDD / PR）→ 持续合并上游。

---

## 一、你需要提前准备什么


| 条件             | 是否必须 | 说明                                       |
| -------------- | ---- | ---------------------------------------- |
| 一个 AI 编程助手     | ✅ 必须 | Cursor、Claude Code、Codex 等               |
| GitHub账号       | ✅ 必须 | 托管代码、跟踪 Issue、走 PR 流程                    |
| GitHub CLI（gh） | ✅ 必须 | 在终端里(或Agent)调用 GitHub API 创建 PR、关联 Issue |
| Git            | ✅ 必须 | 本地代码版本控制                                 |
| 工程 Skills      | ✅ 必须 | 工程技能组合包                                  |




### 1.1 注册 GitHub 并准备 SSH

1. 打开 [https://github.com](https://github.com) 注册账号。
2. 进入 **Settings** → **SSH and GPG keys**。
3. 如果还没有 SSH 密钥，在终端执行：

```bash
ssh-keygen -t ed25519 -C "你的邮箱@example.com"
```

复制公钥：

macOS：

```bash
pbcopy < ~/.ssh/id_ed25519.pub
```

Linux（需要 `xclip`）：

```bash
xclip -sel clip < ~/.ssh/id_ed25519.pub
```

Windows Git Bash：

```bash
cat ~/.ssh/id_ed25519.pub | clip
```

回到 GitHub，点击 **New SSH key**，粘贴公钥并保存。

测试 SSH：

```bash
ssh -T git@github.com
```

成功后会看到类似 `Hi 你的用户名!`

### 1.2 安装 Git



#### macOS

```bash
git --version
xcode-select --install
git --version
```

看到类似 `git version 2.x.x` 即成功。

#### Windows

1. 打开 [https://gitforwindows.org](https://gitforwindows.org) 下载 Git for Windows。
2. 一路使用默认配置安装。
3. 打开 Git Bash 或命令提示符，输入：

```bash
git --version
```

看到类似 `git version 2.x.x.windows.x` 即成功。

#### Linux

Ubuntu/Debian：

```bash
sudo apt-get update
sudo apt-get install git
git --version
```

CentOS/Fedora：

```bash
sudo yum install git
git --version
```



### 1.3 安装 GitHub CLI (gh)



#### macOS

```bash
gh --version
# 如果未安装，执行下列命令进行安装
brew install gh

# 安装后进行身份认证（建议使用 SSH 方式）
gh auth login

# （如遇权限问题）授予当前用户配置目录的权限
sudo chown -R "$(whoami):staff" ~/.config/gh

# 检查认证状态
gh auth status
```



#### Windows

1. 访问 [https://github.com/cli/cli/releases](https://github.com/cli/cli/releases) 下载 Windows 安装包（`gh_*_windows_amd64.msi`）。
2. 双击运行安装，完成后在“命令提示符”或 PowerShell 执行：

```bash
gh --version
```

1. 初始化并认证 GitHub 账户（建议选择 SSH 方式）：

```bash
gh auth login
```

1. 检查认证状态：

```bash
gh auth status
```



#### Linux

（以 Ubuntu/Debian 为例）

```bash
# 安装最新 gh 版本
type -p curl >/dev/null || sudo apt install curl -y
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh -y

# 安装完成后认证（推荐 SSH）
gh auth login

# 检查认证状态
gh auth status
```

看到 `gh version x.x.x` 信息和认证通过即可。

### 1.4 确认 Skills 已就绪

跟做前，确认你的 AI 编程助手已启用本指南用到的工程 Skills。若尚未配置，按你所在环境（如 Cursor 根目录下创建 .cursor/skills）完成部署（将提供完整的 Skills 包拷贝至 .cursor/skills）。Skills 包清单如下：


| 序号  | 命令                              | 分类  | 一句话                                                         |
| --- | ------------------------------- | --- | ----------------------------------------------------------- |
| 1   | `/setup-skills`                 | 工程  | 每个仓跑一次，配置 Issue跟踪器、Triage标签词汇、领域文档和架构决策记录ADR、UI设计是否启用等初始化配置 |
| 2   | `grill-with-docs`               | 工程  | 拷问方案的同时维护领域术语表 `CONTEXT.md` / 架构决策记录ADR / UI 设计治理骨架         |
| 3   | `grill-me`                      | 效率  | 纯拷问，不写仓库文档                                                  |
| 4   | `to-prd`                        | 工程  | 把已对齐的需求整理成 PRD 并发布至 Issue                                   |
| 5   | `to-issues`                     | 工程  | 将 PRD 按照 tracer-bullet 进行垂直切片，拆分为完整的功能Issue 和 UI Issue      |
| 6   | `tdd`                           | 工程  | 红-绿-重构，测试驱动开发                                               |
| 7   | `diagnose`                      | 工程  | 有纪律的排错循环                                                    |
| 8   | `triage`                        | 工程  | Issue 状态机分拣                                                 |
| 9   | `improve-codebase-architecture` | 工程  | 找“加深模块”的架构重构机会                                              |
| 10  | `zoom-out`                      | 工程  | 拉高视角看陌生代码                                                   |


---



## 二、跟做：完整闭环演练

本指南以 [https://qwenpaw.agentscope.io/](https://qwenpaw.agentscope.io/)  开源项目作为示例，详细演示如何在已有开源项目基础上，结合本套 AI Coding 工作方法，完成品牌定制和二次开发，助你高效启动并持续演进自己的项目版本。

### 2.1 项目初始化



#### 2.1.1 新建项目

```bash
# 新建空目录
mkdir my-qwenpaw 
cd my-qwenpaw
# 用 Cursor 打开这个文件夹
cursor .
```



#### 2.1.2 克隆官方仓库到本地

```bash
# 进到项目根目录
cd my-qwenpaw
# 克隆项目到本地项目根目录
git clone https://github.com/agentscope-ai/QwenPaw.git .
```

**说明**：

- `git clone` = 把官方整份代码下载到本机

克隆完成后，在项目根目录应能看到 `README.md`、`LICENSE`、`pyproject.toml`、`src` 等（以官方当前结构为准）。

**检查当前远程**（此时通常只有一个叫 `origin` 的远程，指向官方）：

```bash
git remote -v
```

类似：

```text
origin  https://github.com/agentscope-ai/QwenPaw.git (fetch)
origin  https://github.com/agentscope-ai/QwenPaw.git (push)
```

接下来我们要把它改成：**upstream = 官方，origin = 你的私有库**。

#### 2.1.3 把现在的 origin 改名为 upstream

```bash
git remote rename origin upstream
git remote -v
```

**成功标志**：

```text
upstream  https://github.com/agentscope-ai/QwenPaw.git (fetch)
upstream  https://github.com/agentscope-ai/QwenPaw.git (push)
```

此时还没有 `origin`，这是正常的。

#### 2.1.4 在 GitHub 创建空私有仓库

1. 浏览器打开 [https://github.com/new](https://github.com/new)
2. 填写：
  - **Repository name**：`my-qwenpaw`（或你喜欢的名字，记住即可）  
  - **Description**：可选，如「QwenPaw 定制版」  
  - 选择 **Private**（私有，闭源商用必选）  
  - **不要**勾选 “Add a README file”  
  - **不要**勾选 “Add .gitignore”  
  - 要的是 **完全空仓库**
3. 点 **Create repository**。

创建后会看到一个页面，上面有仓库地址，二选一：

- SSH：`git@github.com:你的用户名/my-qwenpaw.git`  
- HTTPS：`https://github.com/你的用户名/my-qwenpaw.git`

**复制 SSH 地址**（推荐，已配置 SSH 的话）。

#### 2.1.5 添加你的私有仓库为 origin

把下面命令里的地址换成 **你刚复制的地址**：

```bash
# 仍在 ~/my-qwenpaw/my-qwenpaw 目录下
git remote add origin git@github.com:YOUR_USER/my-qwenpaw.git
git remote -v
```

**成功标志**（顺序无所谓）：

```text
origin    git@github.com:YOUR_USER/my-qwenpaw.git (fetch)
origin    git@github.com:YOUR_USER/my-qwenpaw.git (push)
upstream  https://github.com/agentscope-ai/QwenPaw.git (fetch)
upstream  https://github.com/agentscope-ai/QwenPaw.git (push)
```



#### 2.1.6 创建定制分支 custom/main

**为什么要新分支？**  
官方更新会进 `main`；你的修改放在 `custom/main`，合并时界限清晰，不容易乱。

```bash
# 查看当前在哪个分支
git branch

# 创建并切换到 custom/main
git checkout -b custom/main
```

**成功标志**：终端提示 `Switched to a new branch 'custom/main'`，`git branch` 里 `custom/main` 前面有 `*`。

#### 2.1.7 第一次推送到你的私有仓库

```bash
git push -u origin custom/main
```

**说明**：

- `push` = 把本地分支上传到 GitHub。  
- `-u` = 以后在这个分支上直接 `git push` 即可，不用每次写远程名。

**成功标志**：

- 终端无报错，最后一行类似 `Branch 'custom/main' set up to track remote branch 'custom/main' from 'origin'.`  
- 浏览器打开 `https://github.com/你的用户名/my-qwenpaw`，能看到代码，分支选 `custom/main`。

> **若提示权限错误**：检查 SSH（见 1.1）或改用 HTTPS 地址再 `git remote set-url origin https://...`。



#### 2.1.8 创建 CUSTOM.md（强烈建议）

用来记录「我改了什么」，以后合并官方时非常有用。

在仓库根目录（有 `pyproject.toml` 的那一层）新建文件 `CUSTOM.md`，内容可先照抄：

```markdown
# 相对官方的定制说明

## 品牌
- 产品名：（待填写）
- Logo 路径：（待填写）

## 我改过的文件
| 文件/目录 | 改了什么 | 日期 |
|-----------|----------|------|
| | | |

## 我故意删除的文件（商用等）
| 路径 | 原因 |
|------|------|
| | |

## 合并官方记录
| 日期 | 官方版本 | 有没有冲突 | 备注 |
|------|----------|------------|------|
| | | | |
```

保存后执行：

```bash
git add CUSTOM.md
git commit -m "docs: 添加定制记录文件 CUSTOM.md"
git push
```

**成功标志**：GitHub 上 `custom/main` 分支能看到 `CUSTOM.md`。

#### 2.1.9 初始化自检（做完打勾）

在 `my-qwenpaw` 目录执行：

```bash
git status
git branch
git remote -v
```


| 检查项             | 期望结果                                                  |
| --------------- | ----------------------------------------------------- |
| `git status`    | `nothing to commit, working tree clean`（或只有你知道的未提交文件） |
| `git branch`    | 当前在 `* custom/main`                                   |
| `git remote -v` | 同时有 `origin`（你的）和 `upstream`（官方）                      |
| GitHub 网页       | 私有库 `my-qwenpaw`，分支 `custom/main` 有代码                 |


**到这里初始化完成。** 后面所有开发都在 `custom/main` 上进行。

### 2.2 二次开发（接入工作法）



#### 2.2.1 项目初始配置 — `/setup-skills`

接下来进行项目设置，它会依次问你 Issue 跟踪器、Triage 标签、领域文档布局；多端 UI 项目还会多问一步 是否启用 UI 设计管控。

**自然语言（在 Cursor 里说）**：

```bash
/setup-skills
```


| 步骤  | 问什么           | 小白怎么选                                                         |
| --- | ------------- | ------------------------------------------------------------- |
| A   | Issue 跟踪器放哪？  | **跟做推荐 GitHub**（多端 Issue 多、迭代长，用 GitHub 跟踪 + PR 更可审查）         |
| B   | Triage 标签叫什么？ | 第一次用 → 接受默认；多端 UI 会多一个类别标签 `design-input`（UI Issue 专用）        |
| C   | 领域文档放哪？       | 单项目 → **Single-context**（根目录 `CONTEXT.md` + `docs/adr/`，三端共用） |
| D   | UI 设计治理？      | 做管理端或小程序 → **Enabled**；纯 API 项目可 Disabled                     |


完成后会在项目里生成：

```
你的项目/
├── AGENTS.md 或 CLAUDE.md    ← 增加 Agent 技能配置块，Cursor 中使用 AGENTS.md
└── docs/agents/
    ├── issue-tracker.md      ← Issue 跟踪方式
    ├── triage-labels.md      ← 标签词汇表
    ├── domain.md             ← 领域文档布局说明
    └── design-governance.md  ← 启用 UI 治理时生成
```

**每个仓库只需跑一次**。以后改配置，直接编辑 `docs/agents/*.md` 即可。**最后完成 GitHub 推送**，可以通过指令也可自然语言，推荐全程自然语言交互。

**自然语言（在 Cursor 里说）**：

```
提交并push
```



#### 2.2.2 查看当前代码结构 — `/zoom-out`

若对调用关系不熟，可先 `/zoom-out` 画系统图

**自然语言（在 Cursor 里说）：**

```
/zoom-out

对于当前这个项目，我想全面了解当前的技术架构和各个模块之间的关系。请画出整体架构示意及主要模块划分，不需要给出具体代码。
```



#### 2.2.3 开工前对齐 — `/grill-with-docs`

**自然语言（在 Cursor 里说）**：

```
/grill-with-docs

我想基于当前这份开源代码（QwenPaw）做二次开发，改成自己的品牌产品（闭源商用）。我的品牌名称是：一白。

v1 目标：
- 替换产品名、Logo、文案等品牌标识
- 按需裁剪不适合商用的能力（如部分 Skills）
- 尽量少改核心逻辑，优先改配置 / 文案 / 静态资源
- 所有定制记入 CUSTOM.md，方便以后合并上游

请一步步拷问我，把品牌范围、定制边界、保留/删除清单和术语都落地清楚。
```

**你会经历什么：**

1. 智能体**一次只问一个问题**
2. 逼你把模糊词变成术语
3. 每敲定一个术语，会**当场创建并写入** `CONTEXT.md`（空仓库里第一份领域文档）
4. 遇到难反悔的抉择会写 **ADR**，如：`docs/adr/0001-booking-state-pending-verified-only.md`
5. **若有 UI**，在领域术语稳定后还会问：品牌色方向、管理端 vs 小程序 UI 标准、组件库选型、哪些对外端页面需要参考图；并按需创建 `docs/design/`

**你要做的：**

- 认真回答每个问题；不确定就说“接受你的建议”
- `CONTEXT.md` 每更新一次就扫一眼——从零建项目时，这份文件就是你的“宪法”
- **仍然不要写代码**；没有术语表就开工，后面命名和测试会全线跑偏

**确认后，自然语言（在 Cursor 里说）**：

```
提交并push
```



#### 2.2.4 沉淀需求 — `/to-prd`

对齐后，**自然语言（在 Cursor 里说）：**

```
/to-prd

整理成 PRD
```

智能体会生成 PRD，并在 GitHub 上创建为 Issue。到 GitHub 仓库的 **Issues** 页核对 PRD Issue 是否已生成以及调整。也可直接自然对话询问进度。

**自然语言（在 Cursor 里说）**：

```
请帮我在 GitHub Issues 里确认 PRD Issue 是否已创建，并列出标题与编号。
```



#### 2.2.5 拆任务 — `/to-issues`

从零构建时，**强烈建议拆 Issue**，避免一次性让智能体“搭完整项目”。

**自然语言（在 Cursor 里说）**：

```
/to-issues

按垂直切片拆 v1 PRD
```

除 **功能垂直切片** 外，本用例存在Web端和小程序端，还需拆 **UI Issue**。

拆成“#1 设计全部表结构 → #2 实现全部 API → #3 做管理端 → #4 做小程序”——那是水平切片，和 `/tdd` 的节奏冲突。也**不要**“先设计全部页面再开发”。

拆完后在 GitHub **Issues** 页核对条数与验收标准。确认后会按依赖顺序在 GitHub 创建 issue。

**自然语言（在 Cursor 里说）**：

```
确认拆分合理，创建issue
```



#### 2.2.6 写代码 — 分支 + `/tdd` + PR

从 **Issue #2** 开始（Issue #1 一般为PRD文档），**每个 Issue 走一遍“拉分支 → TDD → push → CI → PR → 合并”**。后端优先，因为管理端和小程序都依赖 API 行为。

**步骤 1：为 Issue #2 建分支**

**自然语言（在 Cursor 里说）**：

```
从最新默认主干创建新分支，准备实现 Issue #[num]
```

**步骤 2：在当前对话或新对话里跑** `/tdd`

**自然语言（在 Cursor 里说）**：

```
/tdd

实现该 Issue
```

**步骤 3：接入 CI**

Issue #2 会产出测试脚本——**在同一条分支上**会新增 GitHub Actions workflow，让 push 后云端自动跑。

**自然语言（在 Cursor 里说）**：

```
【首次设置即可】创建CI，并设置任意分支 push 和 PR 时都（不）要跑 CI
```

**步骤 4：push 并等 CI 变绿**

**自然语言（在 Cursor 里说）**：

```
提交并 push
```

push 后会自动运行 CI 检测，打开 GitHub → **Actions**，确认 workflow **CI** 最近一次运行是 ✅。若失败，把 Actions 日志贴给 `/diagnose`。完成之后，还未将代码合并到 main，需要提交 PR。

**自然语言（在 Cursor 里说）**：

```
创建 PR
```

PR 后会自动运行 CI 检测，打开 GitHub → **Actions**，确认 workflow **CI** 最近一次运行是 ✅。若失败，把 Actions 日志贴给 `/diagnose`。也可以通过自然语言查看 CI 状态。

**自然语言（在 Cursor 里说）**：

```
请确认 CI 是否通过；失败则摘要原因并建议修复
```

PR 完成之后，将代码合并到 main。

**自然语言（在 Cursor 里说）**：

```
合并该 PR 到 main，不要删除该分支，并确认该 Issue 已关闭
```

PR 页 **Checks** 全绿后，再合并进 `main`。之后其他 Issue 重复：拉新分支 → `/tdd` → push → **等 CI** → PR → 合并。会话更干净，历史也可审查。

#### 2.2.7 出问题时 — `/diagnose`

从零写代码时，常见卡点举例：

**自然语言（在 Cursor 里说）**：

```
/diagnose

[描述你的具体问题]
```

它会带你走：复现 → 缩小范围 → 提假设 → 观测 → 验证 → 修 → 补回归测试。**不要让它一上来就猜着改。**

#### 2.2.8 v1 跑通后的维护 — `/improve-codebase-architecture`

可以在 v1 全部完成后或每隔 3–4 天就运行如下 Skill 进行代码维护：

```
/improve-codebase-architecture

看看有没有可以把模块“加深”、接口收窄的地方。
```

这一步在**新项目第一天**就可以做，不必等“变成泥球”——**从第一版就投资设计**，而不是先胡乱堆功能再还债。

---



## 三、上游有版本更新时：如何合并进当前仓库

二次开发不是「克隆一次就结束」。官方会修 bug、发安全补丁、加功能；你的私有库在 `custom/main` 上持续改品牌与业务。两边都会前进，必须**定期把上游变更合进你的定制分支**，否则差距越大，冲突越难解。

本节回答：官方仓库有新版本 / 新提交时，如何安全地合并到你当前仓库（`custom/main`）。

### 3.1 先搞清三条线（心智模型）


| 名称            | 指向              | 谁在改      | 你平时写代码在哪         |
| ------------- | --------------- | -------- | ---------------- |
| `upstream`    | 官方仓库（如 QwenPaw） | 上游维护者    | 只读拉取，不直接往这推业务定制  |
| `origin`      | 你的私有仓库          | 你 / 你的团队 | `git push` 的目标   |
| `custom/main` | 你的定制主干          | 你        | **日常开发与合并上游的落点** |


合并的本质是：

```text
官方 main（或 release 标签）的新提交
        ↓  git fetch + git merge（或 PR）
你的 custom/main（保留定制，吸收官方变更）
        ↓  git push
你的 origin（私有库跟上）
```

> **不要**在合并时直接改 `upstream` 远程地址，也不要在脏工作区上硬合。先保证本地干净、分支正确。



### 3.2 合并前自检（做完再动手）

在项目根目录执行：

```bash
git status
git branch
git remote -v
```


| 检查项  | 期望结果                                                            |
| ---- | --------------------------------------------------------------- |
| 工作区  | `nothing to commit, working tree clean`（有未提交改动先 commit 或 stash） |
| 当前分支 | `* custom/main`（或你约定的定制主干）                                      |
| 远程   | 同时有 `origin`（你的）和 `upstream`（官方）                                |
| 定制记录 | 根目录有 `CUSTOM.md`，且「我改过的文件」大致最新                                  |


**自然语言（在 Cursor 里说）**：

```
合并上游前做一次自检：确认当前在 custom/main、工作区干净、origin/upstream 远程齐全，并摘要 CUSTOM.md 里「我改过的文件」清单
```



### 3.3 拉取上游，先看「更新了什么」

```bash
# 1）拉取官方最新引用（不改你本地文件）
git fetch upstream

# 2）看官方默认主干相对你这边多了哪些提交（官方多为 main）
git log --oneline HEAD..upstream/main

# 3）看会碰到哪些文件（合并预览）
git diff --stat HEAD...upstream/main
```

若官方用标签发版，可先列出再对准某个版本：

```bash
git fetch upstream --tags
git tag -l --sort=-v:refname | head
# 示例：核对某标签相对当前的差异
git log --oneline HEAD..v1.2.0
```

**怎么读结果：**

- `git log` 为空 → 你这边已经包含官方这些提交，**本次无需合并**。
- 有提交、且 `git diff --stat` 里出现你在 `CUSTOM.md` 改过的路径 → **高风险冲突区**，合并时重点盯这些文件。

**自然语言（在 Cursor 里说）**：

```
先切到 custom/main。fetch upstream，对比 custom/main 与 upstream/main：列出新增提交摘要、变更文件统计，并标出与 CUSTOM.md「我改过的文件」重叠的路径
```



### 3.4 推荐流程：单独开「同步分支」再合进定制主干

不建议在 `custom/main` 上直接瞎试。更稳的做法与日常 Issue 开发一致：**拉同步分支 → 合并上游 → 解决冲突 → 自测 → PR → 合回** `custom/main`。

#### 3.4.1 从最新定制主干拉同步分支

```bash
git checkout custom/main
git pull origin custom/main
git checkout -b sync/upstream-YYYYMMDD
```

把 `YYYYMMDD` 换成当天日期，或改成官方版本号，如 `sync/upstream-v1.2.0`。

#### 3.4.2 合并官方主干（或指定标签）

```bash
# 跟做默认：合官方 main
git merge upstream/main
```

若要对齐某个发版标签：

```bash
git merge v1.2.0
```

**自然语言（在 Cursor 里说）**：

```
从最新 custom/main 创建分支 sync/upstream-YYYYMMDD，
把 upstream/main 合并进来；
有冲突先停下来：只列出冲突文件与冲突原因，不要擅自丢弃我们的品牌定制与 CUSTOM.md 记录
```



#### 3.4.3 出现冲突时怎么处理

冲突 = 同一文件两边都改过。原则：

1. **先停**，看清冲突文件列表，对照 `CUSTOM.md`。
2. **品牌 / 文案 / Logo / 你故意删除的商用裁剪** → 优先保留你的定制，再手工把官方必要的逻辑补回来。
3. **官方 bugfix / 安全补丁 / 与你无关的核心逻辑** → 优先吸收官方，再把你的定制叠回去。
4. **不要**为了「能合过去」直接选一边全部覆盖；合完后应用能跑、品牌还在。

查看冲突文件：

```bash
git status
# 或
git diff --name-only --diff-filter=U
```

解决每个文件后：

```bash
git add <已解决的文件>
# 全部解决后
git commit   # 若 merge 已自动生成提交信息，按提示完成即可
```

**自然语言（在 Cursor 里说）**：

```
/diagnose

合并 upstream/main 时出现冲突。请按 CUSTOM.md 区分「必须保留的定制」与「应吸收的官方修复」，
逐文件给出保留策略，改完后说明如何验证，不要 silently 丢掉定制
```

冲突面很大、一时理不清时：先把冲突文件清单记成 Issue，再逐个消化——**不要在半解决状态强行 push 当完成**。

### 3.5 合并后验收（比「能 commit」更重要）

按项目实际情况勾选（以 QwenPaw 类项目为例）：

1. **能安装 / 能启动**：按官方 README 或你项目文档把服务跑起来。
2. **品牌还在**：产品名、Logo、关键文案没有被官方默认值盖掉。
3. **定制能力仍在**：你在 `CUSTOM.md` 里记过的关键改动抽查一遍。
4. **测试 / CI**：本地测一遍；有 CI 则 push 后等 Actions 变绿。
5. **记一笔账**：更新 `CUSTOM.md` 的「合并官方记录」。

`CUSTOM.md` 示例追加一行：

```markdown
## 合并官方记录
| 日期 | 官方版本 | 有没有冲突 | 备注 |
|------|----------|------------|------|
| 2026-07-25 | upstream/main@abc1234 | 有：改了 README 品牌名 | 保留我方品牌，吸收官方依赖升级 |
```

```bash
git add CUSTOM.md
git commit -m "docs: 记录合并 upstream（YYYYMMDD）"
```



### 3.6 合回定制主干并推送到私有库

同步分支验收通过后，走 PR（推荐）或快进合并：

**方式 A：PR（推荐，可审查、可走 CI）**

**自然语言（在 Cursor 里说）**：

```
提交并 push 当前同步分支，创建 PR 合并进 custom/main；
PR 说明写清：上游范围、冲突文件与取舍、本地/CI 验收结果
```

CI 全绿、人工确认品牌与关键路径无误后：

```
合并该 PR 到 custom/main，不要删除该分支（或按团队习惯删除），并确认无残留冲突
```

**方式 B：本地直接合回（个人仓、改动很小时）**

```bash
git checkout custom/main
git merge sync/upstream-YYYYMMDD
git push origin custom/main
```



### 3.7 建议节奏与禁忌


| 建议      | 说明                                         |
| ------- | ------------------------------------------ |
| 定期合     | 官方活跃时每周或每发版合一次；拖越久，冲突越指数级变难                |
| 小步合     | 一次对齐一个上游区间（一段提交或一个 tag），不要攒半年再合            |
| 先记后合    | `CUSTOM.md` 越完整，冲突决策越快                     |
| 同步与业务分开 | 正在开发的 Issue 分支先合完或搁置；避免「业务半成品 + 上游大合并」搅在一起 |


**禁忌：**

- 在未 `fetch` 的情况下凭感觉改版本号「算同步完了」。  
- 冲突时一律 `git checkout --theirs/--ours` 整文件覆盖，却不看内容。  
- 合并后不启动、不看品牌、不更新 `CUSTOM.md`。  
- 把只属于你私有仓的提交 `push` 到 `upstream`（你通常没有写权限，也不该推）。



### 3.8 一页纸命令清单（可收藏）

```bash
# 自检
git status && git branch && git remote -v

# 拉上游并预览
git fetch upstream
git log --oneline HEAD..upstream/main
git diff --stat HEAD...upstream/main

# 同步分支上合并
git checkout custom/main && git pull origin custom/main
git checkout -b sync/upstream-YYYYMMDD
git merge upstream/main
# …解决冲突、自测、更新 CUSTOM.md…

# 推送并由 PR 合回 custom/main（或本地 merge 后）
git push -u origin HEAD
```

**到这里**：官方新版本已进入你的 `custom/main`，定制仍在，私有库与上游重新对齐。之后继续按第二节的 Issue → `/tdd` → PR 节奏做二次开发即可。