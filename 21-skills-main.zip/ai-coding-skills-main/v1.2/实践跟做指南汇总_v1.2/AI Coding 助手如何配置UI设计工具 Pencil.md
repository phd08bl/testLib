# AI Coding 助手如何配置UI设计工具  Pencil

> 按 [Pencil 官方文档](https://docs.pencil.dev/) 整理，重点参考 [Installation](https://docs.pencil.dev/getting-started/installation)、[AI Integration](https://docs.pencil.dev/getting-started/ai-integration)。  
> 适用场景：通过 MCP 让 AI 助手读写本地 `.pen` 设计文件，实现 Design ↔ Code 双向工作流。

---

## 一、MCP 如何工作

Pencil MCP **在本机自动运行**，链路如下：

```
AI 助手（MCP 客户端）→ Pencil MCP Server（本地）→ 当前打开的 .pen 文件
```

Pencil 启动后会自动注册 MCP，通常无需手动编写配置文件。AI 通过 MCP 工具读取、修改、生成设计；`.pen` 文件保存在本地，MCP 设计操作不依赖云端。

---

## 二、开始使用

### 步骤 1：安装 Pencil（IDE 扩展）

1. 在 IDE 中打开扩展市场（`Cmd/Ctrl + Shift + X`）
2. 搜索 **Pencil**
3. 点击 **Install**
4. 确认扩展已 **Enable**

**验证是否安装成功：**

1. 新建文件 `design.pen`
2. 用 Pencil 打开该文件
3. 画布正常加载；编辑器右上角应出现 **Pencil 图标**

若看不到图标或画布未加载：

- 在命令面板（`Cmd/Ctrl + Shift + P`）中搜索 **Pencil** 查看可用命令
- 确认扩展已启用
- 重启 IDE 后重试

首次启动 Pencil 会要求 **邮箱激活**：输入邮箱 → 查收激活码 → 在 Pencil 中完成激活。

详细说明见 [Installation](https://docs.pencil.dev/getting-started/installation)。

---



### 步骤 2：验证 MCP 连接

在 AI 助手的 **MCP 设置** 中，确认列表出现 **Pencil**，且状态为 **已连接**。

**若未出现或状态异常：**

1. 在 Pencil 中打开任意 `.pen` 文件
2. 保存文件 → 重启 IDE
3. 再次检查 MCP 设置

---



### 步骤 3：确认目标 .pen 文件已打开

AI 通过 MCP 读写的是 **当前在 Pencil 中打开的** `.pen` **文件**。

推荐把 `.pen` 放在项目目录内：

```
your-project/
├── design.pen          ← 设计文件
└── ...
```

**使用规则：**

- `.pen` 为结构化设计文件，应通过 Pencil 或 MCP 工具操作，**不要手改源码**
- 同一时刻 AI 上下文以 **当前打开的设计文件 + 编辑器选中状态** 为准
- 改完记得 **手动保存**（`Cmd/Ctrl + S`）—— 当前版本尚无自动保存

---



## 三、Pencil MCP 可用工具一览

MCP 连接成功后，可在 AI 助手的 MCP 设置中查看完整工具列表。常用工具包括：


| 工具                             | 用途                             |
| ------------------------------ | ------------------------------ |
| `get_editor_state`             | 获取当前编辑器上下文、选中元素、活动文件           |
| `batch_get`                    | 读取设计组件层级、按模式搜索节点               |
| `batch_design`                 | 创建/修改/删除元素，设置 Variables，批量设计操作 |
| `get_screenshot`               | 渲染设计预览，用于视觉验证                  |
| `snapshot_layout`              | 分析布局结构、检测重叠与定位问题               |
| `get_variables`                | 读取 Design Tokens / 主题变量        |
| `export_html` / `export_nodes` | 导出设计为 HTML 或节点数据               |


> 写入 Variables 通常通过 `batch_design` 内的 `SetVariables` 操作完成。

---



## 四、日常使用流程（每次开工 checklist）

```
□ Pencil 扩展已安装并启用
□ 已打开目标 .pen 文件，画布可见
□ MCP 设置中 Pencil 为已连接状态
□ 重要改动前已 Cmd/Ctrl + S 保存
□ 在 AI 助手中发 Prompt
```

---



## 五、常见问题排查


| 现象                       | 可能原因                    | 处理办法                        |
| ------------------------ | ----------------------- | --------------------------- |
| 无 Pencil 图标 / 打不开 `.pen` | 扩展未安装或未启用               | 检查扩展市场；确认 Enable；重启 IDE     |
| MCP 列表中无 Pencil          | 未打开 `.pen` 或 Pencil 未启动 | 打开 `.pen` 文件；重启 IDE         |
| AI 说看不到设计                | 未打开 `.pen` 或打开了错误文件     | 在 Pencil 中打开目标 `design.pen` |
| AI 改了设计但画布没更新            | 未保存或文件未刷新               | 保存文件；重新打开 `.pen`            |
| 工具调用失败                   | MCP 未重连                 | 重启 IDE；检查 MCP 设置            |
| 误改设计无法恢复                 | 无自动保存 / Undo 有限         | 从备份恢复；大改前先保存副本              |


**通用修复顺序：**

1. 确认 Pencil 扩展已启用
2. 关闭并重新打开 `.pen` 文件
3. 重启 IDE
4. 再次检查 MCP 连接状态

---



## 六、安全与权限提醒

- **本地 MCP**：设计读写在本机完成，MCP 设计操作不依赖远程服务
- **写权限**：AI 连接后可通过 MCP **增删改** `.pen` 内图层与样式；重要文件建议先备份再操作
- **权限弹窗**：若 Pencil 提示文件夹访问权限，请在系统中 **允许**，否则 AI 无法读写设计文件

