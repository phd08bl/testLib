# 基于若依前后端分离版二次开发与AI编程全流程实践指南_V1.2

> 本指南以 [若依 RuoYi-Vue](https://doc.ruoyi.vip/ruoyi-vue/)（前后端分离版）为载体，演示如何用 Cursor / Claude Code 等 AI 编程助手，完成品牌定制与业务二次开发。工作法与工程 Skills 与通用二次开发指南一致：需求对齐 → PRD → 拆 Issue → TDD → PR → 持续合并上游，让你在「改品牌、加业务、长期维护」时有清晰闭环。

> 面向对象：要用 AI 编程助手，基于 **RuoYi-Vue**（同仓后端 + Vue2 `ruoyi-ui`）做**品牌定制**（改名称/Logo、闭源商用）并长期维护自己版本的开发者。  
> 可跟做闭环：克隆官方 GitHub → 推到私有仓库与 `custom/main` → 本地跑通前后端 → 接入工程 Skills → 持续合并上游。

> 官方文档：[https://doc.ruoyi.vip/ruoyi-vue/](https://doc.ruoyi.vip/ruoyi-vue/)  
> 官方仓库（GitHub）：[https://github.com/yangzongzhuan/RuoYi-Vue](https://github.com/yangzongzhuan/RuoYi-Vue)  
> 在线演示：[http://vue.ruoyi.vip](http://vue.ruoyi.vip)

---



## 〇、先认清若依前后端分离版

**RuoYi-Vue** 是一个 Java EE 企业级快速开发平台，经典技术组合为 Spring Boot + Spring Security + MyBatis + Jwt + Vue，内置部门/角色/用户、菜单按钮授权、数据权限、参数/日志/通知、代码生成、定时任务等。

跟做组合：**官方 GitHub 单仓 RuoYi-Vue**，分支 `master`（Spring Boot 4.x / JDK 17+）**，前端用仓内附带的** `ruoyi-ui`**（Vue 2 + Element UI）**。

### 版本怎么选（跟做建议）


| 维度   | 选项                                                                                                | 跟做推荐                                                           |
| ---- | ------------------------------------------------------------------------------------------------- | -------------------------------------------------------------- |
| 后端分支 | `master`（Spring Boot 4.x / JDK 17+）、`springboot3`、`springboot2`                                   | `**master`（Spring Boot 4.x / JDK 17+）**                        |
| 前端   | 同仓 `ruoyi-ui`（Vue 2 + Element UI）；独立仓 [RuoYi-Vue3](https://github.com/yangzongzhuan/RuoYi-Vue3) 等 | **同仓** `ruoyi-ui`**（Vue 2）**                                   |
| 托管   | 官方 GitHub / 其他镜像站                                                                                 | **一律用官方 GitHub**；`upstream = 官方 GitHub`，`origin = 你的私有 GitHub` |


> 官方也提供 Vue3 独立前端，本指南跟做**不切换**；若以后要换 Vue3，再单独评估并更新 `CUSTOM.md`。



### 仓库大致长什么样

```text
RuoYi-Vue/                         # Cursor 打开这一层（克隆后的项目根）
├── ruoyi-admin/                   # 启动入口、Controller
├── ruoyi-framework/               # Security、拦截器、配置
├── ruoyi-system/                  # 系统业务（用户/角色/菜单等）
├── ruoyi-common/                  # 工具与通用能力
├── ruoyi-quartz/                  # 定时任务（可裁剪）
├── ruoyi-generator/               # 代码生成（可裁剪）
├── ruoyi-ui/                      # 前端 Vue 2（跟做用这个）
├── sql/                           # 初始化 SQL
└── pom.xml
```

品牌相关常见落点（记入 `CUSTOM.md`）：


| 位置                                      | 通常改什么                      |
| --------------------------------------- | -------------------------- |
| `ruoyi-admin/.../application.yml`       | `ruoyi.name`、版权年、上传路径、验证码等 |
| `ruoyi-admin/.../application-druid.yml` | 数据库账号密码（勿提交真实生产密钥）         |
| `ruoyi-ui/src/settings.js`、`.env.*`     | 侧边栏标题、页面 Title             |
| `ruoyi-ui/public/`、`src/assets/`        | Logo、favicon               |
| 登录页 / 布局组件                              | 文案、版权、品牌色（配合 UI 治理）        |


---



## 一、你需要提前准备什么


| 条件             | 是否必须   | 说明                                                           |
| -------------- | ------ | ------------------------------------------------------------ |
| 一个 AI 编程助手     | ✅ 必须   | Cursor、Claude Code、Codex 等                                   |
| GitHub 账号      | ✅ 必须   | 拉官方代码 + 托管你的私有仓、Issue、PR                                     |
| GitHub CLI（gh） | ✅ 必须   | 终端或 Agent 创建 PR、关联 Issue                                     |
| Git            | ✅ 必须   | 本地版本控制；上游在官方 GitHub                                          |
| 工程 Skills      | ✅ 必须   | 本仓库 `v1.2/skills` 工程技能包                                      |
| JDK            | ✅ 必须   | **JDK 17+**（master / Spring Boot 4.x）；推荐用 SDKMAN 按项目切换，见 1.4 |
| Maven          | ✅ 必须   | >= 3.0；推荐随 SDKMAN 安装                                         |
| MySQL          | ✅ 必须   | >= 5.7；**推荐 Docker 起容器**，不必本机装服务                             |
| Redis          | ✅ 必须   | >= 3；**推荐 Docker 起容器**，不必本机装服务                               |
| Node.js        | ✅ 必须   | >= 12（建议 LTS）；推荐用 nvm + `.nvmrc`，见 1.4                       |
| Docker         | ⭐ 强烈推荐 | 用来隔离 MySQL/Redis，避免弄乱本机环境                                    |




### 1.1 注册 GitHub 并准备 SSH

1. 打开 [https://github.com](https://github.com) 注册账号。
2. 进入 **Settings** → **SSH and GPG keys**。
3. 如果还没有 SSH 密钥，在终端执行：

```bash
ssh-keygen -t ed25519 -C "你的邮箱@example.com"
```

复制公钥：

macOS：

```bash
pbcopy < ~/.ssh/id_ed25519.pub
```

Linux（需要 `xclip`）：

```bash
xclip -sel clip < ~/.ssh/id_ed25519.pub
```

Windows Git Bash：

```bash
cat ~/.ssh/id_ed25519.pub | clip
```

回到 GitHub，点击 **New SSH key**，粘贴公钥并保存。

测试 SSH：

```bash
ssh -T git@github.com
```

成功后会看到类似 `Hi 你的用户名!`

### 1.2 安装 Git



#### macOS

```bash
git --version
xcode-select --install
git --version
```

看到类似 `git version 2.x.x` 即成功。

#### Windows

1. 打开 [https://gitforwindows.org](https://gitforwindows.org) 下载 Git for Windows。
2. 一路使用默认配置安装。
3. 打开 Git Bash 或命令提示符，输入：

```bash
git --version
```

看到类似 `git version 2.x.x.windows.x` 即成功。

#### Linux

Ubuntu/Debian：

```bash
sudo apt-get update
sudo apt-get install git
git --version
```

CentOS/Fedora：

```bash
sudo yum install git
git --version
```



### 1.3 安装 GitHub CLI (gh)



#### macOS

```bash
gh --version
# 如果未安装，执行下列命令进行安装
brew install gh

# 安装后进行身份认证（建议使用 SSH 方式）
gh auth login

# （如遇权限问题）授予当前用户配置目录的权限
sudo chown -R "$(whoami):staff" ~/.config/gh

# 检查认证状态
gh auth status
```



#### Windows

1. 访问 [https://github.com/cli/cli/releases](https://github.com/cli/cli/releases) 下载 Windows 安装包（`gh_*_windows_amd64.msi`）。
2. 双击运行安装，完成后在“命令提示符”或 PowerShell 执行：

```bash
gh --version
```

1. 初始化并认证 GitHub 账户（建议选择 SSH 方式）：

```bash
gh auth login
```

1. 检查认证状态：

```bash
gh auth status
```



#### Linux

（以 Ubuntu/Debian 为例）

```bash
# 安装最新 gh 版本
type -p curl >/dev/null || sudo apt install curl -y
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh -y

# 安装完成后认证（推荐 SSH）
gh auth login

# 检查认证状态
gh auth status
```

看到 `gh version x.x.x` 信息和认证通过即可。

### 1.4 确认 Skills 已就绪

跟做前，确认你的 AI 编程助手已启用本指南用到的工程 Skills。Skills 包清单如下：


| 序号  | 命令                              | 分类  | 一句话                                               |
| --- | ------------------------------- | --- | ------------------------------------------------- |
| 1   | `/setup-skills`                 | 工程  | 每个仓跑一次，配置 Issue 跟踪器、Triage 标签、领域文档和 ADR、UI 设计是否启用 |
| 2   | `grill-with-docs`               | 工程  | 拷问方案的同时维护 `CONTEXT.md` / ADR / UI 设计治理骨架          |
| 3   | `grill-me`                      | 效率  | 纯拷问，不写仓库文档                                        |
| 4   | `to-prd`                        | 工程  | 把已对齐的需求整理成 PRD 并发布至 Issue                         |
| 5   | `to-issues`                     | 工程  | 按 tracer-bullet 垂直切片，拆功能 Issue 与 UI Issue         |
| 6   | `tdd`                           | 工程  | 红-绿-重构，测试驱动开发                                     |
| 7   | `diagnose`                      | 工程  | 有纪律的排错循环                                          |
| 8   | `triage`                        | 工程  | Issue 状态机分拣                                       |
| 9   | `improve-codebase-architecture` | 工程  | 找「加深模块」的架构重构机会                                    |
| 10  | `zoom-out`                      | 工程  | 拉高视角看陌生代码                                         |


---



## 二、跟做：完整闭环演练

本指南以官方 GitHub 上的 **RuoYi-Vue（**`master` **+ 同仓** `ruoyi-ui`**）** 为示例，演示如何完成品牌定制与业务二次开发。

### 2.1 项目初始化



#### 2.1.1 新建项目目录

```bash
# 新建空目录
mkdir my-ruoyi-vue
cd my-ruoyi-vue
# 用 Cursor 打开这个文件夹
cursor .
```



#### 2.1.2 克隆官方仓库到本地

```bash
# 进到项目根目录
cd my-ruoyi-vue

# 官方 GitHub · 默认 master = Spring Boot 4.x（JDK 17+），含 ruoyi-ui（Vue 2）
git clone https://github.com/yangzongzhuan/RuoYi-Vue.git .

# 确认在 master（跟做不要切到 springboot3 / springboot2）
git branch
```

**说明**：

- `git clone` = 把官方整份代码下载到本机  
- 跟做**留在** `master`

克隆完成后，在项目根目录应能看到 `pom.xml`、`ruoyi-admin`、`ruoyi-ui`、`sql` 等（以官方当前结构为准）。更多模块说明见官方：[项目介绍](https://doc.ruoyi.vip/ruoyi-vue/document/xmjs.html)。

**检查当前远程**（此时通常只有一个叫 `origin` 的远程，指向官方 GitHub）：

```bash
git remote -v
```

类似：

```text
origin  https://github.com/yangzongzhuan/RuoYi-Vue.git (fetch)
origin  https://github.com/yangzongzhuan/RuoYi-Vue.git (push)
```

接下来我们要把它改成：**upstream = 官方 GitHub，origin = 你的私有库**。

#### 2.1.3 把现在的 origin 改名为 upstream

```bash
git remote rename origin upstream
git remote -v
```

**成功标志**：

```text
upstream  https://github.com/yangzongzhuan/RuoYi-Vue.git (fetch)
upstream  https://github.com/yangzongzhuan/RuoYi-Vue.git (push)
```

此时还没有 `origin`，这是正常的。

#### 2.1.4 在 GitHub 创建空私有仓库

1. 浏览器打开 [https://github.com/new](https://github.com/new)
2. 填写：
  - **Repository name**：`my-ruoyi-vue`（或你喜欢的名字，记住即可）  
  - **Description**：可选，如「RuoYi-Vue 定制版」  
  - 选择 **Private**（私有，闭源商用必选）  
  - **不要**勾选 “Add a README file”  
  - **不要**勾选 “Add .gitignore”  
  - 要的是 **完全空仓库**
3. 点 **Create repository**。

创建后会看到仓库地址，二选一：

- SSH：`git@github.com:你的用户名/my-ruoyi-vue.git`  
- HTTPS：`https://github.com/你的用户名/my-ruoyi-vue.git`

**复制 SSH 地址**（推荐，已配置 SSH 的话）。

#### 2.1.5 添加你的私有仓库为 origin

把下面命令里的地址换成 **你刚复制的地址**：

```bash
git remote add origin git@github.com:YOUR_USER/my-ruoyi-vue.git
git remote -v
```

**成功标志**（顺序无所谓）：

```text
origin    git@github.com:YOUR_USER/my-ruoyi-vue.git (fetch)
origin    git@github.com:YOUR_USER/my-ruoyi-vue.git (push)
upstream  https://github.com/yangzongzhuan/RuoYi-Vue.git (fetch)
upstream  https://github.com/yangzongzhuan/RuoYi-Vue.git (push)
```



#### 2.1.6 创建定制分支 custom/main

**为什么要新分支？**  
官方更新会进 `master`；你的修改放在 `custom/main`，合并时界限清晰，不容易乱。

```bash
# 查看当前在哪个分支（跟做应在 master）
git branch

# 创建并切换到 custom/main
git checkout -b custom/main
```

**成功标志**：终端提示 `Switched to a new branch 'custom/main'`，`git branch` 里 `custom/main` 前面有 `*`。

#### 2.1.7 第一次推送到你的私有仓库

```bash
git push -u origin custom/main
```

**说明**：

- `push` = 把本地分支上传到 GitHub。  
- `-u` = 以后在这个分支上直接 `git push` 即可，不用每次写远程名。

**成功标志**：

- 终端无报错，最后一行类似 `Branch 'custom/main' set up to track remote branch 'custom/main' from 'origin'.`  
- 浏览器打开 `https://github.com/你的用户名/my-ruoyi-vue`，能看到代码，分支选 `custom/main`。

> **若提示权限错误**：检查 SSH（见 1.1）或改用 HTTPS 地址再 `git remote set-url origin https://...`。



#### 2.1.8 本地跑通一次（强烈建议，再谈定制）

官方要求：**前后端都要单独启动**才能完整访问。对于基础环境的配置请参考第3章节（抽为独立章节介绍），配置完成后再继续往下操作。

**0）激活本项目隔离环境（每个新终端做一次）**

```bash
# 在项目根目录
sdk env   # 读取.sdkmanrc
nvm use   # 读取 .nvmrc
docker compose -f docker-compose.dev.yml up -d
```

**1）准备数据库**

1. 若用 1.4 的 Compose，库名已由 `MYSQL_DATABASE` 建好（常见 `ry-vue`）；否则自行建库。
2. 导入 `sql/` 目录下的业务脚本与 `quartz` 脚本（文件名带日期，以当前仓库为准），例如：

```bash
docker exec -i my-ruoyi-mysql mysql -uroot -proot ry-vue < sql/你的业务脚本.sql
docker exec -i my-ruoyi-mysql mysql -uroot -proot ry-vue < sql/quartz.sql
```

**2）改后端配置（仅本地，勿把真实密码推到公开仓库）**

- 编辑 `ruoyi-admin/src/main/resources/application-druid.yml`：数据库 URL / 用户名 / 密码（对接 Compose 时一般为 `localhost:3306`、`root` / `root`）  
- 确认 `application.yml` 中 Redis（`localhost:6379`）、`ruoyi.profile`（上传目录）在本机可写

**3）启动后端**

**命令行启动（推荐跟做，不依赖 IDE）**

在**项目根**（有根 `pom.xml` 的那一层）执行：

```bash
# 编译整个多模块工程（首次或改过依赖后建议完整装一遍）
mvn clean install -DskipTests

# 进入启动模块并运行
cd ruoyi-admin
mvn spring-boot:run
```

**成功标志**

- 控制台出现类似「若依启动成功」/ `Started RuoYiApplication` 的日志，无持续报错刷屏。  
- 浏览器或 curl 访问 `http://localhost:8080` 有响应（接口侧通即可；完整页面要等前端起来）。  
- 常见失败：连不上 MySQL/Redis（检查 Compose 是否 `up`、端口是否按 1.4 改过）、JDK 版本不对、`ruoyi.profile` 目录不可写。

> 端口默认 **8080**；若被占用，改 `ruoyi-admin/src/main/resources/application.yml` 里的 `server.port`，并同步前端代理目标。

**4）启动前端（同仓** `ruoyi-ui`**）**

```bash
cd ruoyi-ui
nvm use
npm install
npm run dev
```

浏览器打开前端地址（开发环境常见为 `http://localhost:80`，以当前 `vue.config.js` / 终端输出为准），默认账号密码见官方文档（一般为 `admin` / `admin123`）。登录后菜单正常，即环境成功。

> 卡住时优先查官方 [环境部署](https://doc.ruoyi.vip/ruoyi-vue/document/hjbs.html) 与「常见问题」：Mac 的 `profile` 路径、Linux MySQL 大小写、目录写权限、前端代理前缀（`/dev-api`）、端口被占用（见 1.4 改映射）等。



#### 2.1.9 创建 CUSTOM.md（强烈建议）

用来记录「我改了什么」，以后合并官方时非常有用。

在仓库根目录（有根 `pom.xml` 的那一层）新建文件 `CUSTOM.md`，内容可先照抄：

```markdown
# 相对官方的定制说明

## 基线
- 上游仓库：https://github.com/yangzongzhuan/RuoYi-Vue
- 跟做基线分支：master（Spring Boot 4.x / JDK 17+）
- 前端：同仓 ruoyi-ui（Vue 2）
- 本地隔离：SDKMAN + nvm + docker-compose.dev.yml（MySQL/Redis）

## 品牌
- 产品名：（待填写）
- Logo / favicon 路径：（待填写）
- 系统标题落点：settings.js / .env / application.yml

## 我改过的文件
| 文件/目录 | 改了什么 | 日期 |
|-----------|----------|------|
| | | |

## 我故意删除/裁剪的模块（商用等）
| 路径/模块 | 原因 |
|-----------|------|
| 例：ruoyi-generator | （待填写） |
| 例：ruoyi-quartz | （待填写） |

## 合并官方记录
| 日期 | 官方提交/标签 | 有没有冲突 | 备注 |
|------|---------------|------------|------|
| | | | |
```

保存后执行：

```bash
git add CUSTOM.md
git commit -m "docs: 添加定制记录文件 CUSTOM.md"
git push
```

**成功标志**：GitHub 上 `custom/main` 分支能看到 `CUSTOM.md`。

#### 2.1.10 初始化自检（做完打勾）

在 `my-ruoyi-vue` 目录执行：

```bash
git status
git branch
git remote -v
```


| 检查项             | 期望结果                                                  |
| --------------- | ----------------------------------------------------- |
| `git status`    | `nothing to commit, working tree clean`（或只有你知道的未提交文件） |
| `git branch`    | 当前在 `* custom/main`                                   |
| `git remote -v` | 同时有 `origin`（你的私有 GitHub）和 `upstream`（官方 GitHub）      |
| GitHub 网页       | 私有库 `my-ruoyi-vue`，分支 `custom/main` 有代码               |
| 本地联调            | 后端启动成功 + `**ruoyi-ui**` 可登录                           |


**到这里初始化完成。** 后面所有开发都在 `custom/main` 上进行（或从其上拉 `issue/`* 分支）。

### 2.2 二次开发（接入工作法）



#### 2.2.1 项目初始配置 — `/setup-skills`

接下来进行项目设置，它会依次问你 Issue 跟踪器、Triage 标签、领域文档布局；有管理端 UI 时还会问是否启用 UI 设计管控。

**自然语言（在 Cursor 里说）**：

```bash
/setup-skills
```


| 步骤  | 问什么           | 小白怎么选                                                      |
| --- | ------------- | ---------------------------------------------------------- |
| A   | Issue 跟踪器放哪？  | **跟做推荐 GitHub**（Issue + PR 可审查）                            |
| B   | Triage 标签叫什么？ | 第一次用 → 接受默认；管理端 UI 会用到 `design-input`                      |
| C   | 领域文档放哪？       | 单仓前后端 → **Single-context**（根目录 `CONTEXT.md` + `docs/adr/`） |
| D   | UI 设计治理？      | 管理后台有界面 → **Enabled**                                      |


完成后会在项目里生成：

```
你的项目/
├── AGENTS.md 或 CLAUDE.md    ← Agent 技能配置块（Cursor 用 AGENTS.md）
└── docs/agents/
    ├── issue-tracker.md
    ├── triage-labels.md
    ├── domain.md
    └── design-governance.md  ← 启用 UI 治理时生成
```

**每个仓库只需跑一次**。以后改配置，直接编辑 `docs/agents/*.md` 即可。**最后完成 GitHub 推送**，推荐全程自然语言：

```
提交并push
```



#### 2.2.2 查看当前代码结构 — `/zoom-out`

若依模块多，建议先建立「后端模块 + 前端目录」心智模型。

**自然语言（在 Cursor 里说）：**

```
/zoom-out

这是 RuoYi-Vue 前后端分离单仓项目（master / Spring Boot 4.x + 同仓 ruoyi-ui Vue2）。请画出：
1）后端 Maven 多模块职责（admin / framework / system / common / quartz / generator）
2）前端 ruoyi-ui 主要目录（api / views / store / permission 等）
3）一次「登录 → 拉菜单 → 调业务 API」的调用链
不要贴大段源码，重点是模块边界与依赖方向。
```



#### 2.2.3 开工前对齐 — `/grill-with-docs`

**自然语言（在 Cursor 里说）**：

```
/grill-with-docs

我想基于官方 GitHub 开源代码（RuoYi-Vue master，同仓 ruoyi-ui Vue2）做二次开发，改成自己的品牌后台产品（闭源商用）。我的品牌名称是：一白。

v1 目标：
- 替换产品名、Logo、favicon、登录页与侧栏标题等品牌标识
- 关闭或不暴露不适合商用的演示能力（如 demo 开关、多余示例菜单）
- 明确保留/裁剪模块：代码生成、定时任务、系统监控等
- 尽量少改框架核心，优先改配置、文案、静态资源与业务扩展模块
- 所有定制记入 CUSTOM.md，方便以后合并 upstream（官方 GitHub）

请一步步拷问我，把品牌范围、定制边界、模块保留清单和术语都落地清楚。
```

**你会经历什么：**

1. 智能体**一次只问一个问题**
2. 逼你把模糊词变成术语（如「租户」「组织」「菜单权限」在你业务里的含义）
3. 每敲定一个术语，会**当场写入** `CONTEXT.md`
4. 遇到难反悔的抉择会写 **ADR**（例如：是否改 `com.ruoyi` 包名、是否拆独立业务模块 `ruoyi-xxx`）
5. **管理端 UI**：在术语稳定后还会问品牌色、是否继续 Element UI 体系、哪些页面需要参考图；并按需创建 `docs/design/`

**你要做的：**

- 认真回答每个问题；不确定就说「接受你的建议」
- `CONTEXT.md` 每更新一次就扫一眼
- **仍然不要写代码**；没有术语表就开工，后面命名和测试会全线跑偏

**确认后：**

```
提交并push
```



#### 2.2.4 沉淀需求 — `/to-prd`

对齐后，**自然语言（在 Cursor 里说）：**

```
/to-prd

整理成 PRD
```

智能体会生成 PRD，并在 GitHub 上创建为 Issue。到仓库 **Issues** 页核对；也可直接问：

```
请帮我在 GitHub Issues 里确认 PRD Issue 是否已创建，并列出标题与编号。
```



#### 2.2.5 拆任务 — `/to-issues`

二次开发**强烈建议拆 Issue**，避免一次让智能体「整仓换皮 + 加业务」。

**自然语言（在 Cursor 里说）**：

```
/to-issues

按垂直切片拆 v1 PRD
```

除功能垂直切片外，管理端还需拆 **UI / Design Issue**。

反例：把「#1 改完全部后端配置 → #2 改完全部前端皮肤 → #3 再加业务」拆成水平层——会和 `/tdd` 节奏冲突。  
正例：每一刀都能独立验收，例如「登录页与系统标题品牌化可验收」「新增某某业务：库表 + API + 管理页可验收」。

拆完后在 GitHub **Issues** 核对条数与验收标准，再：

```
确认拆分合理，创建issue
```



#### 2.2.6 写代码 — 分支 + `/tdd` + PR

从 **Issue #2** 开始（Issue #1 一般为 PRD），**每个 Issue 走一遍「拉分支 → TDD → push → CI → PR → 合并」**。

若依场景建议顺序：

1. **品牌与配置类 Issue**（标题、Logo、版权、demo 开关）——改动面小、易验收
2. **业务垂直切片**——优先新模块/新表，少改 `framework`
3. **涉及权限的菜单/按钮**——与官方「菜单管理 + `@PreAuthorize`」模型对齐，写进验收标准

**步骤 1：为 Issue 建分支**

```
从最新 custom/main 创建新分支，准备实现 Issue #[num]
```

**步骤 2：跑** `/tdd`

```
/tdd

实现该 Issue
```

**步骤 3：接入 CI（首次）**

若依是 Java + Node 双栈，首次可让 Agent 建 GitHub Actions：后端至少编译/单测，前端至少在 `ruoyi-ui` 做 `npm install` + lint/build（按你仓库现状裁剪）。

```
【首次设置即可】创建 CI：对任意分支的 push 与 PR 运行；后端 Maven 编译，前端在 ruoyi-ui 安装依赖并做构建检查
```

**步骤 4：push、等 CI、开 PR、合并**

```
提交并 push
```

```
创建 PR
```

```
请确认 CI 是否通过；失败则摘要原因并建议修复
```

```
合并该 PR 到 custom/main，不要删除该分支，并确认该 Issue 已关闭
```

之后其他 Issue 重复：拉新分支 → `/tdd` → push → 等 CI → PR → 合并。

#### 2.2.7 出问题时 — `/diagnose`

若依常见卡点：数据库脚本未导全、Redis 连不上、跨域/代理前缀（`/dev-api`）、权限注解与菜单 SQL 不一致、上传目录无写权限等。

```
/diagnose

[描述你的具体问题，附上后端日志或浏览器 Network 报错]
```

它会带你走：复现 → 缩小范围 → 提假设 → 观测 → 验证 → 修 → 补回归测试。**不要让它一上来就猜着改。**

#### 2.2.8 v1 跑通后的维护 — `/improve-codebase-architecture`

```
/improve-codebase-architecture

看看有没有可以把业务模块「加深」、少泄漏若依框架细节到业务代码里的地方；同时检查 ruoyi-ui 管理端 UI Token / 品牌规范是否漂移。
```

不必等「变成泥球」——从第一版业务模块起就投资边界设计。

### 2.3 持续合并上游（长期必备）

官方在 **GitHub** 持续发版时，建议定期（也可自然语言描述合并需求）：

```bash
# 在 custom/main 上
git fetch upstream

# 合并官方 master（跟做基线）
git merge upstream/master
```

```
把 upstream 的官方 master 合并进当前 custom/main；有冲突先停下来说明冲突文件，不要擅自丢弃我们的定制
```

合并后：

1. 跑后端启动 + `ruoyi-ui` 登录冒烟
2. 核对 `CUSTOM.md`：品牌资源、配置覆盖是否被盖掉
3. 记一行「合并官方记录」
4. 冲突优先交给 `/diagnose` 或新开 Issue，不要 silently 丢定制

---



## 三、本地运行环境配置

确认本地运行环境（推荐：为本项目做隔离，别弄乱整机）


| 依赖            | 隔离方式（跟做推荐）                        | 作用                      |
| ------------- | --------------------------------- | ----------------------- |
| JDK / Maven   | **SDKMAN**（按 shell / 项目切换版本）      | 装 JDK 17+，不覆盖系统其它 Java  |
| Node / npm    | **nvm**（项目根放 `.nvmrc`）            | 进目录自动用指定 Node，退出不影响其它项目 |
| MySQL / Redis | **Docker Compose**（容器起停）          | **最值得隔离**：不必本机装数据库服务    |
| 前端依赖          | 项目内 `node_modules` + 项目级 `.npmrc` | 依赖本来就在仓内；镜像只写进本项目       |


> 跟做默认：**中间件用 Docker；JDK/Node 用版本管理器**。本机已有可用的 MySQL/Redis/JDK 17+/Node 也可直接用，但更容易和其他项目抢端口、抢版本。



#### 3.1 一次性装好「隔离工具」（装的是管理器，不是把环境焊死进系统）

**Docker Desktop**（或等价 Docker 引擎 + Compose 插件）：[https://www.docker.com/products/docker-desktop/](https://www.docker.com/products/docker-desktop/)

**SDKMAN**（JDK / Maven）：

```bash
curl -s "https://get.sdkman.io" | bash
# 先检查安装脚本有没有把初始化写进 ~/.zshrc（zsh 用户）或 ~/.bashrc（bash 用户）
grep -n "sdkman-init.sh" ~/.zshrc ~/.bashrc 2>/dev/null
# 若上面没有输出，说明没写进去，手动补一行（zsh）：
# echo 'source "$HOME/.sdkman/bin/sdkman-init.sh"' >> ~/.zshrc
# bash 用户则改成写入 ~/.bashrc

# 验证：
sdk version
```

**nvm**（Node）：

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
# 重新打开终端后：
nvm --version
```



#### 3.2 为本项目准备 JDK 17+ 与 Maven（SDKMAN）

```bash
# 安装 JDK 17+（版本号以 sdk list java 为准）
sdk list java | head
sdk install java 17.0.19-amzn
sdk install maven 3.9.16

# 仅当前终端生效（推荐，不改全局 default）
sdk use java 17.0.19-amzn
sdk use maven 3.9.16
java -version
mvn -v
```

**可选：用** `.sdkmanrc` **把本项目的 JDK/Maven 钉死在目录里**

作用：进入这个项目目录后，用 `sdk env` 自动切到若依需要的 JDK/Maven；离开后不影响你本机其它项目的默认版本。适合「多个项目、多套 JDK」时避免手滑用错版本。

具体设置（在项目根、有 `pom.xml` 的那一层）：

```bash
# 1. 先确保当前终端已切到本项目要用的版本（见上）
sdk use java 17.0.19-amzn
sdk use maven 3.9.16

# 2. 生成 .sdkmanrc（按当前 use 的版本写入）
sdk env init

# 3. 之后每次进入项目根，执行一次即可切换
sdk env

# 可选：打开自动切换（cd 进目录就生效）
# 编辑 ~/.sdkman/etc/config，设：
# sdkman_auto_env=true
```

生成后的 `.sdkmanrc` 大致类似：

```text
java=17.0.19-amzn
maven=3.9.16
```

可提交到你的私有仓，方便同事/下次开终端复用同一套版本。

#### 3.3 为本项目准备 Node（nvm）

克隆出仓库后，在**项目根**（有 `pom.xml` 的那一层）执行：

```bash
# 跟做建议一个 LTS，例如 20
nvm install 20
nvm use 20

# 把版本钉在项目里，别人/下次进目录可复用
echo "20" > .nvmrc
# 之后每次进入项目根：nvm use
```

**镜像只写进本项目**（不要用全局 `npm config set`，避免影响其它项目）：

在 `ruoyi-ui/.npmrc` 写入一行：

```text
registry=https://registry.npmmirror.com
```

（**不要用 cnpm**，官方也不建议。）

#### 3.4 为本项目单独起 MySQL + Redis（Docker Compose，强烈推荐）

克隆出仓库后，在项目根新建 `docker-compose.dev.yml`（仅本地开发用，可提交到你的私有仓；密码仅开发环境）：

```yaml
services:
  mysql:
    image: mysql:8.0
    container_name: my-ruoyi-mysql
    ports:
      - "3306:3306"   # 若本机 3306 已被占用，改成 "3307:3306"，并同步改 application-druid.yml
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: ry-vue
    volumes:
      - my_ruoyi_mysql_data:/var/lib/mysql
    command: --character-set-server=utf8mb4 --collation-server=utf8mb4_unicode_ci --lower_case_table_names=1

  redis:
    image: redis:7-alpine
    container_name: my-ruoyi-redis
    ports:
      - "6379:6379"   # 冲突则改 "6380:6379"，并同步改 application.yml 的 redis.port

volumes:
  my_ruoyi_mysql_data:
```

启动 / 停止（只影响这两个容器，不装系统级 MySQL/Redis 服务）：

```bash
# 在项目根
docker compose -f docker-compose.dev.yml up -d
docker compose -f docker-compose.dev.yml ps
docker compose -f docker-compose.dev.yml down      # 停掉；数据还在 volume 里
# docker compose -f docker-compose.dev.yml down -v  # 连数据一并清掉（慎用）
```

后端连容器时：`application-druid.yml` / `application.yml` 里 host 用 `localhost`，端口与上面映射一致。

#### 3.5 跟做前自检（在「已 sdk use / nvm use、容器已 up」的同一终端里）

```bash
java -version          # 应为 17+
mvn -v
node -v
npm -v
docker compose -f docker-compose.dev.yml ps   # mysql / redis 为 running
```

不必本机安装 `mysql` / `redis-cli` 客户端；需要时可用：

```bash
docker exec -it my-ruoyi-mysql mysql -uroot -proot
docker exec -it my-ruoyi-redis redis-cli ping   # 期望 PONG
```

详细部署说明见官方：[环境部署](https://doc.ruoyi.vip/ruoyi-vue/document/hjbs.html)。

---



## 四、相关链接


| 资源            | 链接                                                                                                       |
| ------------- | -------------------------------------------------------------------------------------------------------- |
| 若依 Vue 分离版文档  | [https://doc.ruoyi.vip/ruoyi-vue/](https://doc.ruoyi.vip/ruoyi-vue/)                                     |
| 环境部署          | [https://doc.ruoyi.vip/ruoyi-vue/document/hjbs.html](https://doc.ruoyi.vip/ruoyi-vue/document/hjbs.html) |
| 项目介绍          | [https://doc.ruoyi.vip/ruoyi-vue/document/xmjs.html](https://doc.ruoyi.vip/ruoyi-vue/document/xmjs.html) |
| 官方仓库（GitHub）  | [https://github.com/yangzongzhuan/RuoYi-Vue](https://github.com/yangzongzhuan/RuoYi-Vue)                 |
| 演示站           | [http://vue.ruoyi.vip](http://vue.ruoyi.vip)                                                             |
| 通用二次开发指南（同目录） | `基于开源项目二次开发与AI编程全流程实践指南_V1.2.md`                                                                         |


