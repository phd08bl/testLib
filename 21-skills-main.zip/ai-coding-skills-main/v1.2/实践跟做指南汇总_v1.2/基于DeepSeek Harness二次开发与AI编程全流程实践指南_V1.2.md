# 基于 DeepSeek Harness 二次开发与AI编程全流程实践指南_V1.2

> 本指南以 [DeepSeek Harness](https://deepseek-harness.github.io/deepseek-harness/develop/basic/)（开源 agent harness，CLI 为 `dsh`）为载体，演示如何用 Cursor / Claude Code 等 AI 编程助手，完成插件扩展、私有定制与长期维护。工作法与工程 Skills 与通用二次开发指南一致：需求对齐 → PRD → 拆 Issue → TDD → PR → 持续合并上游，让你在「加工具、换模型、组自己的 agent 产品」时有清晰闭环。

> 面向对象：要用 AI 编程助手，基于 **DeepSeek Harness**（`deepseek-ai/deepseek-harness`，Cordis 插件架构）做**能力扩展与产品定制**（自研 Tool / LLM 适配器 / 组合包，必要时私有分发）并长期维护自己版本的开发者。  
> 可跟做闭环：克隆官方 GitHub → 推到私有仓库与 `custom/main` → 本地从源码跑通 Web UI → 用 `--patch` 加载第一个插件 → 接入工程 Skills → 持续合并上游。

> 官方文档：[https://deepseek-harness.github.io/deepseek-harness/develop/basic/](https://deepseek-harness.github.io/deepseek-harness/develop/basic/)  
> 官方仓库（GitHub）：[https://github.com/deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness)  
> 产品页：[https://deepseek.com/harness](https://deepseek.com/harness)

---



## 〇、先认清 DeepSeek Harness

**DeepSeek Harness**（`dsh`）是 DeepSeek AI 开源的 agent harness（智能体运行时）。核心口号是 **Everything is a Plugin（一切皆插件）**：模型适配器、工具注册表、会话日志、agent 循环、Web UI 本身，都是挂到共享 `ctx` 上的 Cordis 插件。扩展产品的正道不是去改「内核」，而是再挂一个插件。

跟做组合：**官方 GitHub 单仓** `deepseek-ai/deepseek-harness`，分支 `master`（Node.js `^22.19 || >=24`，pnpm workspace，TypeScript ESM）。二次开发以**从源码运行**为准，不要只停留在 `npx @deepseek-ai/dsh web`。

当前阶段是 **developer preview（开发者预览）**，官方明确会有破坏兼容性的变更。许可证为 **MIT**，可闭源商用，但须保留版权与许可声明。官方目前**不接受外部 PR**；社区贡献路径是发插件（仓库打 `dsh-plugin` topic）、写文档、在 [Discussions](https://github.com/deepseek-ai/deepseek-harness/discussions) 反馈，而不是改官方主干。

### 版本怎么选（跟做建议）


| 维度   | 选项                                                                                 | 跟做推荐                                                                 |
| ---- | ---------------------------------------------------------------------------------- | -------------------------------------------------------------------- |
| 运行方式 | `npx @deepseek-ai/dsh web` 即用；从源码 `pnpm install && pnpm run build && pnpm dsh web` | **从源码**（二次开发必须能改、能 patch、能跟上游）                                       |
| 分支   | `master`（当前唯一跟做基线；预览期无长期稳定 tag 承诺）                                                 | `master`                                                             |
| 扩展方式 | 树外插件 / 组合包（bundle）+ profile；直接改 `packages/`；改 `vendor/`（vendored Cordis）           | **优先树外插件与组合包**；少改 `packages/`；**不要改** `vendor/`（除非你明确在维护一份私有 Cordis） |
| 托管   | 官方 GitHub / 其他镜像                                                                   | **一律用官方 GitHub**；`upstream = 官方 GitHub`，`origin = 你的私有 GitHub`       |


> 只想先体验 Web UI，可以用 `npx @deepseek-ai/dsh web`（默认 [http://127.0.0.1:3080](http://127.0.0.1:3080)）。本指南跟做**从源码检出**开始；插件教程也要求已完成「从源码运行」路径。



### 仓库大致长什么样

```text
deepseek-harness/                  # Cursor 打开这一层（克隆后的项目根）
├── apps/                          # CLI / Web 等应用入口（pnpm dsh 走这里）
├── packages/                      # @deepseek-ai/dsh-* 工作区包
│   ├── core/                      # session / tools / agent / agent-loop
│   ├── llm/                       # LLM 能力缝 + DeepSeek 等适配器
│   ├── bundle/                    # 可安装的 profile 层：dsh-base / dsh-web-app / dsh-headless
│   ├── client/                    # Web GUI 浏览器侧
│   ├── host/                      # Web GUI 主机侧
│   └── ...                        # fs / shell / skill / subagent / sdk 等能力族
├── examples/                      # 可运行的 cordis.yml 叶子示例
├── vendor/                        # 内置的 Cordis 源码副本（不要当业务代码改）
├── python/                        # Python SDK
├── native/                        # 原生附加（如 landlock）
├── docs/                          # 架构、cookbook、用户/开发文档源
├── website/                       # VitePress 文档站
├── AGENTS.md                      # 给 Agent 的仓库约定（二次开发必读）
├── package.json                   # 根 workspace；固定 pnpm@11.7.0
└── pnpm-workspace.yaml
```

定制相关常见落点（记入 `CUSTOM.md`）：


| 位置                                        | 通常改什么                              |
| ----------------------------------------- | ---------------------------------- |
| 独立插件仓 / 仓内 `scratch-plugin/`              | 自研 Tool、服务、事件监听、LLM 适配器            |
| `--patch` 用的 `cordis.yml`                 | 本地开发时插入插件（路径必须是**绝对路径**）           |
| `$DSH_HOME/profiles/<名>/cordis.patch.yml` | 某个 profile 的用户覆盖层                  |
| `$DSH_HOME/cordis.patch.yml`              | 本机所有 profile 共享的偏好                 |
| `$DSH_HOME/settings.yaml`                 | 模型提供方、自定义 OpenAI 兼容端点              |
| `$DSH_HOME/.credentials.yaml`             | API Key（**勿提交**；Web UI「设置 → 模型」写入） |
| `packages/client/`、`apps/web`             | 仅当要做 Web UI 换皮/品牌时（尽量避免，优先插件）      |
| `packages/` 其它包                           | 仅当官方扩展点不够、必须改能力缝时；冲突成本高，预览期易被上游打断  |


三个必须分清的词：

- **插件（plugin）**：导出 `apply(ctx)` 的 TypeScript 模块，运行时挂到 Cordis `Context`。  
- **组合包（bundle）**：带 `package.json` → `dsh.bundle` 的 npm 包，贡献一层 `cordis.patch.yml`。  
- **profile**：`$DSH_HOME/profiles/<名>/` 下一份可启动组合（`web` / `headless` 是内置模板）。生效配置按「各 bundle → profile patch → home patch → `--patch`」叠加。

默认 Harness home 是 `$DSH_HOME`**，未设置时为** `~/.dsh`。

---



## 一、你需要提前准备什么


| 条件               | 是否必须   | 说明                                                        |
| ---------------- | ------ | --------------------------------------------------------- |
| 一个 AI 编程助手       | ✅ 必须   | Cursor、Claude Code、Codex 等                                |
| GitHub 账号        | ✅ 必须   | 拉官方代码 + 托管你的私有仓、Issue、PR                                  |
| GitHub CLI（gh）   | ✅ 必须   | 终端或 Agent 创建 PR、关联 Issue                                  |
| Git              | ✅ 必须   | 本地版本控制；上游在官方 GitHub；官方要求 **Git 2.26+**                    |
| 工程 Skills        | ✅ 必须   | 本仓库 `v1.2/skills` 工程技能包                                   |
| Node.js          | ✅ 必须   | `^22.19` **或** `>=24`（CI 覆盖 22.19 / 24 / 26）；推荐 nvm，见 3.2 |
| pnpm             | ✅ 必须   | 仓库固定 `pnpm@11.7.0`；用 Corepack 启用，不要全局乱装一份不匹配的 pnpm        |
| DeepSeek API Key | ⭐ 强烈推荐 | Web / headless / 真实对话需要；无 Key 仍可跑通构建与无密钥测试，但无法完整验收 agent  |




### 1.1 注册 GitHub 并准备 SSH

1. 打开 [https://github.com](https://github.com) 注册账号。
2. 进入 **Settings** → **SSH and GPG keys**。
3. 如果还没有 SSH 密钥，在终端执行：

```bash
ssh-keygen -t ed25519 -C "你的邮箱@example.com"
```

复制公钥：

macOS：

```bash
pbcopy < ~/.ssh/id_ed25519.pub
```

Linux（需要 `xclip`）：

```bash
xclip -sel clip < ~/.ssh/id_ed25519.pub
```

Windows Git Bash：

```bash
cat ~/.ssh/id_ed25519.pub | clip
```

回到 GitHub，点击 **New SSH key**，粘贴公钥并保存。

测试 SSH：

```bash
ssh -T git@github.com
```

成功后会看到类似 `Hi 你的用户名!`

### 1.2 安装 Git



#### macOS

```bash
git --version
xcode-select --install
git --version
```

看到类似 `git version 2.x.x` 即成功。官方开发指南要求 **Git 2.26+**。

#### Windows

1. 打开 [https://gitforwindows.org](https://gitforwindows.org) 下载 Git for Windows。
2. 一路使用默认配置安装。
3. 打开 Git Bash 或命令提示符，输入：

```bash
git --version
```

看到类似 `git version 2.x.x.windows.x` 即成功。

#### Linux

Ubuntu/Debian：

```bash
sudo apt-get update
sudo apt-get install git
git --version
```

CentOS/Fedora：

```bash
sudo yum install git
git --version
```



### 1.3 安装 GitHub CLI (gh)



#### macOS

```bash
gh --version
# 如果未安装，执行下列命令进行安装
brew install gh

# 安装后进行身份认证（建议使用 SSH 方式）
gh auth login

# （如遇权限问题）授予当前用户配置目录的权限
sudo chown -R "$(whoami):staff" ~/.config/gh

# 检查认证状态
gh auth status
```



#### Windows

1. 访问 [https://github.com/cli/cli/releases](https://github.com/cli/cli/releases) 下载 Windows 安装包（`gh_*_windows_amd64.msi`）。
2. 双击运行安装，完成后在“命令提示符”或 PowerShell 执行：

```bash
gh --version
```

1. 初始化并认证 GitHub 账户（建议选择 SSH 方式）：

```bash
gh auth login
```

1. 检查认证状态：

```bash
gh auth status
```



#### Linux

（以 Ubuntu/Debian 为例）

```bash
# 安装最新 gh 版本
type -p curl >/dev/null || sudo apt install curl -y
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh -y

# 安装完成后认证（推荐 SSH）
gh auth login

# 检查认证状态
gh auth status
```

看到 `gh version x.x.x` 信息和认证通过即可。

### 1.4 确认 Skills 已就绪

跟做前，确认你的 AI 编程助手已启用本指南用到的工程 Skills。Skills 包清单如下：


| 序号  | 命令                              | 分类  | 一句话                                               |
| --- | ------------------------------- | --- | ------------------------------------------------- |
| 1   | `/setup-skills`                 | 工程  | 每个仓跑一次，配置 Issue 跟踪器、Triage 标签、领域文档和 ADR、UI 设计是否启用 |
| 2   | `grill-with-docs`               | 工程  | 拷问方案的同时维护 `CONTEXT.md` / ADR / UI 设计治理骨架          |
| 3   | `grill-me`                      | 效率  | 纯拷问，不写仓库文档                                        |
| 4   | `to-prd`                        | 工程  | 把已对齐的需求整理成 PRD 并发布至 Issue                         |
| 5   | `to-issues`                     | 工程  | 按 tracer-bullet 垂直切片，拆功能 Issue 与 UI Issue         |
| 6   | `tdd`                           | 工程  | 红-绿-重构，测试驱动开发                                     |
| 7   | `diagnose`                      | 工程  | 有纪律的排错循环                                          |
| 8   | `triage`                        | 工程  | Issue 状态机分拣                                       |
| 9   | `improve-codebase-architecture` | 工程  | 找「加深模块」的架构重构机会                                    |
| 10  | `zoom-out`                      | 工程  | 拉高视角看陌生代码                                         |


---



## 二、跟做：完整闭环演练

本指南以官方 GitHub 上的 **DeepSeek Harness（**`master` **，从源码运行）** 为示例，演示如何完成插件扩展与私有二次开发。

> **和「给官方提 PR」不是同一条路。** 官方 [CONTRIBUTING](https://github.com/deepseek-ai/deepseek-harness/blob/master/CONTRIBUTING.md) 写明目前不接受外部 PR。你的私有仓是**自己的产品基线**；能开源的能力做成独立插件仓，打上 `[dsh-plugin](https://github.com/topics/dsh-plugin)` topic。



### 2.1 项目初始化



#### 2.1.1 新建项目目录

```bash
# 新建空目录
mkdir my-deepseek-harness
cd my-deepseek-harness
# 用 Cursor 打开这个文件夹
cursor .
```



#### 2.1.2 克隆官方仓库到本地

```bash
# 进到项目根目录
cd my-deepseek-harness

# 官方 GitHub · 默认 master
git clone https://github.com/deepseek-ai/deepseek-harness.git .

# 确认在 master
git branch
```

**说明**：

- `git clone` = 把官方整份代码下载到本机  
- 跟做**留在** `master`  
- 仓库体积与提交历史都很大，首次克隆需要一点时间

克隆完成后，在项目根目录应能看到 `package.json`、`pnpm-workspace.yaml`、`packages/`、`apps/`、`AGENTS.md` 等（以官方当前结构为准）。更多模块说明见官方：[架构文档](https://deepseek-harness.github.io/deepseek-harness/reference/)、仓库内 `docs/architecture.md`。

**检查当前远程**（此时通常只有一个叫 `origin` 的远程，指向官方 GitHub）：

```bash
git remote -v
```

类似：

```text
origin  https://github.com/deepseek-ai/deepseek-harness.git (fetch)
origin  https://github.com/deepseek-ai/deepseek-harness.git (push)
```

接下来我们要把它改成：**upstream = 官方 GitHub，origin = 你的私有库**。

#### 2.1.3 把现在的 origin 改名为 upstream

```bash
git remote rename origin upstream
git remote -v
```

**成功标志**：

```text
upstream  https://github.com/deepseek-ai/deepseek-harness.git (fetch)
upstream  https://github.com/deepseek-ai/deepseek-harness.git (push)
```

此时还没有 `origin`，这是正常的。

#### 2.1.4 在 GitHub 创建空私有仓库

1. 浏览器打开 [https://github.com/new](https://github.com/new)
2. 填写：
  - **Repository name**：`my-deepseek-harness`（或你喜欢的名字，记住即可）  
  - **Description**：可选，如「DeepSeek Harness 定制版」  
  - 选择 **Private**（私有；闭源商用必选）  
  - **不要**勾选 “Add a README file”  
  - **不要**勾选 “Add .gitignore”  
  - 要的是 **完全空仓库**
3. 点 **Create repository**。

创建后会看到仓库地址，二选一：

- SSH：`git@github.com:你的用户名/my-deepseek-harness.git`  
- HTTPS：`https://github.com/你的用户名/my-deepseek-harness.git`

**复制 SSH 地址**（推荐，已配置 SSH 的话）。

#### 2.1.5 添加你的私有仓库为 origin

把下面命令里的地址换成 **你刚复制的地址**：

```bash
git remote add origin git@github.com:YOUR_USER/my-deepseek-harness.git
git remote -v
```

**成功标志**（顺序无所谓）：

```text
origin    git@github.com:YOUR_USER/my-deepseek-harness.git (fetch)
origin    git@github.com:YOUR_USER/my-deepseek-harness.git (push)
upstream  https://github.com/deepseek-ai/deepseek-harness.git (fetch)
upstream  https://github.com/deepseek-ai/deepseek-harness.git (push)
```



#### 2.1.6 创建定制分支 custom/main

**为什么要新分支？**  
官方更新会进 `master`；你的修改放在 `custom/main`，合并时界限清晰，不容易乱。预览期上游变动很快，这条分界尤其重要。

```bash
# 查看当前在哪个分支（跟做应在 master）
git branch

# 创建并切换到 custom/main
git checkout -b custom/main
```

**成功标志**：终端提示 `Switched to a new branch 'custom/main'`，`git branch` 里 `custom/main` 前面有 `*`。

#### 2.1.7 第一次推送到你的私有仓库

```bash
git push -u origin custom/main
```

**说明**：

- `push` = 把本地分支上传到 GitHub。  
- `-u` = 以后在这个分支上直接 `git push` 即可，不用每次写远程名。

**成功标志**：

- 终端无报错，最后一行类似 `Branch 'custom/main' set up to track remote branch 'custom/main' from 'origin'.`  
- 浏览器打开 `https://github.com/你的用户名/my-deepseek-harness`，能看到代码，分支选 `custom/main`。

> **若提示权限错误**：检查 SSH（见 1.1）或改用 HTTPS 地址再 `git remote set-url origin https://...`。



#### 2.1.8 本地跑通一次（强烈建议，再谈定制）

官方要求：**从源码运行要先装依赖、再构建、再启动**。对于 Node / pnpm 的隔离安装请参考第 3 章，配置完成后再继续往下操作。

**0）激活本项目隔离环境（每个新终端做一次）**

```bash
# 在项目根目录
nvm use          # 读取 .nvmrc（若尚未创建，见 3.2）
corepack enable
pnpm --version   # 应解析到仓库锁定的 11.7.0 一带
```

**1）安装依赖并做一次类型检查**

```bash
pnpm install
pnpm run typecheck
```

`pnpm install` 还会通过 `postinstall` 安装 worktree 本地的 Lefthook 钩子。`pnpm run typecheck` 成功退出，即官方开发指南所说的「首次搭建完成」。

**2）构建（源码启动 Web / headless 前必须）**

```bash
pnpm run build
```

生产路径需要已构建的包产物和前端产物。首次构建会花较长时间，属正常。

**3）（可选）准备 API Key**

任选其一，**不要把真实 Key 提交进 Git**：

- 稍后在 Web UI **设置 → 模型**里填写（写入 `~/.dsh/.credentials.yaml`）  
- 或在仓库根目录建被 gitignore 的 `.env`：

```sh
DEEPSEEK_API_KEY=sk-...
# DEEPSEEK_BASE_URL=https://...   # 可选，默认公开 API
```

无 Key 时：构建和大部分无密钥测试仍可跑；真实对话、headless demo、真实 API e2e 会跳过或不可用。

**4）启动 Web UI**

在**项目根**（有根 `package.json` 与 `pnpm-workspace.yaml` 的那一层）执行：

```bash
pnpm dsh web
```

**成功标志**

- 终端打印访问地址，默认 **[http://127.0.0.1:3080](http://127.0.0.1:3080)**，无持续报错刷屏。  
- 浏览器能打开 Web UI。  
- 打开 **设置 → 模型**，填入 DeepSeek API Key 并保存（无需重启）。  
- 点击 **选择工作区**，选中你启动 `dsh` 时所在的项目目录。  
- 新开会话，发送一句例如：`Summarize this repository and identify its main packages.`，模型能回复（需已配置 Key）。

> `dsh` 把**调用目录**当作默认文件系统位置，但新的 Web UI 在你手动选中工作区之前，会话输入框不可用。  
> `dsh web` 是 `--profile web` 的别名。改端口等应用参数写在启动器 flag **之后**，例如 `pnpm dsh web --port 3081`。  
> 卡住时优先查官方 [从源码运行](https://github.com/deepseek-ai/deepseek-harness/blob/master/README.zh.md)、[开发指南](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/development.zh.md)、[使用 Web UI](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/guide/index.zh.md)：Node 版本不对、未 `corepack enable`、没跑 `pnpm run build`、没选工作区、Key 未配置。

**5）用** `--patch` **加载最小插件（强烈建议，确认扩展路径通）**

官方「第一个插件」教程要求：已完成从源码运行。在仓库根：

```bash
mkdir -p scratch-plugin/src
pwd    # 记下绝对路径，下一步要用
```

创建 `scratch-plugin/src/my-plugin.ts`：

```ts
import type { Context } from '@deepseek-ai/cordis'

export const name = 'hello-plugin'

export function apply(ctx: Context) {
  console.log('[hello-plugin] plugin loaded!')
}
```

创建 `scratch-plugin/cordis.yml`（把路径换成你的 `pwd` 结果；**必须是绝对路径**）：

```yaml
- insert:
    - id: hello
      name: '/absolute/path/to/deepseek-harness/scratch-plugin/src/my-plugin.ts'
```

启动：

```bash
pnpm dsh web --patch ./scratch-plugin/cordis.yml
```

**成功标志**：启动期间终端打印 `[hello-plugin] plugin loaded!`。这就是二次开发的最小闭环：不改 `packages/`，只往树上插一行。

> patch 只贡献配置，不会改变 loader 解析模块路径时使用的 profile 目录，所以本地插件路径必须是绝对路径。详见官方：[第一个插件](https://deepseek-harness.github.io/deepseek-harness/develop/basic/)。



#### 2.1.9 创建 CUSTOM.md（强烈建议）

用来记录「我改了什么」，以后合并官方时非常有用。预览期上游会频繁破坏兼容性，这份清单比注释更可靠。

在仓库根目录（有根 `package.json` 的那一层）新建文件 `CUSTOM.md`，内容可先照抄：

```markdown
# 相对官方的定制说明

## 基线
- 上游仓库：https://github.com/deepseek-ai/deepseek-harness
- 跟做基线分支：master（developer preview，会有破坏性变更）
- 运行方式：从源码 pnpm install / build / pnpm dsh web
- Node：^22.19 或 >=24；pnpm@11.7.0（Corepack）
- 扩展策略：优先树外插件 / 组合包，少改 packages/，不改 vendor/

## 产品
- 产品名：（待填写）
- 默认 profile：web / 自建 profile 名：（待填写）
- 模型提供方：DeepSeek / 其它 / 自定义 OpenAI 兼容端点

## 我的插件与组合包
| 名称 | 形态（--patch / bundle / profile patch） | 作用 | 日期 |
|------|------------------------------------------|------|------|
| | | | |

## 我改过的官方文件（尽量为空）
| 文件/目录 | 改了什么 | 日期 |
|-----------|----------|------|
| | | |

## 我故意不跟的上游行为
| 点 | 原因 |
|----|------|
| | |

## 合并官方记录
| 日期 | 官方提交/标签 | 有没有冲突 | 备注 |
|------|---------------|------------|------|
| | | | |
```

保存后执行：

```bash
git add CUSTOM.md
git commit -m "docs: 添加定制记录文件 CUSTOM.md"
git push
```

**成功标志**：GitHub 上 `custom/main` 分支能看到 `CUSTOM.md`。

#### 2.1.10 初始化自检（做完打勾）

在 `my-deepseek-harness` 目录执行：

```bash
git status
git branch
git remote -v
```


| 检查项             | 期望结果                                                  |
| --------------- | ----------------------------------------------------- |
| `git status`    | `nothing to commit, working tree clean`（或只有你知道的未提交文件） |
| `git branch`    | 当前在 `* custom/main`                                   |
| `git remote -v` | 同时有 `origin`（你的私有 GitHub）和 `upstream`（官方 GitHub）      |
| GitHub 网页       | 私有库 `my-deepseek-harness`，分支 `custom/main` 有代码        |
| 本地联调            | `pnpm run typecheck` 通过；`pnpm dsh web` 可打开 UI         |
| 插件路径            | `--patch` 后终端出现 `[hello-plugin] plugin loaded!`       |


**到这里初始化完成。** 后面所有开发都在 `custom/main` 上进行（或从其上拉 `issue/`* 分支）。业务插件优先放独立目录或独立仓，避免和官方 `packages/` 缠在一起。

### 2.2 二次开发（接入工作法）



#### 2.2.1 项目初始配置 — `/setup-skills`

接下来进行项目设置，它会依次问你 Issue 跟踪器、Triage 标签、领域文档布局；有管理端 / 产品 UI 时还会问是否启用 UI 设计管控。

**自然语言（在 Cursor 里说）**：

```bash
/setup-skills
```


| 步骤  | 问什么           | 小白怎么选                                                                    |
| --- | ------------- | ------------------------------------------------------------------------ |
| A   | Issue 跟踪器放哪？  | **跟做推荐 GitHub**（Issue + PR 可审查）                                          |
| B   | Triage 标签叫什么？ | 第一次用 → 接受默认；若要改 Web UI，会用到 `design-input`                                |
| C   | 领域文档放哪？       | 单仓 monorepo → **Single-context**（根目录 `CONTEXT.md` + `docs/adr/`）         |
| D   | UI 设计治理？      | 只做 Tool / 适配器 / 组合包 → **Disabled**；要换皮 Web UI 或做自有 Chat 节点 → **Enabled** |


完成后会在项目里生成：

```
你的项目/
├── AGENTS.md 或 CLAUDE.md    ← Agent 技能配置块（Cursor 用 AGENTS.md）
└── docs/agents/
    ├── issue-tracker.md
    ├── triage-labels.md
    ├── domain.md
    └── design-governance.md  ← 启用 UI 治理时生成
```

> 官方仓根目录已有一份给上游贡献者看的 `AGENTS.md`。`/setup-skills` 写入的是**你的工作法配置块**。不要删掉官方约定；冲突时：官方仓库纪律继续约束 `packages/`，你的领域术语进 `CONTEXT.md`。

**每个仓库只需跑一次**。以后改配置，直接编辑 `docs/agents/*.md` 即可。**最后完成 GitHub 推送**，推荐全程自然语言：

```
提交并push
```



#### 2.2.2 查看当前代码结构 — `/zoom-out`

Harness 包很多，建议先建立「能力缝 + 插件树 + 一次对话」心智模型，而不是从某个 `packages/*` 里开始改。

**自然语言（在 Cursor 里说）：**

```
/zoom-out

这是 DeepSeek Harness（master，Cordis「一切皆插件」）。请画出：
1）packages 主要分组职责（core / llm / bundle / client / host / fs / shell / skill 等），以及不该改的 vendor/
2）一次启动如何组成插件树：profile 的 bundles → profile cordis.patch.yml → $DSH_HOME patch → --patch
3）一次「用户发消息 → agent-loop → tools → session log → UI」的调用链
不要贴大段源码，重点是模块边界、ctx 上的服务键，以及「新能力应该挂在哪、而不是改 agent-loop」。
```



#### 2.2.3 开工前对齐 — `/grill-with-docs`

**自然语言（在 Cursor 里说）**：

```
/grill-with-docs

我想基于官方 GitHub 开源代码（DeepSeek Harness master）做二次开发，做成自己的 agent 产品（可闭源商用）。我的产品名称是：星火助手。

v1 目标：
- 不改 vendor/，尽量不改 packages/ 核心；用插件 / 组合包 / profile 扩展
- 至少一个业务 Tool（模型可调用、Web UI 里能验收到）
- 明确模型策略：默认 DeepSeek，是否还要自定义 OpenAI 兼容端点
- 明确分发形态：源码 fork + --patch，还是打成 bundle 用 dsh plugin add 装进自有 profile
- 所有定制记入 CUSTOM.md，方便以后合并 upstream（官方 GitHub；预览期破坏性变更会很勤）

请一步步拷问我，把产品范围、扩展边界（插件 vs 改核心）、profile 策略和术语都落地清楚。
```

**你会经历什么：**

1. 智能体**一次只问一个问题**
2. 逼你把模糊词变成术语（如「工具」「技能」「组合包」「profile」「能力缝」在你产品里的含义）
3. 每敲定一个术语，会**当场写入** `CONTEXT.md`
4. 遇到难反悔的抉择会写 **ADR**（例如：插件放仓内 `scratch-plugin` 还是独立仓；要不要白标 Web UI；要不要自研 LLM 适配器）
5. **若启用了 UI 治理**：在术语稳定后还会问品牌色、Chat 节点是否自研、哪些页面需要参考图；并按需创建 `docs/design/`

**你要做的：**

- 认真回答每个问题；不确定就说「接受你的建议」
- `CONTEXT.md` 每更新一次就扫一眼
- **仍然不要写代码**；没有术语表就开工，后面命名和测试会全线跑偏

**确认后：**

```
提交并push
```



#### 2.2.4 沉淀需求 — `/to-prd`

对齐后，**自然语言（在 Cursor 里说）：**

```
/to-prd

整理成 PRD
```

智能体会生成 PRD，并在 GitHub 上创建为 Issue。到仓库 **Issues** 页核对；也可直接问：

```
请帮我在 GitHub Issues 里确认 PRD Issue 是否已创建，并列出标题与编号。
```



#### 2.2.5 拆任务 — `/to-issues`

二次开发**强烈建议拆 Issue**，避免一次让智能体「改全仓 harness + 加十个工具 + 换皮 UI」。

**自然语言（在 Cursor 里说）**：

```
/to-issues

按垂直切片拆 v1 PRD
```

若 v1 含 Web UI 换皮或自有 Chat 节点，还需拆 **UI / Design Issue**。

反例：把「#1 改完所有 core 包 → #2 再写全部工具 → #3 再做 UI」拆成水平层——会和 `/tdd` 节奏冲突，也和「一切皆插件」对着干。  
正例：每一刀都能独立验收，例如「`--patch` 加载 greet 工具可验收」「组合包可 `dsh plugin add` 进自有 profile」「某某业务 Tool：schema + execute + Web UI 调用可验收」。

拆完后在 GitHub **Issues** 核对条数与验收标准，再：

```
确认拆分合理，创建issue
```



#### 2.2.6 写代码 — 分支 + `/tdd` + PR

从 **Issue #2** 开始（Issue #1 一般为 PRD），**每个 Issue 走一遍「拉分支 → TDD → push → CI → PR → 合并」**。

Harness 场景建议顺序：

1. **最小 Tool 插件**（官方 `greet` 教程量级）——改动面小、Web UI 可验收
2. **插件配置 + 打成 bundle**——`dsh.bundle` + `dsh plugin --profile <名> add`
3. **业务垂直切片**——新 Tool / 新服务 / 新 LLM 适配器，挂在扩展点上，不改 `agent-loop`
4. **涉及 Web UI / Chat 节点**——与官方 `ConversationNodeDefinition` 对齐，写进验收标准

官方最小 Tool 形态（跟做时以当前文档为准）：

```ts
import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'greet-tool'
export const inject = ['tools']

export function apply(ctx: Context) {
  ctx.tools.register(defineTool({
    name: 'greet',
    description: 'Greet someone by name.',
    parameters: {
      name: { type: 'string', required: true, description: 'The name to greet' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      return `Hello, ${args.name}!`
    },
  }))
}
```

重启：

```bash
pnpm dsh web --patch ./scratch-plugin/cordis.yml
```

在 UI 里说：`Use the greet tool to greet Ada.` 模型应能调用 `greet` 并得到 `Hello, Ada!`。详见：[开发一个 Tool](https://deepseek-harness.github.io/deepseek-harness/en/develop/basic/tool)。

打成可安装组合包时，核心是 `package.json` 里的：

```json
{
  "name": "dsh-hello-plugin",
  "dsh": { "bundle": { "patch": "./cordis.patch.yml" } }
}
```

以及：

```bash
dsh plugin --profile demo add ./hello-plugin
dsh --profile demo --dump-config
```

从 GitHub 安装源码包还要注意：作者需要自包含的 `prepare` 构建脚本，用户要在 profile 的 `pnpm-workspace.yaml` 里授权 `allowBuilds`。更稳妥的是发 npm 预构建包或 `pnpm pack` 的 tarball。详见：[打包与安装插件](https://deepseek-harness.github.io/deepseek-harness/develop/basic/publish)。

**步骤 1：为 Issue 建分支**

```
从最新 custom/main 创建新分支，准备实现 Issue #[num]
```

**步骤 2：跑** `/tdd`

```
/tdd

实现该 Issue
```

Harness 官方测试纪律很严（单测、snapshot、真实 API e2e 分层）。你的**树外插件**不必照搬上游「`packages/*/*/src` 逐文件 100% 覆盖」；但每个模型可见行为至少要有：可重复的加载方式 + 一次真实或可回放的调用验收。改到官方 `packages/` 时，才按仓库 `AGENTS.md` / `docs/testing.md` 补门禁。

**步骤 3：接入 CI（首次）**

这是 TypeScript monorepo。首次可让 Agent 建 GitHub Actions：至少 `pnpm install` + `pnpm run typecheck`；有插件单测再加 `pnpm run test`。完整上游门禁（coverage / snapshot / hygiene / 多 Node 矩阵）给官方 CI 用，不必一上来全抄到私有仓。

```
【首次设置即可】创建 CI：对任意分支的 push 与 PR 运行；Node 22.19 或 24，pnpm 用 Corepack，执行 pnpm install 与 pnpm run typecheck
```

**步骤 4：push、等 CI、开 PR、合并**

```
提交并 push
```

```
创建 PR
```

```
请确认 CI 是否通过；失败则摘要原因并建议修复
```

```
合并该 PR 到 custom/main，不要删除该分支，并确认该 Issue 已关闭
```

之后其他 Issue 重复：拉新分支 → `/tdd` → push → 等 CI → PR → 合并。

#### 2.2.7 出问题时 — `/diagnose`

Harness 常见卡点：Node 版本不在 `^22.19 || >=24`、未 `corepack enable` / pnpm 版本不对、没跑 `pnpm run build` 就 `pnpm dsh web`、`--patch` 用了相对路径、未选工作区导致输入框不可用、Key 未写入导致 `MISSING_CREDENTIAL`、插件未 `inject: ['tools']` 就调 `ctx.tools`、改了 `agent-loop` 却没更新架构约定。

```
/diagnose

[描述你的具体问题，附上终端日志或浏览器 Network 报错]
```

它会带你走：复现 → 缩小范围 → 提假设 → 观测 → 验证 → 修 → 补回归测试。**不要让它一上来就猜着改。**

#### 2.2.8 v1 跑通后的维护 — `/improve-codebase-architecture`

```
/improve-codebase-architecture

看看有没有可以把「业务插件」加深、少泄漏 harness 内部细节到业务代码里的地方；
对照官方能力缝（Service Definition / Provider / Consumer），检查我们是不是把三层揉在一个文件里了；
若启用了 Web UI 定制，检查品牌 Token / Chat 节点是否漂移。
```

不必等「变成泥球」——从第一个业务 Tool 起就投资边界设计。官方扩展地图见仓库 `docs/architecture.md` 的「Where new behavior goes」。

### 2.3 持续合并上游（长期必备）

官方处于开发者预览，**GitHub** `master` **会快速破坏兼容性**。建议定期（也可自然语言描述合并需求）：

```bash
# 在 custom/main 上
git fetch upstream

# 合并官方 master（跟做基线）
git merge upstream/master
```

```
把 upstream 的官方 master 合并进当前 custom/main；有冲突先停下来说明冲突文件，不要擅自丢弃我们的定制
```

合并后：

1. `pnpm install`（lockfile 常变）→ `pnpm run typecheck` → 必要时 `pnpm run build` → `pnpm dsh web` 冒烟
2. 再跑一遍你的 `--patch` / 自有 profile，确认插件仍能加载
3. 核对 `CUSTOM.md`：插件路径、bundle 名、是否被上游改了 `ctx` 服务键或 Tool DSL
4. 记一行「合并官方记录」
5. 冲突优先交给 `/diagnose` 或新开 Issue，不要 silently 丢定制

> 若你的扩展全在树外组合包里，合并会轻松得多——这是跟做一开始就强调「少改 `packages/`」的原因。

---



## 三、本地运行环境配置

确认本地运行环境（推荐：为本项目做隔离，别弄乱整机）


| 依赖             | 隔离方式（跟做推荐）                           | 作用                             |
| -------------- | ------------------------------------ | ------------------------------ |
| Node.js        | **nvm**（项目根放 `.nvmrc`）               | 进目录用 22.19+ / 24，退出不影响其它项目     |
| pnpm           | **Corepack**（跟仓库 `packageManager` 走） | 钉死 `pnpm@11.7.0`，避免全局 pnpm 抢版本 |
| API Key / 模型配置 | `~/.dsh/` 与仓库根 `.env`（gitignore）     | 密钥不进 Git；Web UI 与 CLI 都能读到     |
| 插件依赖           | 项目内 `node_modules` + 可选项目级 `.npmrc`  | 依赖本来就在仓内；镜像只写进本项目              |


> 跟做默认：**Node 用 nvm；pnpm 用 Corepack**。本机已有可用的 Node 22.19+ / 24 也可直接用，但更容易和其他项目抢版本。  
> 本项目**不需要** MySQL / Redis / JDK。会话与设置落在 `$DSH_HOME`（默认 `~/.dsh`）。



#### 3.1 一次性装好「隔离工具」（装的是管理器，不是把环境焊死进系统）

**nvm**（Node）：

```bash
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.3/install.sh | bash
# 重新打开终端后：
nvm --version
```

Windows 可用 [nvm-windows](https://github.com/coreybutler/nvm-windows) 或官方 Node 安装包，只要最终 `node -v` 满足引擎要求。

**Corepack**（pnpm，Node 官方附带）：

```bash
corepack enable
corepack --version
```

进入本仓库后再执行 `pnpm --version`，应走 `package.json` 里的 `"packageManager": "pnpm@11.7.0"`。

#### 3.2 为本项目准备 Node（nvm）

克隆出仓库后，在**项目根**（有 `package.json` 的那一层）执行：

```bash
# 跟做建议 Node 24，或 22.19+
nvm install 24
nvm use 24

# 把版本钉在项目里，别人/下次进目录可复用
echo "24" > .nvmrc
# 之后每次进入项目根：nvm use
```

确认引擎：

```bash
node -v    # 应为 v22.19.x，或 v24+ / v26（CI 矩阵）
```

**镜像只写进本项目**（不要用全局 `npm config set`，避免影响其它项目）：

在项目根 `.npmrc` 写入一行（可选）：

```text
registry=https://registry.npmmirror.com
```

（**不要用 cnpm**。）启用 Corepack 后继续用 `pnpm`，不要另装一份全局 pnpm 抢锁。

#### 3.3 为本项目准备密钥（不要提交）

Web UI 路径（跟做推荐）：启动后 **设置 → 模型** → 填 DeepSeek API Key → 保存。密钥进 `$DSH_HOME/.credentials.yaml`（默认 `~/.dsh/.credentials.yaml`），设置里只留引用，页面不再回显明文。

CLI / headless / 源码 demo 还可在仓库根 `.env`（已被官方 gitignore）写入：

```sh
DEEPSEEK_API_KEY=sk-...
DEEPSEEK_BASE_URL=https://...   # 可选
```

其它提供方、公司网关、自建 OpenAI 兼容端点见官方：[配置模型](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/guide/providers.md)。常见错误：`MISSING_CREDENTIAL`（没存 Key）、未选工作区、自定义视觉模型未声明 `input: [text, image]`。

Headless 一次任务（需 Key，且已 `pnpm run build`）：

```bash
pnpm dsh --profile headless "summarize this workspace"
```

查看某 profile 实际启动的配置树（不真正跑 agent）：

```bash
pnpm dsh --profile web --dump-config
```



#### 3.4 跟做前自检（在「已 nvm use、corepack enable」的同一终端里）

```bash
node -v              # 22.19+ 或 24+
corepack enable
pnpm --version       # 应接近 11.7.0
git --version        # 2.26+
```

在项目根：

```bash
pnpm install
pnpm run typecheck
```

不必本机安装额外数据库。用户数据默认在：

```bash
ls ~/.dsh            # profiles / settings.yaml / .credentials.yaml 等
```

可用 `DSH_HOME` 覆盖该目录；改完需重启 `dsh`。

详细搭建说明见官方：[开发指南](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/development.zh.md)。

---



## 四、相关链接


| 资源               | 链接                                                                                                                                                                       |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 第一个插件（中文文档）      | [https://deepseek-harness.github.io/deepseek-harness/develop/basic/](https://deepseek-harness.github.io/deepseek-harness/develop/basic/)                                 |
| 开发一个 Tool        | [https://deepseek-harness.github.io/deepseek-harness/en/develop/basic/tool](https://deepseek-harness.github.io/deepseek-harness/en/develop/basic/tool)                   |
| 打包与安装插件          | [https://deepseek-harness.github.io/deepseek-harness/develop/basic/publish](https://deepseek-harness.github.io/deepseek-harness/develop/basic/publish)                   |
| 架构说明             | [https://deepseek-harness.github.io/deepseek-harness/reference/](https://deepseek-harness.github.io/deepseek-harness/reference/)                                         |
| 官方仓库（GitHub）     | [https://github.com/deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness)                                                                       |
| 中文 README        | [https://github.com/deepseek-ai/deepseek-harness/blob/master/README.zh.md](https://github.com/deepseek-ai/deepseek-harness/blob/master/README.zh.md)                     |
| 开发指南             | [https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/development.zh.md](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/development.zh.md) |
| 架构文档             | [https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/architecture.md](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/architecture.md)     |
| 贡献说明（目前不接受外部 PR） | [https://github.com/deepseek-ai/deepseek-harness/blob/master/CONTRIBUTING.zh.md](https://github.com/deepseek-ai/deepseek-harness/blob/master/CONTRIBUTING.zh.md)         |
| 社区 Discussions   | [https://github.com/deepseek-ai/deepseek-harness/discussions](https://github.com/deepseek-ai/deepseek-harness/discussions)                                               |
| 插件发现 topic       | [https://github.com/topics/dsh-plugin](https://github.com/topics/dsh-plugin)                                                                                             |
| 产品页              | [https://deepseek.com/harness](https://deepseek.com/harness)                                                                                                             |
| 通用二次开发指南（同目录）    | `基于开源项目二次开发与AI编程全流程实践指南_V1.2.md`                                                                                                                                         |


