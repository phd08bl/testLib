# 打造高效协作的 AI 编程全流程保姆级实践指南_V1.2

> 面向对象：在用 Cursor / Claude Code / Codex 等 AI 编程助手，但总觉得“智能体听不懂我”“代码越写越乱”，以及在开发过程中 UI 效果无法把控的开发者。 本文提供一套可跟做的 **AI 编程全流程实践指南**：涵盖从需求对齐、协作流程到测试驱动实现，把软件工程习惯嵌进日常 AI 编程。
>
> 本指南在 [mattpocock/skills](https://github.com/mattpocock/skills)（GitHub 17 万+ Star，MIT 开源协议）开源项目基础上，结合自身实践不断迭代完善。

## 版本记录


| 版本         | 日期         | 作者                       | 变更说明                                                                                                                                                                                                                                                                                                      |
| ---------- | ---------- | ------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| V1.0       | 2026-06-22 | 南哥（B站、YouTube @南哥AGI研习社） | 初始版本发布：① 将开源项目中的 Skills 中文化并融入自身实践经验；② 在整体流程中新增了 UI 设计治理环节。                                                                                                                                                                                                                                               |
| V1.1       | 2026-06-24 | 南哥（B站、YouTube @南哥AGI研习社） | ① Skills 中的 /to-issues 微调，主要解决：如有 `#D-global`（全局基线）和 `#D-templates`（页面/状态模板）类型的 Design Issues，将它们的初始状态标记为 `ready-for-agent`，可直接交由Agent处理；② 将4.2全栈预约核销 `shop-book`项目案例场景具体为：宠物洗护门店预约核销系统。                                                                                                                  |
| V1.2(当前版本) | 2026-07-06 | 南哥（B站、YouTube @南哥AGI研习社） | 工作法全新调整： ① `/setup-skills` 调整为 Issue 跟踪器+ Triage 标签 + 领域文档三项。② `/grill-with-docs` 固定拷问顺序（领域 → 技术栈 → UI 模式 + 品牌视觉规范），；UI 编码模式（重新设计为3种模式） 在领域与技术栈确认后选定并写入 `DESIGN.md`；③ `/to-prd` 先写 `docs/prd` 本地确认，PRD模版全新设计改版；④ `/to-issues` 引入 PRD 绑定、States 矩阵、Design Issue 分层；⑤ `/tdd` 编码前强制 PRD 必检预检，TDD严格参考PRD进行编码。 |


---



## 一、这是什么？一句话介绍

这是一套面向 AI 编程助手的**全流程工作法**——不是替你包办一切的“重型框架”，而是把需求对齐、规划、实现、排错、架构维护拆成**小而可组合**的步骤，通过对话里的 Skill 逐步触发。

目标很明确：**真工程**，而不是“Vibe Coding”——每个阶段都有可检查的产物（领域术语表、架构决策记录、`DESIGN.md`、PRD、Issue、测试、PR）。

和 GSD、BMAD、Spec-Kit 等规格驱动开发的“流程接管型”方案不同，本指南的设计原则是：


| 特点            | 说明                             |
| ------------- | ------------------------------ |
| **小**         | 每个 Skill 只做一件事，上手成本低           |
| **可改编**       | 流程、Skills 均可按团队习惯裁剪            |
| **可组合**       | 支持将各环节流程按照实际需求灵活组合，逐步推进完整的开发流程 |
| **AI 编程助手无关** | Cursor、Claude Code、Codex 等都能用  |


---



## 二、它解决哪四个痛点？

AI 编程最常见的失败模式可归纳成四类，本指南为每类准备了对应技能与产出物：

```mermaid
flowchart LR
  A[智能体没做对] --> B["/grill-me<br/>/grill-with-docs"]
  C[对话太啰嗦] --> D["CONTEXT.md<br/>领域共享语言"]
  E[代码跑不通] --> F["/tdd<br/>/diagnose"]
  G[代码变成泥球] --> H["/zoom-out<br/>/to-prd<br/>/improve-codebase-architecture"]
```





### 痛点 1：智能体没听懂你要什么

**现象**：你说“加个提醒功能”，它做了个完全不是你想要的版本。

**根因**：需求没对齐——人和 AI 之间缺一次“拷问式访谈”。

**解法**：

- `/grill-me` — 纯访谈，不写文档，适合产品想法、流程设计
- `/grill-with-docs` — 同样拷问，但会同步维护 `CONTEXT.md`、ADR（架构决策记录）及 `docs/design/DESIGN.md`（若启用 UI）



### 痛点 2：对话和代码都太啰嗦

**现象**：智能体用 20 个词描述一件能用 1 个领域术语说清的事。

**根因**：项目没有共享语言，Issue 正文重复粘贴 PRD 全文。

**解法**：`CONTEXT.md`——项目的领域术语表；**PRD 绑定**——Issue 用编号清单路由 Agent 到 PRD 正确段落，不重复全文。如：

- ❌ “加一条任务”“标记完成”
- ✅ “添加一条 **待办（Todo）**”“标为 **已完成（Done）**”

术语统一后，变量名、函数名、测试名都会更一致，智能体也更省 token。

### 痛点 3：代码写出来不能跑

**现象**：看起来对，一运行就挂；或者改一处坏三处。

**根因**：反馈回路太弱——智能体在“盲飞”。

**解法**：

- `/tdd` — 测试驱动开发，红-绿-重构，**垂直切片**（一次只写一个测试 + 一份实现）
- `/diagnose` — 有纪律的排错循环：复现 → 最小化 → 假设 → 观测 → 修复 → 回归测试



### 痛点 4：代码库变成泥球

**现象**：功能能跑，但越改越不敢动。

**根因**：AI 加速写代码，也加速了“软件熵增”

**解法**：

- `/zoom-out` — 让 AI 从系统视角解释陌生代码
- `/to-prd` — 大改动前先沉淀 PRD，明确动哪些模块、验收标准
- `/improve-codebase-architecture` — 定期做“加深模块”重构

---



## 三、你需要提前准备什么


| 条件             | 是否必须 | 说明                                                 |
| -------------- | ---- | -------------------------------------------------- |
| 一个 AI 编程助手     | ✅ 必须 | Cursor、Claude Code、Codex 等                         |
| GitHub 账号      | ✅ 必须 | 托管代码、跟踪 Issue、走 PR 流程（GitLab 亦可，见 `/setup-skills`） |
| GitHub CLI（gh） | ✅ 必须 | 在终端里(或Agent)调用 GitHub API 创建 PR、关联 Issue           |
| Git            | ✅ 必须 | 本地代码版本控制                                           |
| 工程 Skills      | ✅ 必须 | 工程技能组合包                                            |




### 3.1 注册 GitHub 并准备 SSH

1. 打开 [https://github.com](https://github.com) 注册账号。
2. 进入 **Settings** → **SSH and GPG keys**。
3. 如果还没有 SSH 密钥，在终端执行：

```bash
ssh-keygen -t ed25519 -C "你的邮箱@example.com"
```

复制公钥：

macOS：

```bash
pbcopy < ~/.ssh/id_ed25519.pub
```

Linux（需要 `xclip`）：

```bash
xclip -sel clip < ~/.ssh/id_ed25519.pub
```

Windows Git Bash：

```bash
cat ~/.ssh/id_ed25519.pub | clip
```

回到 GitHub，点击 **New SSH key**，粘贴公钥并保存。

测试 SSH：

```bash
ssh -T git@github.com
```

成功后会看到类似 `Hi 你的用户名!`

### 3.2 安装 Git



#### macOS

```bash
git --version
xcode-select --install
git --version
```

看到类似 `git version 2.x.x` 即成功。

#### Windows

1. 打开 [https://gitforwindows.org](https://gitforwindows.org) 下载 Git for Windows。
2. 一路使用默认配置安装。
3. 打开 Git Bash 或命令提示符，输入：

```bash
git --version
```

看到类似 `git version 2.x.x.windows.x` 即成功。

#### Linux

Ubuntu/Debian：

```bash
sudo apt-get update
sudo apt-get install git
git --version
```

CentOS/Fedora：

```bash
sudo yum install git
git --version
```



### 3.3 安装 GitHub CLI (gh)



#### macOS

```bash
gh --version
# 如果未安装，执行下列命令进行安装
brew install gh

# 安装后进行身份认证（建议使用 SSH 方式）
gh auth login

# （如遇权限问题）授予当前用户配置目录的权限
sudo chown -R "$(whoami):staff" ~/.config/gh

# 检查认证状态
gh auth status
```



#### Windows

1. 访问 [https://github.com/cli/cli/releases](https://github.com/cli/cli/releases) 下载 Windows 安装包（`gh_*_windows_amd64.msi`）。
2. 双击运行安装，完成后在“命令提示符”或 PowerShell 执行：

```bash
gh --version
```

1. 初始化并认证 GitHub 账户（建议选择 SSH 方式）：

```bash
gh auth login
```

1. 检查认证状态：

```bash
gh auth status
```



#### Linux

（以 Ubuntu/Debian 为例）

```bash
# 安装最新 gh 版本
type -p curl >/dev/null || sudo apt install curl -y
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
sudo chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
sudo apt update
sudo apt install gh -y

# 安装完成后认证（推荐 SSH）
gh auth login

# 检查认证状态
gh auth status
```

看到 `gh version x.x.x` 信息和认证通过即可。

### 3.4 确认 Skills 已就绪

跟做前，确认你的 AI 编程助手已启用本指南用到的工程 Skills。若尚未配置，按你所在环境（如 Cursor 根目录下创建 .cursor/skills）完成部署（将提供完整的 Skills 包拷贝至 .cursor/skills）。Skills 包清单如下：


| 序号  | 命令                              | 分类  | 一句话                                                             |
| --- | ------------------------------- | --- | --------------------------------------------------------------- |
| 1   | `/hi-ai-coding`                 | 入门  | 零基础 AI Coding 认知引导：是什么、vs Vibe 与可控、工程常识、协作方式、工作法全流程导览（可沉淀认知报告）  |
| 2   | `/setup-skills`                 | 工程  | 每个仓跑一次，配置 Issue 跟踪器（GitHub / GitLab / 本地 md）、Triage 标签、领域文档布局   |
| 3   | `grill-with-docs`               | 工程  | 拷问方案 + 维护 `CONTEXT.md` / ADR / `DESIGN.md`（含 UI 模式选定与品牌视觉规范）    |
| 4   | `grill-me`                      | 效率  | 纯拷问，不写仓库文档                                                      |
| 5   | `to-prd`                        | 工程  | 先写 `docs/prd` 本地确认，再发布 PRD Issue（含状态策略、页面清单、app-shell）          |
| 6   | `to-issues`                     | 工程  | 以 PRD 页面清单为 SSOT 拆垂直切片 + Design Issue；Issue 含 PRD 绑定与 States 矩阵 |
| 7   | `tdd`                           | 工程  | 编码前 PRD 必检预检 → 红-绿-重构垂直切片                                       |
| 8   | `diagnose`                      | 工程  | 有纪律的排错循环                                                        |
| 9   | `triage`                        | 工程  | Issue 状态机分拣 + Agent 简报（原样复制 PRD 必读）                             |
| 10  | `improve-codebase-architecture` | 工程  | 找“加深模块”的架构重构机会                                                  |
| 11  | `zoom-out`                      | 工程  | 拉高视角看陌生代码                                                       |


---



## 四、跟做：完整闭环演练

本节提供 **两个完整跟做用例**，走同一套 AI Coding 链路（项目初始化 → 需求对齐 → PRD → Issue → 分支 + TDD + push + CI + PR → 合并），但场景与复杂度递增。跟做时的节奏一览：

```mermaid
flowchart LR
  subgraph prep [正式开发前]
    R[建 GitHub 空仓库] --> S[/setup-skills/]
    S --> P[push main 初始提交]
    P --> G[/grill-with-docs/]
    G --> PRD[/to-prd docs/prd 确认/]
    PRD --> ISS[/to-issues/]
  end
  subgraph perIssue [每个 Issue 重复]
    TR[/triage ready-for-agent/] --> B[从 main 拉分支 issue/N-xxx]
    B --> T[/tdd PRD 必检预检/]
    T --> C[commit + push]
    C --> CI[GitHub Actions CI]
    CI --> PR[开 Pull Request]
    PR --> CHK[PR Checks 通过]
    CHK --> M[合并进 main]
    M --> TR
  end
  prep --> perIssue
```




| 用例      | 项目                               | 适合谁                                           | Issue 跟踪      | 代码托管与合并方式                                  |
| ------- | -------------------------------- | --------------------------------------------- | ------------- | ------------------------------------------ |
| **4.1** | 命令行 `todo-cli`                   | 第一次跟做、想最快跑通闭环                                 | GitHub Issues | 每 Issue 一分支 → push → CI → PR → 合并          |
| **4.2** | 全栈预约核销 `shop-book`（宠物洗护门店预约核销系统） | 已跑通 A，想练 后端 API 服务 + Web 管理后台 + 移动端（小程序） 多端协作 | GitHub Issues | Monorepo，每 Issue 一分支 → push → CI → PR → 合并 |




### 4.1 命令行待办清单 `todo-cli`



#### 示例项目长什么样（v1 目标）


| 能力   | 命令示例             | 说明                                                 |
| ---- | ---------------- | -------------------------------------------------- |
| 添加待办 | `todo add "买牛奶"` | 创建一条 **待办（Todo）**                                  |
| 列出待办 | `todo list`      | 显示全部 **待办（Todo）**，区分 **未完成（Open）** / **已完成（Done）** |
| 标记完成 | `todo done 1`    | 按序号把待办标为完成                                         |


**v1 故意不做**（写在 PRD 的 Out of scope 里）：Web 界面、多用户、云同步、数据库——先用 JSON 文件落盘即可。

技术栈可交给智能体推荐，也可以在交互中指定。

#### 阶段 1：创建GitHub及本地仓库、项目初始配置 — `/setup-skills`

**先在 GitHub Web 端创建空仓库** `todo-cli`（不勾选 README），再本地建仓：

```bash
# 1. 新建空目录并初始化 git
mkdir todo-cli && cd todo-cli
git init

# 2. 用 Cursor 打开这个文件夹
cursor .
```

然后再进行项目设置，它会依次问你 Issue 跟踪器、Triage 标签、领域文档布局（**UI 编码模式不在此步配置**，改在 `/grill-with-docs` 中选定）。

**自然语言（在 Cursor 里说）**：

```bash
/setup-skills
```


| 步骤  | 问什么           | 小白怎么选                                                                                |
| --- | ------------- | ------------------------------------------------------------------------------------ |
| A   | Issue 跟踪器放哪？  | **跟做推荐 GitHub**（用 GitHub 跟踪 + PR 更可审查）；GitLab 仓库选 GitLab；纯离线练手可选 Local markdown（不建议） |
| B   | Triage 标签叫什么？ | 第一次用 → 接受默认；有 UI 项目后续会用到 `design-input` 类别标签                                         |
| C   | 领域文档放哪？       | 默认根目录 `CONTEXT.md` + `docs/adr/`                                                     |


完成后会在项目里生成：

```
你的项目/
├── AGENTS.md 或 CLAUDE.md    ← 增加 Agent 技能配置块，Cursor 中使用 AGENTS.md
└── docs/agents/
    ├── issue-tracker.md      ← Issue 跟踪方式
    ├── triage-labels.md      ← 标签词汇表
    └── domain.md             ← 领域文档布局说明
```

**每个仓库只需跑一次**。以后改配置，直接编辑 `docs/agents/*.md` 即可。**最后完成 GitHub 推送**，可以通过指令也可自然语言，推荐全程自然语言交互。

**输入指令（不推荐）**：

```bash
# 依次运行如下指令
git remote add origin git@github.com:<你的用户名>/todo-cli.git
git add docs/ AGENTS.md CLAUDE.md 2>/dev/null; git add -A
git commit -m "chore: initial project setup"
git branch -M main
git push -u origin main
```

**自然语言（在 Cursor 里说）**：

```
请关联 GitHub 远程 git@github.com:<你的用户名>/todo-cli.git，
提交并首次 push 到 main。
```



#### 阶段 2：开工前对齐 — `/grill-with-docs`

**自然语言（在 Cursor 里说）**：

```
/grill-with-docs

我想从零做一个命令行待办清单 todo-cli，v1 只要：添加待办、列出待办、标记完成。
数据先存本地 JSON 文件。请拷问我直到方案清晰。
```

**你会经历什么：**

1. 智能体**一次只问一个问题**，并给出推荐答案
2. **固定拷问顺序**：领域规格 → 技术规格（14 项技术栈基线，值得 ADR 的决策写入 `docs/adr/`）→ UI 规格（本用例为 CLI，会选定 **headless（无可视化 UI）** 模式，不创建 `docs/design/`）
3. 逼你把模糊词变成术语
4. 每敲定一个术语，会**当场创建并写入** `CONTEXT.md`（空仓库里第一份领域文档）
5. 遇到难反悔的抉择会写 **ADR**，如：`docs/adr/0001-v1-cli-only-no-web.md`

**你要做的：**

- 认真回答每个问题；不确定就说“接受你的建议”
- `CONTEXT.md` 每更新一次就扫一眼——从零建项目时，这份文件就是你的“宪法”
- **仍然不要写代码**；没有术语表就开工，后面命名和测试会全线跑偏

**确认后，自然语言（在 Cursor 里说）**：

```
提交并 push 到 main。
```



#### 阶段 3：沉淀需求 — `/to-prd`

对齐后，**自然语言（在 Cursor 里说）：**

```
/to-prd

把 todo-cli v1 的讨论整理成 PRD。
```

智能体会**先在** `docs/prd/` **目录生成本地 PRD 草稿**供你确认和调整（CLI 项目为 headless（无可视化 UI），无需「状态策略」与页面清单）。确认无误后，再将 PRD 发布到 GitHub Issue。到 GitHub 仓库的 **Issues** 页核对 PRD Issue 是否已生成以及调整。也可直接自然对话询问进度。

**自然语言（在 Cursor 里说）**：

```
请帮我在 GitHub Issues 里确认 PRD Issue 是否已创建，并列出标题与编号。
```

**确认后，自然语言（在 Cursor 里说）**：

```
提交并 push 到 main。
```



#### 阶段 4：拆任务 — `/to-issues`

从零构建时，**强烈建议拆 Issue**，避免一次性让智能体“搭完整项目”。

**自然语言（在 Cursor 里说）**：

```
/to-issues

按垂直切片拆 todo-cli v1 PRD。
```

期望拆出类似这样的切片（每个都能单独跑通、单独验收）：


| Issue | 垂直切片                | 验收方式                                |
| ----- | ------------------- | ----------------------------------- |
| #1    | PRD 文档              | GitHub 上 PRD Issue 已发布              |
| #2    | 项目脚手架 + `todo add`  | `todo add "买牛奶"` 后数据写入 `todos.json` |
| #3    | `todo list`         | 能列出待办并区分 Open / Done                |
| #4    | `todo done <index>` | 指定序号可标为完成，`list` 可见状态变化             |


每个功能 Issue 正文含 **PRD 绑定**（Seam + **PRD 必读 3 项** + 覆盖用户故事）和 **验收标准**（每条含 **PRD 依据**），Issue **不重复** PRD 全文。

**不要**拆成“#1 写所有测试、#2 写所有实现”——那是水平切片，和 `/tdd` 的节奏冲突。

拆完后在 GitHub **Issues** 页核对条数与验收标准。确认后会按依赖顺序在 GitHub 创建 issue。

**自然语言（在 Cursor 里说）**：

```
确认拆分合理，创建issue。
```



#### 阶段 5：写代码 — 分支 + `/triage` + `/tdd` + PR

从 **Issue #2** 开始（Issue #1 为 PRD 文档），**每个 Issue 走一遍“分拣 → 拉分支 → TDD → push → CI → PR → 合并”**。

**步骤 0：分拣 Issue（若尚未** `ready-for-agent`**）**

`/to-issues` 已正确贴标签时可跳过。否则：

```
/triage

将 todo-cli Issue #[num] 推到 ready-for-agent，写 Agent 简报。（或直接在 Issue 跟踪器中手动操作）
```

**步骤 1：为 Issue #2 建分支**

**输入指令（不推荐）**：

```bash
git checkout main && git pull origin main
git checkout -b issue/2-todo-list
```

**自然语言（在 Cursor 里说）**：

```
从最新 main 创建新分支，准备实现 todo-cli 的 GitHub Issue #[num]。
```

**步骤 2：在当前对话或新对话里跑** `/tdd`

**自然语言（在 Cursor 里说）**：

```
/tdd

实现该 Issue。
```

`/tdd` 会先按 issue「**PRD 必读**」3 项打开 PRD 对应段落，再进入红-绿-重构循环；每个 RED 循环按验收标准的 **PRD 依据** 精读 PRD。

**第一个切片的 TDD 节奏示例：**

```
RED   → 测试：todos.json 里有两条 Open 待办，执行 list 输出两条且标为 Open
GREEN → 实现：读取 todos.json 并格式化输出
RED   → 测试：其中一条标为 Done 后，list 能区分 Open / Done
GREEN → 实现：按状态展示逻辑
```

`/tdd` 强制你遵守的节奏：

```
✅ 正确（垂直切片）：
  Issue #1：测试 1 → 实现 1 → 通过 → … → add 命令可用
  Issue #2：测试 1 → 实现 1 → 通过 → … → list 命令可用
  Issue #3：…

❌ 错误（水平切片）：
  先搭完整目录 + 写完全部测试 + 再一次性实现三个命令
```

每轮只加**刚好让当前测试通过**的代码。在TDD结束后，可直接本地运行服务测试

**自然语言（在 Cursor 里说）**：

```
在本地运行服务
```

**步骤 3：接入 CI**

Issue #2 会产出测试脚本——**在同一条分支上**新增 GitHub Actions workflow，让 push 后云端自动跑。

**自然语言（在 Cursor 里说）**：

```
【首次设置即可】设置任意分支 push 和 PR 时都（不）要跑 CI。
```

**步骤 4：push 并等 CI 变绿**

**输入指令（不推荐）**：

```bash
git add .
git commit -m "feat: todo list command and CI

Closes #2"
git push -u origin issue/2-todo-list
```

**自然语言（在 Cursor 里说）**：

```
提交并 push。
```

push 后会自动运行 CI 检测，打开 GitHub → **Actions**，确认 workflow **CI** 最近一次运行是 ✅。若失败，把 Actions 日志贴给 `/diagnose`。完成之后，还未将代码合并到 main，需要提交 PR。

**自然语言（在 Cursor 里说）**：

```
创建 PR。
```

PR 后会自动运行 CI 检测，打开 GitHub → **Actions**，确认 workflow **CI** 最近一次运行是 ✅。若失败，把 Actions 日志贴给 `/diagnose`。也可以通过自然语言查看 CI 状态。

**自然语言（在 Cursor 里说）**：

```
请确认 CI 是否通过；失败则摘要原因并建议修复。
```

PR 完成之后，将代码合并到 main。

**自然语言（在 Cursor 里说）**：

```
合并该 PR 到 main，不要删除该分支，并确认该 Issue 已关闭。
```

PR 页 **Checks** 全绿后，再 **Merge pull request** 进 `main`。之后 Issue #3、#4 等重复：拉新分支 → `/tdd` → push → **等 CI** → PR → 合并。会话更干净，历史也可审查。

#### 阶段 6：出问题时 — `/diagnose`

从零写代码时，常见卡点举例：

**自然语言（在 Cursor 里说）**：

```
/diagnose

todos.json 为空时 todo list 崩溃，按诊断循环修。
```

它会带你走：复现 → 缩小范围 → 提假设 → 观测 → 验证 → 修 → 补回归测试。**不要让它一上来就猜着改。**

#### 阶段 7：v1 跑通后的维护 — `/improve-codebase-architecture`

可以在 v1 全部完成后或每隔 3–4 天就运行如下 Skill 进行代码维护：

```
/improve-codebase-architecture

todo-cli v1 已跑通，看看有没有可以把模块“加深”、接口收窄的地方。
```

这一步在**新项目第一天**就可以做，不必等“变成泥球”——**从第一版就投资设计**，而不是先胡乱堆功能再还债。

可选：若对调用关系不熟，可先 `/zoom-out` 画系统图

**自然语言（在 Cursor 里说）：**

```
/zoom-out

画出 todo-cli 模块关系，不写代码。
```



### 4.2 全栈门店预约核销 `shop-book`（后端 + 管理端 + 微信小程序）

从零构建 **多端协作** 的门店预约系统：顾客在微信小程序选时段下单，店员在 Web 管理后台查看预约并 **核销** 到店。

#### 示例项目长什么样（v1 目标）

**核心业务流（v1 只走一条主路径）：**

```
顾客小程序选“精细洗护服务”→ 选可约时段 → 提交预约（Pending）
        ↓
店员管理端看到新预约 → 顾客到店 → 店员点击“核销”→ 状态变 Verified
        ↓
顾客小程序“我的预约”里该条显示“已核销”
```



#### 阶段 1：创建GitHub及本地仓库、项目初始配置 — `/setup-skills`

**先在 GitHub Web 端创建空仓库** `shop-book`（不勾选 README），再本地建仓：

```bash
# 1. 新建空目录并初始化 git
mkdir shop-book && cd shop-book
git init

# 2. 用 Cursor 打开这个文件夹
cursor .
```

然后再进行项目设置，它会依次问你 Issue 跟踪器、Triage 标签、领域文档布局（**UI 编码模式不在此步配置**，改在 `/grill-with-docs` 中选定）。

**自然语言（在 Cursor 里说）**：

```bash
/setup-skills
```


| 步骤  | 问什么           | 小白怎么选                                                 |
| --- | ------------- | ----------------------------------------------------- |
| A   | Issue 跟踪器放哪？  | **跟做推荐 GitHub**（多端 Issue 多、迭代长，用 GitHub 跟踪 + PR 更可审查） |
| B   | Triage 标签叫什么？ | 第一次用 → 接受默认；有 UI 项目后续会用到 `design-input` 类别标签          |
| C   | 领域文档放哪？       | 默认根目录 `CONTEXT.md` + `docs/adr/`，三端共用                 |


完成后会在项目里生成：

```
你的项目/
├── AGENTS.md 或 CLAUDE.md    ← 增加 Agent 技能配置块，Cursor 中使用 AGENTS.md
└── docs/agents/
    ├── issue-tracker.md      ← Issue 跟踪方式
    ├── triage-labels.md      ← 标签词汇表
    └── domain.md             ← 领域文档布局说明
```

**每个仓库只需跑一次**。以后改配置，直接编辑 `docs/agents/*.md` 即可。**最后完成 GitHub 推送**，可以通过指令也可自然语言，推荐全程自然语言交互。

**输入指令（不推荐）**：

```bash
# 依次运行如下指令
git remote add origin git@github.com:<你的用户名>/shop-book.git
git add docs/ AGENTS.md CLAUDE.md 2>/dev/null; git add -A
git commit -m "chore: initial project setup"
git branch -M main
git push -u origin main
```

**自然语言（在 Cursor 里说）**：

```
请关联 GitHub 远程 git@github.com:<你的用户名>/shop-book.git，
提交并首次 push 到 main。
```



#### 阶段 2：开工前对齐 — `/grill-with-docs`

**自然语言（在 Cursor 里说）**：

```
/grill-with-docs

我想从零做一个宠物洗护门店预约核销系统 shop-book，v1 包含：
- 后端 REST API
- Web 管理端（店员查看预约、核销）
- 微信小程序（顾客选时段预约、看核销状态）

主路径：顾客预约 → 店员核销 → 小程序状态更新。
请拷问我直到方案清晰。
```

**你会经历什么：**

1. 智能体**一次只问一个问题**
2. **固定拷问顺序**：领域规格 → 技术规格（14 项技术栈基线）→ UI 规格（选定 UI 编码模式 + 品牌视觉规范）
3. 逼你把模糊词变成术语
4. 每敲定一个术语，会**当场创建并写入** `CONTEXT.md`（空仓库里第一份领域文档）
5. 遇到难反悔的抉择会写 **ADR**，如：`docs/adr/0001-booking-state-pending-verified-only.md`
6. **UI 模式拷问**（三选一，写入 `docs/design/DESIGN.md` 文首）：


| 模式                        | 何时选                              | 设计输入                             |
| ------------------------- | -------------------------------- | -------------------------------- |
| **headless（无可视化 UI）**     | 纯 API / CLI / 库，无可视化页面           | 不创建 `docs/design/`               |
| **spec-driven（规范驱动 UI）**  | 有 Web/小程序/H5 页面，**永不**提供 PNG 设计稿 | `DESIGN.md` + PRD 页面清单「UI 设计描述」  |
| **mockup-driven（稿驱动 UI）** | 有页面，**全部** UI 页须提供 PNG 设计稿       | `DESIGN.md` + `references/*.png` |


```mermaid
flowchart TD
    Q1{"有没有可视化页面?"}
    Q1 -->|否| M1["headless（无可视化 UI）"]
    Q1 -->|是| Q2{"会不会提供 UI 设计稿 PNG?"}
    Q2 -->|否| M2["spec-driven（规范驱动 UI）"]
    Q2 -->|是| M3["mockup-driven（稿驱动 UI）（全部 UI 页须提供 PNG）"]
```



1. **品牌视觉规范**确认后，惰性创建 `docs/design/DESIGN.md`（Token、通用 UI 原语 §5、宜忌 §6）；多端时还会创建 `docs/design/platforms.md`
2. **功能页面规格不进 DESIGN.md**——mockup-driven（稿驱动 UI） 由 PNG 承载；spec-driven（规范驱动 UI） 在 `/to-prd` 阶段写入 PRD 页面清单

**你要做的：**

- 认真回答每个问题；不确定就说“接受你的建议”
- `CONTEXT.md` 每更新一次就扫一眼——从零建项目时，这份文件就是你的“宪法”
- **仍然不要写代码**；没有术语表就开工，后面命名和测试会全线跑偏

**确认后，自然语言（在 Cursor 里说）**：

```
提交并 push 到 main。
```



#### 阶段 3：沉淀需求 — `/to-prd`

对齐后，**自然语言（在 Cursor 里说）：**

```
/to-prd

把shop-book v1 的讨论整理成 PRD。
```

智能体会**先在** `docs/prd/` **目录生成本地 PRD 草稿**供你确认。非 headless（无可视化 UI） PRD **须含**：

- `状态策略` — 全局 loading / empty / error 等约定（位于页面清单之前）
- **各端** `app-shell` **置顶** — 每个 `platform-id` 的第一条页面清单项必须是整体框架页
- **页面清单** — 每页 `page-id` + **UI 设计描述**（spec-driven（规范驱动 UI） 为编码 SSOT；mockup-driven（稿驱动 UI） 额外标注默认态设计稿计划）
- **用户故事 ↔ 页面映射表**

确认无误后，再将 PRD 发布到 GitHub Issue。到 GitHub 仓库的 **Issues** 页核对 PRD Issue 是否已生成以及调整。也可直接自然对话询问进度。

**自然语言（在 Cursor 里说）**：

```
请帮我在 GitHub Issues 里确认 PRD Issue 是否已创建，并列出标题与编号。
```

**确认后，自然语言（在 Cursor 里说）**：

```
提交并 push 到 main。
```



#### 阶段 4：拆任务 — `/to-issues`

从零构建时，**强烈建议拆 Issue**，避免一次性让智能体“搭完整项目”。

**自然语言（在 Cursor 里说）**：

```
/to-issues

按垂直切片拆 shop-book v1 PRD。
```

**以 PRD 页面清单为 SSOT，不再重新拆 UI 页**。除 **功能垂直切片** 外，本用例还需拆：


| Issue 类型                     | 说明                                                     | 初始状态                     |
| ---------------------------- | ------------------------------------------------------ | ------------------------ |
| **Design Issue** `#D-global` | 验收关闭 `DESIGN.md`（多端时含 `platforms.md`）                  | `ready-for-agent`        |
| **Design Issue** `#D-xxx`    | 仅 mockup-driven（稿驱动 UI）：每页一张默认态 PNG                    | 设计稿齐 → `ready-for-agent` |
| **UI Issue**                 | 一个 `page-id` 的完整逻辑态；含 **PRD 必读 7 项** + **States 矩阵**   | 输入齐 → `ready-for-agent`  |
| **功能 Issue**                 | API / schema 等；含 **PRD 必读 3 项** + 验收标准（每条含 **PRD 依据**） | 规格齐 → `ready-for-agent`  |


**Design Issue 分层与依赖**：

```
#D-global（验收 DESIGN.md）
    ↓
#D-xxx（仅 mockup-driven（稿驱动 UI）：每页默认态 PNG）
    ↓
app-shell UI Issue（各端整体框架页，功能页之前）
    ↓
功能 UI Issue / API 切片（API 可与 #D-global 并行）
```

- **spec-driven（规范驱动 UI）**：不开 `#D-xxx`；布局 SSOT 在 PRD 页面清单「UI 设计描述」
- 同端功能页 UI Issue **必须依赖** 该端 `app-shell` UI Issue

拆完后在 GitHub **Issues** 页核对条数与验收标准。确认后会按依赖顺序在 GitHub 创建 issue。

**自然语言（在 Cursor 里说）**：

```
确认拆分合理，创建issue。
```



#### 阶段 5：写代码 — 分支 + `/triage` + `/tdd` + PR

从 **Design Issue / 首个功能 Issue** 开始，**每个 Issue 走一遍“分拣 → 拉分支 → TDD → push → CI → PR → 合并”**。后端 API 切片可与 `#D-global` **并行**——后端不依赖设计稿。

**步骤 0：分拣 Issue（若尚未** `ready-for-agent`**）**

```
/triage

将 shop-book Issue #[num] 推到 ready-for-agent，Agent 简报原样复制 PRD 必读。（或直接在 Issue 跟踪器中手动操作）
```

**步骤 1：为 Issue 建分支**

**输入指令（不推荐）**：

```bash
git checkout main && git pull origin main
git checkout -b issue/2-slot-api
```

**自然语言（在 Cursor 里说）**：

```
从最新 main 创建新分支，准备实现 shop-book 的 GitHub Issue #[num]。
```

**步骤 2：在当前对话或新对话里跑** `/tdd`

**自然语言（在 Cursor 里说）**：

```
/tdd

实现该 Issue。
```

- **功能 Issue**：编码前按「PRD 必读」3 项打开 PRD；RED 循环按验收标准 **PRD 依据** 精读
- **UI Issue**：编码前按「PRD 必读」7 项打开 PRD / design；RED 循环按 **States 矩阵**「PRD 来源」列精读；测试全绿后 PR 还须过**设计 QA**

**步骤 3：接入 CI**

Issue #2 会产出测试脚本——**在同一条分支上**会新增 GitHub Actions workflow，让 push 后云端自动跑。

**自然语言（在 Cursor 里说）**：

```
【首次设置即可】创建CI，并设置任意分支 push 和 PR 时都（不）要跑 CI。
```

**步骤 4：push 并等 CI 变绿**

**输入指令（不推荐）**：

```bash
git add .
git commit -m "feat: slot API and CI

Closes #2"
git push -u origin issue/2-slot-api
```

**自然语言（在 Cursor 里说）**：

```
提交并 push。
```

push 后会自动运行 CI 检测，打开 GitHub → **Actions**，确认 workflow **CI** 最近一次运行是 ✅。若失败，把 Actions 日志贴给 `/diagnose`。完成之后，还未将代码合并到 main，需要提交 PR。

**自然语言（在 Cursor 里说）**：

```
创建 PR。
```

PR 后会自动运行 CI 检测，打开 GitHub → **Actions**，确认 workflow **CI** 最近一次运行是 ✅。若失败，把 Actions 日志贴给 `/diagnose`。也可以通过自然语言查看 CI 状态。

**自然语言（在 Cursor 里说）**：

```
请确认 CI 是否通过；失败则摘要原因并建议修复。
```

PR 完成之后，将代码合并到 main。

**自然语言（在 Cursor 里说）**：

```
合并该 PR 到 main，不要删除该分支，并确认该 Issue 已关闭。
```

PR 页 **Checks** 全绿后，再合并进 `main`。之后其他 Issue 重复：拉新分支 → `/tdd` → push → **等 CI** → PR → 合并。会话更干净，历史也可审查。

#### 阶段 6：出问题时 — `/diagnose`

从零写代码时，常见卡点举例：

**自然语言（在 Cursor 里说）**：

```
/diagnose

管理端显示核销成功，但小程序“我的预约”仍是 Pending。
请从 API 响应、admin 请求、小程序缓存三条线按诊断循环排查。
```

它会带你走：复现 → 缩小范围 → 提假设 → 观测 → 验证 → 修 → 补回归测试。**不要让它一上来就猜着改。**

#### 阶段 7：v1 跑通后的维护 — `/improve-codebase-architecture`

可以在 v1 全部完成后或每隔 3–4 天就运行如下 Skill 进行代码维护：

```
/improve-codebase-architecture

shop-book v1 已跑通，看看有没有可以把模块“加深”、接口收窄的地方。
```

这一步在**新项目第一天**就可以做，不必等“变成泥球”——**从第一版就投资设计**，而不是先胡乱堆功能再还债。

可选：若对调用关系不熟，可先 `/zoom-out` 画系统图

**自然语言（在 Cursor 里说）：**

```
/zoom-out

画出 shop-book 三端与 API 的模块关系，不写代码。
```

---



## 五、核心术语

> 本节汇总文档里反复出现、但容易懵的概念。


| 术语           | 一句话                                | 对应命令 / 文件                                  |
| ------------ | ---------------------------------- | ------------------------------------------ |
| `CONTEXT.md` | 领域术语表，统一人和 AI 的用词                  | `/grill-with-docs`                         |
| ADR          | 架构决策记录，只记难反悔的技术抉择                  | `/grill-with-docs` → `docs/adr/`           |
| `DESIGN.md`  | 品牌视觉 SSOT：Token、通用 UI 原语、宜忌        | `/grill-with-docs` → `docs/design/`        |
| PRD 绑定       | Issue 用编号清单路由 Agent 到 PRD 段落，不重复全文 | `/to-issues` → Issue 正文                    |
| PRD 必读       | PRD 绑定中的强制阅读清单（UI 7 项 / 功能 3 项）    | `/triage`、`/tdd`                           |
| States 矩阵    | UI Issue 每态一行，含 PRD 来源 + 可观察预期     | `/to-issues` → `/tdd` RED 循环               |
| app-shell    | 各端整体框架页，功能页 UI Issue 的前置依赖         | `/to-prd` 页面清单 → `/to-issues`              |
| TDD          | 测试驱动开发，红-绿-重构垂直切片                  | `/tdd`                                     |
| 软件熵增         | 代码库随时间自然变乱的趋势                      | `/improve-codebase-architecture`           |
| Triage 标签    | Issue 分拣的状态标记                      | `/triage` → `docs/agents/triage-labels.md` |
| AFK / HITL   | 智能体能否无人值守完成                        | `/triage`、`/to-issues`                     |
| Monorepo     | 多个子项目共用一个 Git 仓库                   | 用例 B `shop-book` → `docs/adr/`             |
| pnpm         | 包管理器，Monorepo 常用搭档                 | `pnpm-workspace.yaml`、`pnpm test`          |
| CI           | 代码 push 后自动跑测试的检查                  | GitHub Actions → `.github/workflows/`      |
| PR           | 合并前审查代码变更的请求                       | `gh pr create`、GitHub Pull Request 页       |




### 5.1 `CONTEXT.md` — 不是需求文档，是术语表

**只放**：领域名词、定义、要避免的模糊说法、概念之间的关系。  
**不要放**：接口设计、表结构、技术选型（那些进 ADR 或代码）、品牌视觉规格（那些进 `docs/design/DESIGN.md`）。

好的条目长这样（`todo-cli` 跟做后的 `CONTEXT.md` 片段）：

```markdown
**门店 (Shop)**：
提供可预约时段的物理网点。v1 系统仅服务一家门店，无门店选择与切换；营业时间 10:00–20:00，全年无休。
_避免使用_: 店铺 (Store), 网点 (Outlet)

**时段 (TimeSlot)**：
系统按门店营业时间自动生成的可预约时间窗口。v1 粒度 60 分钟、每时段容量 5 人、开放未来 14 天；含剩余名额，顾客预约占用 1 个名额。
_避免使用_: 时间段 (Period), 排期 (Schedule)
```



### 5.2 ADR — 只记“难反悔的抉择”

**ADR**（Architecture Decision Record，架构决策记录）用一篇简短 Markdown 记录：**在某个技术/架构问题上，团队最终选了什么、为什么**。

代码能说明“做了什么”，ADR 回答“为什么这么做”——半年后新人看到实现，不会纳闷“为什么用 JSON 而不是数据库？”。

**和** `CONTEXT.md` **的分工**：


| 文档                      | 记什么                    | 不记什么            |
| ----------------------- | ---------------------- | --------------- |
| `CONTEXT.md`            | 领域术语、概念定义              | 技术选型、接口设计、视觉规格  |
| `docs/adr/`             | 难反悔的技术/架构抉择            | 日常业务名词、品牌视觉     |
| `docs/design/DESIGN.md` | 品牌视觉 Token、通用 UI 原语、宜忌 | 页面名、业务字段布局、领域术语 |


**三条才写**，否则跳过：

1. **难反悔** — 以后改掉成本高
2. **不读上下文会惊讶** — 后人会问“为什么这样？”
3. **真实权衡** — 有过备选方案，选了其中一个

ADR 不是项目第一天就必须有的——`/grill-with-docs` 在方案讨论中**惰性创建**，只有真正敲定难反悔的抉择时才写入 `docs/adr/`。长这样（`docs/adr/0001-typescript-monorepo.md` ）：

```markdown
# 全 TypeScript Monorepo 架构

shop-book v1 包含 REST API、Web 管理端与微信小程序三端，共享预约/时段/状态等领域类型。采用 pnpm workspace + Turborepo 组织 `apps/api`、`apps/admin-web`、`apps/miniapp` 与 `packages/shared`，统一 TypeScript 工具链，避免 DTO 在三端漂移。曾考虑微信原生小程序与 Vue 管理端，但为最大化类型复用与协作效率，选择 Taro 3 + React 与 React 管理端同栈。

```



### 5.3 TDD — 测试驱动开发

**TDD**（Test-Driven Development），**先写测试，再写实现**，用测试当“行为规格说明书”。

**红-绿-重构循环**：

1. **红（RED）** — 写一个会失败的测试，描述系统应有的行为
2. **绿（GREEN）** — 写**刚好让该测试通过**的最少代码
3. **重构（REFACTOR）** — 测试全绿后再整理结构，测试继续通过

**测行为，不测实现**：通过公开接口验证可观察结果，而不是测私有函数或内部数据结构。这样重构时，行为不变则测试不应挂。

**垂直切片 vs 水平切片**（`/tdd` 强制垂直）：

```
❌ 错误（水平切片）：
  先写 test1, test2, test3 → 再写 impl1, impl2, impl3

✅ 正确（垂直切片）：
  test1 → impl1 → 通过 → test2 → impl2 → 通过 → …
```

**编码前 PRD 必检**（V1.2 新增门禁）：


| Issue 类型                   | 预检清单                                                                   | RED 循环依据               |
| -------------------------- | ---------------------------------------------------------------------- | ---------------------- |
| **UI 实现**                  | PRD 必读 **7 项** + `DESIGN.md`（+ 多端 `platforms.md`、mockup `references/`） | States 矩阵 **PRD 来源** 列 |
| **功能 / headless（无可视化 UI）** | PRD 必读 **3 项**                                                         | 验收标准 **PRD 依据**        |


Issue 非 `ready-for-agent` 或依赖未满足 → **停止**，不要 `/tdd`。

```
RED   → 测试：执行 add 后，todos.json 里多一条 Open 状态的待办
GREEN → 实现：最小 CLI 解析 + 文件写入
RED   → 测试：重复 add 两条，文件里有两条独立待办（各有 Index）
GREEN → 实现：自增序号逻辑
```



### 5.4 软件熵增 — 代码库为什么会变成泥球

**软件熵增**借用了物理学“熵”的比喻：系统里**无序会随时间自然增加**，除非主动投入能量去整理。

对应到代码：功能可能还能跑，但理解成本、修改成本、出错概率会持续上升—代码“越改越不敢动”就是典型症状。

**常见表现**：

- 模块边界模糊，改一处牵动多处（泥球代码）
- 同样逻辑 copy-paste 散落各处
- 命名和概念漂移，新人读不懂
- 测试变脆或缺失，不敢重构
- “先凑合能跑”的临时方案变成永久方案

**为什么会加速**：需求变化、时间压力、人员变动，以及 **AI 加速写代码**——如果缺少 `CONTEXT.md`、ADR、TDD 和定期架构审查，智能体会更快把复杂度堆上去。

**对抗手段**（本指南里的“负熵工作”）：


| 手段                               | 作用                     |
| -------------------------------- | ---------------------- |
| `CONTEXT.md`                     | 固定领域语言，防概念漂移           |
| ADR                              | 记录关键决策，避免后人误改或重复争论     |
| `/tdd`                           | 用行为测试锁住接口，重构有安全网       |
| `/grill-with-docs`               | 开工前对齐，减少边写边猜           |
| `/improve-codebase-architecture` | 定期做“加深模块”重构            |
| `/zoom-out`                      | 从系统视角理解代码，避免局部补丁制造全局混乱 |




### 5.5 Triage 标签 — Issue 现在该谁处理

**Triage**（分拣）= 把进来的 bug、需求分类、补齐信息，决定下一步交给谁。**Triage 标签**是这套流程的**状态机记号**，词汇表写在 `docs/agents/triage-labels.md`。

每个 Issue 通常带**两类**标签：

**类别标签**（是什么）：


| 标签             | 含义                                     |
| -------------- | -------------------------------------- |
| `bug`          | 有东西坏了                                  |
| `enhancement`  | 新功能或改进                                 |
| `design-input` | Design Issue：只产出 `docs/design/`，不写业务页面 |


**状态标签**（该怎么处理）—默认五个，另加 UI 场景语义：


| 标签                | 含义                                                        |
| ----------------- | --------------------------------------------------------- |
| `needs-triage`    | 待维护者评估（新 Issue 默认入口）                                      |
| `needs-info`      | 信息不够，等报告者补充                                               |
| `ready-for-agent` | 规格齐全，可交给 AFK 智能体（**UI Issue：设计资料也已齐**）                    |
| `ready-for-human` | 需要人来做；**UI Issue：常表示缺** `references/` **或人工未审，不可** `/tdd` |
| `wontfix`         | 不做，关闭                                                     |


**UI 实现 Issue 门禁**（spec-driven（规范驱动 UI） / mockup-driven（稿驱动 UI））：

- **PRD 绑定** 含 **PRD 必读 7 项** + 壳层关系 + 覆盖用户故事 `US-n`
- **States 矩阵** 每态一行，**PRD 来源** 为可定位字符串
- `DESIGN.md` 就绪；多端时 `platforms.md` 就绪
- **验收标准** 分三类：功能 / UI 行为 / 设计 QA
- mockup 额外检查 `references/` 默认态 PNG
- 功能页（`page-id` ≠ `app-shell`）须依赖同端 app-shell issue

**功能 / headless（无可视化 UI） Issue 门禁**：

- **PRD 绑定** 含 **PRD 必读 3 项** + Seam + 覆盖用户故事
- **验收标准** 每条为可观察行为，含 **PRD 依据**

> `/to-issues` 已正确贴标签时，不必每张 Issue 再跑 `/triage`。典型仍需 `/triage` 的场景：用户随手提的无标签 Issue、需写 Agent 简报。

**移至** `ready-for-agent` **时**：Agent 简报须从 issue 正文 **PRD 必读原样复制**「实现前必读」，**不要**在简报中补全或改写。

**状态流转**：

```
新 Issue → needs-triage → needs-info / ready-for-agent / ready-for-human / wontfix
              ↑___________________|
              （报告者补充信息后重新评估）
```



### 5.6 AFK / HITL — 智能体能不能“你走开它自己干”

**AFK**（Away From Keyboard）原意是“人不在键盘前”。在这套体系里指：**智能体可以无人值守、按规格自主完成的工作**—你不在旁边盯着，它也能实现并验收。

**HITL**（Human In The Loop）是反面：需要人中途参与—架构拍板、UI 设计评审、外部账号、主观判断等。


| 类型       | 含义            | 对应 Triage 标签      |
| -------- | ------------- | ----------------- |
| **AFK**  | 规格齐全，智能体可独立完成 | `ready-for-agent` |
| **HITL** | 必须人来处理        | `ready-for-human` |


`/to-issues` 拆垂直切片时会标注 HITL/AFK，原则：**能 AFK 就 AFK**。Issue 标成 `ready-for-agent` ，就表示 AFK 就绪—维护者可以离开，智能体用 `/tdd` 领取实现。

**典型无人值守链路**：

```
/triage 分拣 → ready-for-agent（Agent 简报含 PRD 必读）→ 你去做别的事 → AFK 智能体 /tdd 预检 PRD 必读 → 实现 Issue
```



### 5.7 Monorepo — 一个仓库装多个子项目

**Monorepo**（Monolithic Repository，单仓多包），**一个 Git 仓库里放多个相关子项目**（后端 API、Web 管理端、小程序、共享类型包等），而不是每个端单独开一个仓库。

**为什么用 Monorepo**：

- **共享术语和类型**：根目录一份 `CONTEXT.md`，`packages/shared` 里放三端共用的领域类型，改一处、各端同步
- **原子变更**：一次 PR 可以同时改 API 契约和小程序调用，不会出现“后端已合并、前端还没跟上”的跨仓脱节
- **统一 CI**：push 一次，所有包的测试一起跑

**和“多仓库（Multi-repo）”对比**：


| 方式           | 适合场景                 | 本指南用法          |
| ------------ | -------------------- | -------------- |
| 单仓库单项目       | 命令行工具、单一服务           | 用例 `todo-cli`  |
| **Monorepo** | 多端协作、共享领域模型          | 用例 `shop-book` |
| 多仓库          | 团队完全独立、发布节奏不同、权限严格隔离 | 本指南跟做不推荐新手起步用  |


`shop-book` 跟做示例布局：

```
shop-book/                      ← 一个 Git 仓库（Monorepo 根）
├── CONTEXT.md                  ← 三端共用术语表
├── docs/
│   ├── adr/
│   ├── prd/                    ← to-prd 本地确认草稿
│   └── design/                 ← DESIGN.md、platforms.md、references/
├── apps/
│   ├── api/                    ← 后端服务
│   ├── admin/                  ← Web 管理端
│   └── mini-program/           ← 微信小程序
├── packages/
│   ├── shared/                 ← 共享类型
│   └── design-tokens/          ← UI token
├── pnpm-workspace.yaml
└── package.json
```



### 5.8 pnpm — Monorepo 常用的包管理器

**pnpm** 是 Node.js 的**包管理器**（和 npm、yarn 同类），负责安装依赖、跑脚本、管理 workspace。

**为什么跟做里选 pnpm 而不是 npm**：

- **Workspace 原生支持**：通过 `pnpm-workspace.yaml` 声明 `apps/`*、*`packages/`，子包之间可以互相引用（如 `admin` 依赖 `shared`）
- **磁盘更省**：相同版本的包只存一份，Monorepo 子项目多时优势明显
- **安装更快**：大型 Monorepo 里通常比 npm 快

**Monorepo 里你会见到的文件**：


| 文件 / 命令                  | 作用                                            |
| ------------------------ | --------------------------------------------- |
| `pnpm-workspace.yaml`    | 声明哪些目录是 workspace 成员（如 `apps/`*、*`packages/`） |
| 根目录 `package.json`       | 定义 `pnpm test` 等根级脚本，统一跑所有子包测试                |
| 各子包 `package.json`       | 该子包自己的依赖和脚本（如 `apps/api/package.json`）        |
| `pnpm install`           | 在根目录执行，一次装齐所有子包依赖                             |
| `pnpm test`              | 在根目录执行，跑 workspace 里配置的测试                     |
| `pnpm --filter api test` | 只跑某一个子包的测试                                    |


**小白常见误区**：

- ❌ 在每个子目录分别 `npm install` — 会破坏 workspace 链接，应在**根目录**执行 `pnpm install`
- ❌ 混用 npm 和 pnpm — 只选一个并统一到底；本指南跟做统一用 pnpm



### 5.9 CI — push 之后自动跑测试

**CI**（Continuous Integration，持续集成），**每次提交代码后，由云端自动执行测试和检查**，不用你手动在本机再跑一遍才放心合并。

本指南跟做里，CI 具体指 **GitHub Actions**：你在 `.github/workflows/` 里放一个 workflow 文件（通常叫 `ci.yml`），配置“什么时候跑、跑什么命令”。

**典型触发时机**（跟做默认配置）：

- 任意分支 **push** 时
- 开 **PR** 时（PR 上也会再跑一遍）

**跟做闭环里的位置**：

```
本地 /tdd 测试通过 → git push → CI 自动跑 test → ✅ 变绿 → 开 PR → PR 上 CI 再跑 → 合并 main
```

**为什么要等 CI 变绿再合并**：

- 本机环境（Node 版本、依赖、操作系统）和 GitHub 云端可能不一致——CI 是**远程兜底**
- PR 页的 **Checks** 全绿，说明这次变更在干净环境里也能过，审查者（哪怕是你自己）有据可依
- CI 挂了时，把 Actions 日志贴给 `/diagnose`，比猜“我本地明明过了啊”高效得多

**跟做里你会看到的界面**：

- GitHub → **Actions** 页：查看每次 workflow 运行记录
- PR 页 → **Checks** 区域：该 PR 关联的 CI 是否通过

> **“CI 变绿”** = workflow 运行成功（✅），所有检查通过；**“CI 红了”** = 某步失败，需要修代码或修 workflow 后再 push。



### 5.10 PR — 合并前的代码审查请求

**PR**（Pull Request，拉取请求），**“我在这条分支上改好了，请审查并合并进主分支”** 的正式请求。GitHub 上合并代码进 `main` 的推荐方式不是直接 push 到 `main`，而是走 PR。

**跟做标准节奏**（每个 Issue 重复一次）：

```
1. /triage 推到 ready-for-agent（含 Agent 简报 / PRD 必读）
2. 从 main 拉分支 issue/N-xxx
3. /tdd 预检 PRD 必读 → 红绿循环 + 本地测试通过
4. git push
5. 等 CI ✅
6. 开 PR（关联 Issue，写 Closes #N；UI Issue 还须设计 QA）
7. PR Checks 全绿 → Merge pull request → Issue 自动关闭
```

**为什么建议开 PR**：


| 好处        | 说明                                       |
| --------- | ---------------------------------------- |
| 独立审查记录    | 每个垂直切片有清晰的 diff 和讨论，而不是 main 上一坨 commit  |
| CI 门禁     | PR 触发远程测试，合并前强制过检                        |
| 可回滚       | 某切片有问题， revert 单个 PR 即可，不必在 main 上考古     |
| 自动关 Issue | PR 描述里写 `Closes #2`，合并后 GitHub 自动关 Issue |


**PR 和 Issue 的关系**：

- **Issue** = “要做什么”（规格、验收标准）
- **PR** = “我做了什么”（代码 diff、测试结果）
- 理想状态：**一个 Issue 对应一个 PR**（一 Issue 一分支），合并后 Issue 关闭



### 5.11 PRD 绑定 — Issue 不重复 PRD 全文

**PRD 绑定**是 Issue 正文中的路由章节，把 Agent **指向**父 PRD 的正确段落，而不是把 PRD 全文抄进 Issue。


| Issue 类型                   | PRD 必读项数                                                          | 编码时打开什么                                     |
| -------------------------- | ----------------------------------------------------------------- | ------------------------------------------- |
| **UI 实现**                  | 7 项（页面清单全文、状态策略、用户故事、app-shell、DESIGN §5/§6、platforms、references） | 预检读 7 项；每个 RED 循环按 States 矩阵 **PRD 来源** 列精读 |
| **功能 / headless（无可视化 UI）** | 3 项（实现决策子项、测试决策子项、用户故事）                                           | 每个 RED 循环按验收标准 **PRD 依据** 打开 PRD 段落         |


**PRD 依据**（功能 Issue 验收标准括号内）与 **PRD 来源**（UI Issue States 矩阵列）是对称设计——都须为可定位字符串，如 `PRD 实现决策 › POST /bookings` 或 `PRD 页面清单 §booking-list「UI 设计描述」`。

### 5.12 UI 设计治理 — 非 headless（无可视化 UI） 的分层流水线

UI 设计不是 `/tdd` 里的即兴发挥，而是一套分层流水线：

**设计输入（三类文件）**：

```
docs/design/DESIGN.md          ← 品牌视觉 SSOT（grill 写入，#D-global 验收关闭）
docs/design/platforms.md       ← 多端时：platform-id 清单 + 组件库映射
docs/design/references/*.png   ← mockup-driven（稿驱动 UI） 每页默认态设计稿
```

**页面规格 SSOT 在 PRD**：

```
PRD「状态策略」              ← 全局 loading / empty / error 约定
PRD「页面清单」              ← page-id · UI 设计描述 · 变体段 · DESIGN 复用
```

**Design Issue 分层**：

```
#D-global（验收关闭 DESIGN.md；多端时含 platforms.md）
    ↓
#D-xxx（仅 mockup-driven（稿驱动 UI）：每页一张默认态 PNG）
    ↓
app-shell UI Issue（各端整体框架页，功能页之前）
    ↓
功能 UI Issue（ready-for-agent 后才能 /tdd）
```

- **spec-driven（规范驱动 UI）**：不开 `#D-xxx`；布局 SSOT 在 PRD 页面清单「UI 设计描述」
- **headless（无可视化 UI）**：不开任何 Design Issue
- API 切片可与 `#D-global` **并行**——后端不依赖设计稿

**UI Issue 验收标准分三类**：功能（CI / TDD）· UI 行为（CI / TDD）· 设计 QA（PR 人工；mockup 须列默认态对齐项）