# AI 编程工作法 — TDD 规范与实现梳理

> 基于 `v1.2/skills/` 目录下各 Skill 定义梳理而成，帮助理解整套工作法中 `/tdd`**（测试驱动开发）** 的实现方式。

## 核心思想（一句话）

`/tdd` 不是「拿到 Issue 就写代码」或「先写完全部测试再实现」，而是 `ready-for-agent` **门禁 → PRD 必读预检 → tracer-bullet 垂直切片（一次一个 RED→GREEN）→ 全绿后重构 → PR 验收** 的实现阶段。

---

## Issue 类型（二选一）

`/tdd` 启动后**先判定 Issue 类型**，再进入对应预检文档（[ui-issues.md](skills/tdd/ui-issues.md) 或 [functional-issues.md](skills/tdd/functional-issues.md)）：

```
Issue 含 PRD 绑定？
├─ UI 模式 headless → 功能 Issue（functional-issues.md）
└─ 含 States 矩阵？
    ├─ 是 → UI Issue（ui-issues.md）
    └─ 否 → 功能 Issue（functional-issues.md）
```


| Issue 类型                | 识别                                               | 预检文档                                                    | PRD 必读  | RED 循环依据               |
| ----------------------- | ------------------------------------------------ | ------------------------------------------------------- | ------- | ---------------------- |
| **UI 实现**               | 含 `PRD 绑定` + `States 矩阵`（`headless` 除外）          | [ui-issues.md](skills/tdd/ui-issues.md)                 | **7 项** | States 矩阵 **PRD 来源** 列 |
| **功能 / API / headless** | 含 `PRD 绑定` 且**无** `States 矩阵`，或 UI 模式 `headless` | [functional-issues.md](skills/tdd/functional-issues.md) | **3 项** | 验收标准 **PRD 依据**        |


**共有门禁**：issue 非 `ready-for-agent` → **停止**，不要 `/tdd`。**依赖** 章节所列 Issue 未合并且未注明「已在主干合并」→ **停止**。

---



## 涉及 TDD 的 Skill 分工


| 阶段  | Skill                            | TDD 相关职责                                                                                       |
| --- | -------------------------------- | ---------------------------------------------------------------------------------------------- |
| 基建  | `/setup-skills`                  | Issue 跟踪器、Triage 标签映射（`ready-for-agent` 等）                                                     |
| 规划  | `/to-prd`                        | 实现 / 测试决策**定位词**（功能 Issue 路由键）；非 headless PRD **必填** `### 状态策略`（UI Issue 预检第 2 项）              |
| 拆解  | `/to-issues`                     | 写入 **PRD 必读**（UI 7 项 / 功能 3 项）、**States 矩阵**（UI）、**验收标准** + **PRD 依据**（功能）；Issue **不抄 PRD 全文** |
| 分拣  | `/triage`                        | 核对预检输入 → `ready-for-agent`；Agent 简报 **原样复制** PRD 必读                                            |
| 实现  | `/tdd`                           | 预检 → 红→绿→重构 → PR                                                                               |
| 横切  | `/diagnose`                      | 测试失败 / 运行时 Bug 的反馈回路                                                                           |
| 横切  | `/improve-codebase-architecture` | 全绿后的深模块重构                                                                                      |


---



## 核心理念：行为测试与垂直切片

来自 [SKILL.md](skills/tdd/SKILL.md) 的 TDD 底座：

**核心原则**：测试应通过**公共接口**验证**行为**，而非验证实现细节。代码可以完全改变；测试不应该因此而失败。

**好的测试**（详见 [tests.md](skills/tdd/tests.md)）：集成风格、描述系统**做什么**、仅使用公共 API、重构后仍有效。

**反模式 — 水平切片**：不要先编写所有测试，再编写所有实现。

```
错误（水平切片）：
  RED:   test1, test2, test3, test4, test5
  GREEN: impl1, impl2, impl3, impl4, impl5

正确（垂直切片 / tracer-bullet）：
  RED→GREEN: test1→impl1
  RED→GREEN: test2→impl2
  RED→GREEN: test3→impl3
  ...
```

批量 RED 会产生测试**想象中**的行为、锁死未经验证的结构、且进度超出「能见度」。**正确做法**：一个测试 → 一份最小实现 → 重复；每个 RED 基于上一轮刚写出的代码调整断言。

---



## 知识底座：Issue 字段作为 SSOT

Issue **不重复 PRD 全文**，用结构化字段把 Agent 路由到 PRD / design 的正确段落：


| 字段                   | UI Issue               | 功能 Issue           | 写入方          |
| -------------------- | ---------------------- | ------------------ | ------------ |
| **PRD 绑定 › PRD 必读**  | 7 项编号清单                | 3 项编号清单            | `/to-issues` |
| **States 矩阵**        | 每态：PRD 来源 + 可观察预期      | —                  | `/to-issues` |
| **验收标准**             | 功能 / UI 行为 / 设计质量验收 三类 | 可观察行为 + **PRD 依据** | `/to-issues` |
| **Agent 简报 › 实现前必读** | 从 PRD 必读**原样复制**       | 同左                 | `/triage`    |


**PRD 必读 vs RED 循环的分工**（两类 Issue 共有逻辑）：


| 阶段            | 读什么                                            | 目的                           |
| ------------- | ---------------------------------------------- | ---------------------------- |
| **编码前预检**     | PRD 必读全部项                                      | 建立全局上下文（页面 / 壳层 / 契约 / 设计输入） |
| **每个 RED 循环** | UI：States 矩阵该行 **PRD 来源**；功能：该条验收标准 **PRD 依据** | 精读该行为的可观察预期；**不**重复通读整份 PRD  |


**清单来源**：存在 Agent 简报 → 以简报「实现前必读」为准（须与 issue 正文 PRD 必读一致）；否则用 issue「PRD 绑定 › PRD 必读」。每项须能写出一行摘要，做不到 → **停止** `/tdd`。

---



## PRD → Issue → `/tdd` 的知识路由

```mermaid
flowchart TB
    PRD["PRD Issue"]
    PRD --> IMPL["## 实现决策<br/>定位词"]
    PRD --> TEST["## 测试决策<br/>定位词"]
    PRD --> ST["### 状态策略"]
    PRD --> PL["### 页面清单<br/>page-id · UI 设计描述"]

    TOISS["/to-issues"]
    IMPL --> TOISS
    TEST --> TOISS
    ST --> TOISS
    PL --> TOISS

    TOISS --> FN["功能 Issue<br/>PRD 必读 3 项<br/>验收标准 + PRD 依据"]
    TOISS --> UI["UI Issue<br/>PRD 必读 7 项<br/>States 矩阵"]

    TRIAGE["/triage<br/>Agent 简报"]
    FN --> TRIAGE
    UI --> TRIAGE

    TRIAGE --> TDD["/tdd"]
    TDD --> P7["UI：预检 7 项"]
    TDD --> P3["功能：预检 3 项"]
    P7 --> RED_UI["RED 按 States 矩阵 PRD 来源"]
    P3 --> RED_FN["RED 按验收标准 PRD 依据"]

    style PRD fill:#cfe2ff
    style FN fill:#cfe2ff
    style UI fill:#d4edda
    style TDD fill:#fff3cd
```




| PRD 章节         | 功能 Issue 消费方式               | UI Issue 消费方式                        |
| -------------- | --------------------------- | ------------------------------------ |
| `## 实现决策`      | PRD 必读第 1 项；验收标准 **PRD 依据** | —                                    |
| `## 测试决策`      | PRD 必读第 2 项；验收标准 **PRD 依据** | —                                    |
| `## 用户故事`      | PRD 必读第 3 项                 | PRD 必读第 3 项                          |
| `### 状态策略`     | —                           | PRD 必读第 2 项；States 矩阵 loading / 全局态  |
| `### 页面清单`     | —                           | PRD 必读第 1、4 项；States 矩阵各态 **PRD 来源** |
| `docs/design/` | —                           | PRD 必读第 5–7 项；Token / references 对齐  |


---



## 双轨预检体系（核心机制）

UI 实现与功能 / API 实现 **共用** TDD 节奏，**分叉**于预检清单与 RED 依据：

```mermaid
flowchart TB
    subgraph COMMON["共有门禁"]
        G1["issue = ready-for-agent"]
        G2["依赖已合并或注明主干"]
        G3["PRD 必读逐项打开 + 一行摘要"]
    end

    subgraph UI_TRACK["UI 轨"]
        U1["PRD 必读 7 项"]
        U2["States 矩阵"]
        U3["DESIGN.md（+ references / platforms）"]
        U4["RED：先 default 行，再其余 state"]
        U5["不测像素；PR 设计 QA"]
    end

    subgraph FN_TRACK["功能轨"]
        F1["PRD 必读 3 项"]
        F2["验收标准 + PRD 依据"]
        F3["最高层 seam 集成测试"]
        F4["RED：按验收标准优先级"]
    end

    COMMON --> UI_TRACK
    COMMON --> FN_TRACK

    style COMMON fill:#e2e3e5
    style UI_TRACK fill:#d4edda
    style FN_TRACK fill:#cfe2ff
```





### 关键纪律

- **禁止**在依赖未就绪时 stub 壳层或猜 API 契约
- **禁止**只读 Issue 摘要代替打开 PRD 完整正文
- **禁止**在 RED 阶段重构 — 先 GREEN
- **禁止**功能 UI 的 PR 直接改 `DESIGN.md` 全局 Token → 须 Design Issue
- UI：**测试全绿 ≠ 设计验收通过** — 仍须 PR 设计质量验收
- 功能：产出的**公共接口**是下游 UI Issue 的集成依赖，合并前 CI 须绿

---



## TDD 全流程图（从分拣到合并）

```mermaid
flowchart TB
    START(["Issue ready-for-agent"])

    subgraph P1["阶段 1：启动"]
        BRANCH["从 main 拉分支 issue/N-xxx"]
        TYPE{"判定 Issue 类型"}
        DEPS{"依赖已满足？"}
        START --> BRANCH --> TYPE --> DEPS
        DEPS -->|"否"| STOP["停止 /tdd<br/>说明阻塞"]
    end

    subgraph P2["阶段 2：预检"]
        BRIEF["读 Agent 简报<br/>实现前必读"]
        PRD_OPEN["拉取父 PRD 完整正文"]
        ITEMS["逐项打开 PRD / design"]
        SUMMARY["每项写一行摘要"]
        DEPS -->|"是"| BRIEF --> PRD_OPEN --> ITEMS --> SUMMARY
    end

    subgraph P3["阶段 3：红-绿-重构"]
        PLAN["映射 RED→GREEN 顺序<br/>UI：States 矩阵<br/>功能：验收标准"]
        TB["tracer-bullet<br/>第一个 RED→GREEN"]
        LOOP["其余 RED→GREEN 循环"]
        REFACTOR["全绿后重构"]
        SUMMARY --> PLAN --> TB --> LOOP --> REFACTOR
    end

    subgraph P4["阶段 4：交付"]
        PR["开 PR<br/>勾选验收标准"]
        CI["CI 全绿"]
        QA["UI：设计质量验收 人工过"]
        MERGE["合并 main"]
        REFACTOR --> PR --> CI --> QA --> MERGE
    end

    style STOP fill:#f8d7da
    style MERGE fill:#d4edda
```



---



## 三个关键「闸门」

```mermaid
flowchart LR
    subgraph GATE1["闸门 1：Issue 状态"]
        S1["needs-triage / ready-for-human"]
        S2["ready-for-agent"]
        S1 -->|"triage 核对通过"| S2
    end

    subgraph GATE2["闸门 2：依赖"]
        D1["依赖 Issue 未合并"]
        D2["可开始 /tdd"]
        D1 -->|"合并或注明主干"| D2
    end

    subgraph GATE3["闸门 3：TDD 预检"]
        T1["/tdd 启动前"]
        T1 --> T2["PRD 必读逐项打开"]
        T1 --> T3["一行摘要证明已读"]
        T1 --> T4["RED 前打开 PRD 来源 / PRD 依据"]
        T2 & T3 & T4 --> T5["才开始写测试/代码"]
    end
```




| 闸门       | 不满足时                          | 负责 Skill  |
| -------- | ----------------------------- | --------- |
| Issue 状态 | **停止** `/tdd`                 | `/triage` |
| 依赖       | **停止**；不要 stub / 猜契约          | `/tdd` 预检 |
| PRD 必读   | **停止**；回到 `/triage` 或补 PRD 绑定 | `/tdd` 预检 |


---



## 红-绿-重构工作流

来自 [SKILL.md](skills/tdd/SKILL.md)，四类 Issue **共有**节奏：

### 1. 规划（编码前）

- [ ] 完成对应预检清单（[ui-issues.md](skills/tdd/ui-issues.md) / [functional-issues.md](skills/tdd/functional-issues.md)）
- [ ] **AFK**：Issue **验收标准** 即计划批准 — 映射为 RED→GREEN 循环，无需重复确认（仅模糊或与 PRD 冲突时暂停）
- [ ] 识别 [深模块](skills/tdd/deep-modules.md) 与 [可测试接口](skills/tdd/interface-design.md) 机会
- [ ] 列出 RED→GREEN 顺序（UI：States 矩阵行序，先 `default`；功能：主路径优先 + 各条 PRD 依据）



### 2. Tracer Bullet

```
RED:  为第一个行为编写测试 → 失败
GREEN: 编写最少代码使其通过 → 通过
```

证明该路径端到端可行。

### 3. 增量循环

```
RED:   下一个测试 → 失败
GREEN: 最少代码 → 通过
```

- 一次一个测试；只写够通过当前测试的代码
- 不要预判未来测试；保持可观察行为
- UI：按 States 矩阵逐 state（见 § UI Issue Agent 规则）
- 功能：按验收标准逐条；RED 前打开 **PRD 依据**（见 § 功能 Issue Agent 规则）



### 4. 重构（全绿后）

- [ ] 提取重复、深化模块、应用 SOLID（见 [refactoring.md](skills/tdd/refactoring.md)）
- [ ] 每步重构后跑测试

- UI：填写 PR UI 验收章节；**不要**改 `DESIGN.md`（Design Issue 路径）



### 每个循环的检查清单

```
[ ] 测试描述行为，而非实现
[ ] 测试仅使用公共接口
[ ] 测试在内部重构后仍然有效
[ ] 代码对于此测试是最小化的
[ ] 没有添加推测性的功能
```

---



## UI Issue：Agent 规则

编码前完成 [ui-issues.md](skills/tdd/ui-issues.md) 预检。**先读模式**：issue「UI 模式」→ PRD 摘要 → `DESIGN.md` 文首。`headless` issue 跳过本章。

### 依赖未完成时停止（预检之前）

- [ ] 依赖 Issue 已关闭且 PR 已合并，或注明「已在主干合并」+ PR 链接
- [ ] mockup-driven：对应 `#D-xxx` 已评审且 references 已入库
- [ ] 功能页：同端 **app-shell** Issue 已合并



### 预检 PRD 必读项（7 项）


| 项   | 打开位置                                                                 |
| --- | -------------------------------------------------------------------- |
| 1   | PRD `### 页面清单` 下 `{page-id}` 条目**全文**（含 UI 设计描述与变体段）                 |
| 2   | PRD `### 状态策略`                                                       |
| 3   | PRD `## 用户故事` 中 issue 覆盖的 `US-n`                                     |
| 4   | 同端 `app-shell` 页面清单 + 壳层变体（`page-id` = `app-shell` 时跳过）              |
| 5   | `docs/design/DESIGN.md` — §5 原语 + §6 宜忌                              |
| 6   | `docs/design/platforms.md` — `{platform-id}` 段落（单端跳过）                |
| 7   | `docs/design/references/{platform-id}-{page-id}.png`（spec-driven 跳过） |




### 预检清单

**共有**：

- [ ] PRD 绑定 + States 矩阵完整；PRD 必读 7 项已逐项打开
- [ ] `ready-for-agent`；禁止硬编码颜色/间距，用 DESIGN Token

**mockup-driven 追加**：

- [ ] references 默认态已阅读
- [ ] 变体态行的 **PRD 来源** 已按列打开
- [ ] 偏离 references 须在 PR 说明并经批准



### 对齐标准


| 模式                | 对齐依据                                                         |
| ----------------- | ------------------------------------------------------------ |
| **spec-driven**   | DESIGN Token + **PRD 页面清单 UI 设计描述** + States 矩阵各态            |
| **mockup-driven** | 上列 + references **默认态**；变体态按 States 矩阵 + PRD 变体段 + DESIGN §5 |




### 测试策略

**测**（CI / TDD）：States 矩阵各态可观察行为。**一行矩阵 ≈ 一个 RED→GREEN**；每个 RED 前按 **PRD 来源** 打开对应段落。


| 矩阵 state   | 触发方式（示例）             | 断言什么                       |
| ---------- | -------------------- | -------------------------- |
| `default`  | 正常 fixture / API 有数据 | 文案、按钮态、主操作可用               |
| `loading`  | 延迟 API / `aria-busy` | 骨架 / spinner；或提交中 disabled |
| `empty`    | API 空列表 fixture      | 空态文案与引导操作                  |
| `error`    | API 5xx / seam 注入失败  | 错误提示 + 重试（若矩阵有写）           |
| `disabled` | 未选必填项即渲染             | 主 CTA 不可点或矩阵描述行为           |


优先用 **test seam**（fixture、MSW、项目 API stub）触发变体态，避免测 CSS 类名或组件内部 state。

**不测**（PR 设计 QA）：像素级布局、间距、颜色与 references 一致；DESIGN 气质「看起来对不对」。

**app-shell**（`page-id` = `app-shell`）：测导航 chrome 行为，不测业务字段；功能页合并后**不再重复测 shell 全规格**，只测相对壳层增减。

---



## 功能 Issue：Agent 规则

编码前完成 [functional-issues.md](skills/tdd/functional-issues.md) 预检。识别：UI 模式 `headless`；或含 PRD 绑定但**无** States 矩阵（API / schema / 领域 seam）。

### 预检 PRD 必读项（3 项）


| 项   | 打开位置                             |
| --- | -------------------------------- |
| 1   | PRD `## 实现决策` 中含 issue 定位词的那一条   |
| 2   | PRD `## 测试决策` 中含 issue 定位词的那一条   |
| 3   | PRD `## 用户故事` 中 issue 覆盖的 `US-n` |


定位词须与 `/to-issues` 写入 issue 的正文**完全一致**；PRD 中找不到唯一条目 → **停止**。

### 验收标准 → PRD 依据

功能 issue **无 States 矩阵**；每条验收标准带 **PRD 依据**，供 RED 循环打开 PRD 段落 — 与 UI States 矩阵 **PRD 来源** 列对称：


| PRD 依据             | RED 前打开           |
| ------------------ | ----------------- |
| `PRD 实现决策 › {定位词}` | PRD「实现决策」含该定位词的条目 |
| `PRD 测试决策 › {定位词}` | PRD「测试决策」含该定位词的条目 |
| `用户故事 US-n`        | PRD「用户故事」第 n 条    |




### 预检清单

- [ ] `ready-for-agent`；依赖已合并或注明「无 — 可立即开始」
- [ ] PRD 绑定 3 项已逐项打开；验收标准非空且含 PRD 依据
- [ ] 使用 `CONTEXT.md` 词汇；尊重 `docs/adr/`



### 测试策略

**测**：通过公共接口（最高层 seam：HTTP API、CLI、公开 SDK 等）的可观察行为；每条验收标准至少一个 RED→GREEN。

**不测**：私有函数、内部 call 顺序、绕过公共接口查库（见 [tests.md](skills/tdd/tests.md)、[mocking.md](skills/tdd/mocking.md)）。

**与 UI Issue 衔接**：本 Issue 公共接口即下游 UI 集成依赖；合并前 CI 须绿，契约与 PRD 一致。

---



## 验收分工


| 项                           | 谁负责              | 说明                                |
| --------------------------- | ---------------- | --------------------------------- |
| 功能 + UI 行为                  | CI / Agent / TDD | issue 验收标准中**可测试**类               |
| 布局 / 气质 / mockup references | PR 评审者           | issue **设计 QA** 类 — **不由 TDD 替代** |
| 功能契约一致性                     | CI + PR 评审       | 对照 PRD 实现 / 测试决策                  |


**GREEN 阶段之后**：

- UI：新禁止模式 → `DESIGN.md` §6 宜忌（Design Issue）；**不要**直接改全局 Token
- 功能：PR 逐条勾选验收标准并注明测试名；不修改 `docs/design/`

