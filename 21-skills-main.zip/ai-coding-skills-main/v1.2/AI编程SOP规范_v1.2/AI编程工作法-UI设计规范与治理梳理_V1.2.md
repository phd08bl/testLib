# AI 编程工作法 — UI 设计规范与治理梳理

> 基于 `v1.2/skills/` 目录下各 Skill 定义梳理而成，帮助理解整套工作法中 **UI 设计** 的实现方式。

## 核心思想（一句话）

UI 设计不是 `/tdd` 里的即兴发挥，而是一套 **「UI 模式选定 → DESIGN.md → PRD（状态策略 + 页面清单）→ Design Issue → references/ PNG（mockup-driven（稿驱动 UI））→ UI Issue（PRD 必读 7 项 + States 矩阵）→ Triage 门禁 → 对齐 SSOT 实现」** 的流水线。

---

## UI 编码模式（三选一）

`/grill-with-docs` 在领域 + 技术基线确认后，通过决策树选定 UI 模式，并写入 `docs/design/DESIGN.md` 文首：

```
有没有可视化页面？
├─ 否 → 模式 1 headless（无可视化 UI）
└─ 是 → 会不会提供 UI 设计稿 PNG？
    ├─ 否 → 模式 2 spec-driven（规范驱动 UI）
    └─ 是 → 模式 3 mockup-driven（稿驱动 UI；全部 UI 页须提供 PNG）
```


| 模式                        | 含义                     | 设计输入                                                  | Design Issue              |
| ------------------------- | ---------------------- | ----------------------------------------------------- | ------------------------- |
| **headless（无可视化 UI）**     | 无可视化页面（API / CLI / 库）  | 不创建 `docs/design/`                                    | **不开任何 Design Issue**     |
| **spec-driven（规范驱动 UI）**  | 有页面，**永不**提供 PNG 设计稿   | `DESIGN.md` + PRD 页面清单「UI 设计描述」                       | 仅 `#D-global`             |
| **mockup-driven（稿驱动 UI）** | 有页面，**全部** UI 页须提供 PNG | `DESIGN.md` + + PRD 页面清单「UI 设计描述」+ `references/*.png` | `#D-global` + 每页 `#D-xxx` |


**页面布局 SSOT 分工**：

- **spec-driven（规范驱动 UI）**：PRD 页面清单「UI 设计描述」= 编码唯一权威来源
- **mockup-driven（稿驱动 UI）**：默认态 PNG = 稿面对齐唯一权威来源；UI 设计描述（含变体段）= 设计稿绘制说明与实现补充
- **功能页面规格**（布局、字段排列、状态变体）→ **PRD**，不写入 `DESIGN.md`

---



## 涉及 UI 的 Skill 分工


| 阶段  | Skill              | UI 设计职责                                                                                                           |
| --- | ------------------ | ----------------------------------------------------------------------------------------------------------------- |
| 对齐  | `/grill-with-docs` | 拷问顺序第三段：定 UI 模式 → 品牌视觉规范→ 按 `DESIGN-TEMPLATE.md` 惰性写入 `docs/design/DESIGN.md`                                     |
| 规划  | `/to-prd`          | 先写 `docs/prd` 本地确认；非 headless PRD **必填** `### 状态策略`；页面清单以 app-shell 置顶；UI 设计描述 / 默认态设计稿计划按模式写入 PRD                |
| 拆解  | `/to-issues`       | **以 PRD 页面清单为 SSOT，不重新拆 UI 页**；拆 `#D-global`（+ mockup-driven 下 `#D-xxx`）+ UI Issue，正文含 **PRD 必读 7 项** + States 矩阵 |
| 分拣  | `/triage`          | UI 门禁：核对 PRD 必读 7 项 / States 矩阵 / DESIGN.md / references → `ready-for-agent`；Agent 简报 **原样复制** PRD 必读             |
| 实现  | `/tdd`             | 编码前按 issue「PRD 必读」7 项逐项打开 PRD / design；RED 循环按 States 矩阵 **PRD 来源** 列精读                                           |


---



## 知识底座：设计输入（仅此三类）

```
docs/design/
├── DESIGN.md                              ← 品牌视觉 SSOT（grill 写入，#D-global 验收关闭）
├── platforms.md                           ← 多端时：platform-id 清单 + 各端组件库映射
└── references/
    └── {platform-id}-{page-id}.png        ← mockup-driven（稿驱动 UI）每页默认态设计稿
```



### `DESIGN.md` 文档结构

由 `/grill-with-docs` 按 [DESIGN-TEMPLATE.md](v1.2/skills/grill-with-docs/DESIGN-TEMPLATE.md) **严格模板**惰性创建，**只写通用 UI 原语**，不写页面名、业务字段布局或功能专属复合组件。写入后须逐节对照模板验收，**不得**自行增删章节或调换顺序。


| 章节          | 内容                                                                               |
| ----------- | -------------------------------------------------------------------------------- |
| 文首          | `> UI 模式：spec-driven（规范驱动 UI）                                                    |
| §1 概览与创意北极星 | `### 创意北极星：「…」`；设计哲学、产品气质                                                        |
| §2 色彩与表面架构  | 四组色阶 + 语义色 + 表面层级 + 布局边界规则                                                       |
| §3 字体       | 三档字体族 + 字体实现约束（小程序/RN/Flutter/原生 APP 的 fallback 栈；mockup-driven 下区分稿面字体 vs 实现字体） |
| §4 层级与深度    | 叠层原则、阴影、叠色对照表（复用 ≥2 次的叠色须固化 Token + 预计算 HEX）                                     |
| §5 组件       | 10 项通用 UI 原语（按钮含反色变体、输入、卡片、列表行、导航、搜索框、状态徽章、图标按钮、空状态、Loading）                     |
| §6 宜忌       | Do / Don't 列表；宜忌提到的视觉模式须在 §5 已有对应规格                                              |


`/grill-with-docs` 按 **三类文档路由** 写入：

- 业务规则 → `CONTEXT.md`
- 架构决策 → `docs/adr/*.md`
- **品牌视觉 / 通用 UI 原语 →** `docs/design/DESIGN.md`

**拷问顺序（固定）**：领域规格 → 技术规格（含 14 项技术栈基线） → UI 规格（含 UI 模式选定 + 品牌视觉规范）。

**mockup-driven 分工**：PNG 管页面视觉与功能组件布局；DESIGN 管 Token、通用 UI 原语与实现边界（含字体 fallback、叠色对照表）。

---



## PRD → UI Issue 的知识路由

Issue **不重复 PRD 全文**，用 **PRD 绑定** 把 Agent 路由到正确段落：

```mermaid
flowchart TB
    PRD["PRD Issue"]
    PRD --> ST["### 状态策略<br/>（非 headless 必填）"]
    PRD --> PL["### 页面清单<br/>page-id · UI 设计描述 · 变体段"]
    PRD --> MAP["用户故事 ↔ 页面映射"]

    TOISS["/to-issues"]
    ST --> TOISS
    PL --> TOISS
    MAP --> TOISS

    TOISS --> UI["UI Issue<br/>PRD 必读 7 项 + States 矩阵"]
    TOISS --> DI["Design Issue<br/>#D-global / #D-xxx"]

    UI --> TDD["/tdd 预检 7 项<br/>RED 按 States 矩阵 PRD 来源"]

    style PRD fill:#cfe2ff
    style UI fill:#d4edda
    style DI fill:#fff3cd
```




| PRD 章节         | 消费方式                                                   |
| -------------- | ------------------------------------------------------ |
| `### 状态策略`     | UI Issue「PRD 必读」第 2 项；States 矩阵 loading / 全局态行的 PRD 来源 |
| `### 页面清单`     | spec-driven → 布局 SSOT；mockup → `#D-xxx` 默认态 PNG 范围     |
| 用户故事 ↔ 页面映射    | UI Issue 覆盖故事 `US-n`                                   |
| PRD 末尾 UI 模式摘要 | 判定 headless / spec-driven / mockup-driven              |


**PRD 缺口纪律**：非 headless PRD **缺** `### 状态策略` → `/to-issues` 须在拆解方案标注 PRD 缺口；UI Issue **不得**标 `ready-for-agent`（标 `ready-for-human`），须先补 PRD。

---



## 双轨 Issue 体系（核心机制）

设计文档维护与页面代码实现 **分离**；PRD 承载功能页面规格：

```mermaid
flowchart TB
    subgraph TRACK1["🎨 设计轨（design-input 标签）"]
        D1["#D-global<br/>验收关闭 DESIGN.md<br/>（多端时含 platforms.md）"]
        D2["#D-xxx（仅 mockup-driven（稿驱动 UI））<br/>references/ 单页默认态 PNG"]
        D1 --> D2
    end

    subgraph TRACK2["⚙️ 实现轨（功能 Issue）"]
        API["#5 API 预约<br/>可与 #D-global 并行"]
        SHELL["#7 [web-admin] app-shell<br/>依赖 #D-global"]
        UI1["#8 [web-admin] 预约列表<br/>依赖 #5 + app-shell + #D-xxx（mockup-driven（稿驱动 UI））"]
    end

    D2 --> UI1
    D1 --> SHELL
    SHELL --> UI1
    D1 -.->|"并行，无 UI 依赖"| API

    style D1 fill:#d1e7dd
    style D2 fill:#d1e7dd
    style API fill:#cfe2ff
    style SHELL fill:#fff3cd
    style UI1 fill:#fff3cd
```





### Design Issue 速查


| Issue       | 产出物                                                                                  | 依赖          | 默认状态              | 适用模式                                        |
| ----------- | ------------------------------------------------------------------------------------ | ----------- | ----------------- | ------------------------------------------- |
| `#D-global` | **验收关闭** `DESIGN.md`（grill 已写则补缺口、核对清单，**非重写**）；多端时含 `platforms.md`                  | 无           | `ready-for-agent` | spec-driven（规范驱动 UI）/ mockup-driven（稿驱动 UI） |
| `#D-xxx`    | mockup-driven 每页：**默认态** `references/{platform-id}-{page-id}.png`；PRD 标注的额外态 PNG（若有） | `#D-global` | `ready-for-human` | **仅 mockup-driven（稿驱动 UI）**                 |


> **spec-driven（规范驱动 UI）不开** `#D-xxx`。功能页面规格在 PRD 文字 + issue 正文 PRD 绑定中。mockup-driven 下 PRD 页面清单**全部 UI 页**均须 `#D-xxx` + 默认态 PNG。

**mockup-driven 状态范围**：


| 维度           | 范围                                                      |
| ------------ | ------------------------------------------------------- |
| UI Issue 逻辑态 | 须实现 PRD 定义的全部逻辑态（Loading / Empty / Error…）              |
| mockup PNG   | **仅**默认态 + PRD 列出的「须单独出稿的其他态」；其余态复用 DESIGN §5 + PRD 变体段 |




### 关键纪律

- grill 已写 design → `#D-global` = **验收关闭**，不重写
- 功能 UI 的 PR **不得修改** `DESIGN.md` 全局 Token → 须单独开 Design Issue
- mockup-driven（稿驱动 UI）：任一页缺 `references/` 默认态 → UI issue `ready-for-human`，**禁止** `/tdd`
- **垂直切片**：不要「先设计全部页面，再实现全部页面」
- 功能页 UI issue **须依赖同端 app-shell issue**
- API/后端切片可与 `#D-global` **并行** —— 无设计依赖

---



## app-shell（各端整体框架页）

每个 `platform-id` **必须先**定整体框架页，**再**写该端功能页：


| 要点                    | 说明                                               |
| --------------------- | ------------------------------------------------ |
| page-id               | 固定为 `app-shell`                                  |
| 清单顺序                  | 各端页面清单**第一条**必须是该端 `app-shell`                   |
| 职责                    | 顶栏 / 底栏 Tab / 侧栏 / 内容区约定；**不写**具体业务字段            |
| 功能页引用                 | 描述首句声明继承或脱离 app-shell；只写相对壳层的增减                  |
| mockup-driven（稿驱动 UI） | 额外须 `references/{platform-id}-app-shell.png` 默认态 |


---



## UI 设计全流程图（从想法到代码）

```mermaid
flowchart TB
    START(["新功能 / 新页面想法"])

    subgraph P1["阶段 1：需求对齐"]
        GRILL["/grill-with-docs"]
        GRILL -->|"领域 → 技术 → UI 顺序"| MODE["选定 UI 模式<br/>headless（无可视化 UI）/ spec-driven（规范驱动 UI）/ mockup-driven（稿驱动 UI）"]
        MODE -->|"spec-driven（规范驱动 UI）或 mockup-driven（稿驱动 UI）"| BRAND["品牌视觉拷问<br/>色板 · 字体 · 组件 · 宜忌"]
        BRAND --> DESIGN_DOC["惰性写入 docs/design/DESIGN.md<br/>（DESIGN-TEMPLATE.md）"]
        MODE -->|"headless（无可视化 UI）"| SKIP["跳过 docs/design/"]
    end

    subgraph P2["阶段 2：规划拆解"]
        PRD["/to-prd<br/>docs/prd 本地确认<br/>状态策略 + 页面清单"]
        ISSUES["/to-issues<br/>以 PRD 页面清单为 SSOT"]
        PRD --> ISSUES
        ISSUES --> D_GLOBAL["#D-global Issue<br/>（验收关闭 DESIGN.md）"]
        ISSUES --> D_PAGE["#D-xxx Issues（mockup-driven（稿驱动 UI））<br/>产出 references/*.png"]
        ISSUES --> SHELL_ISS["app-shell UI Issues<br/>各端框架页"]
        ISSUES --> FUNC_UI["功能 UI Issues<br/>PRD 必读 7 项 + States 矩阵"]
    end

    subgraph P3["阶段 3：门禁与实现"]
        TRIAGE["/triage"]
        CHECK{"UI 输入齐全？<br/>PRD 必读 7 项 + States 矩阵<br/>+ DESIGN.md<br/>+ references（mockup-driven（稿驱动 UI））?"}
        TRIAGE --> CHECK
        CHECK -->|"缺设计稿/PRD 必读/States 矩阵"| HUMAN["ready-for-human<br/>❌ 禁止 /tdd"]
        CHECK -->|"设计输入就绪"| READY["ready-for-agent<br/>Agent 简报原样复制 PRD 必读"]
        READY --> TDD["/tdd"]
        TDD --> PRECHECK["ui-issues.md 预检<br/>按 PRD 必读 7 项逐项打开"]
        PRECHECK --> CODE["红→绿→重构<br/>RED 循环按 States 矩阵 PRD 来源<br/>spec-driven: 对齐 PRD UI 设计描述<br/>mockup-driven: 对齐 references 默认态"]
        CODE --> PR["PR 含三类验收标准<br/>功能 / UI 行为 / 设计 QA"]
        PR --> REVIEW["CI + 人工 UI设计质量验收"]
    end

    START --> GRILL
    DESIGN_DOC --> PRD
    SKIP --> PRD
    D_GLOBAL --> D_PAGE
    D_PAGE --> SHELL_ISS --> FUNC_UI
    D_GLOBAL --> SHELL_ISS
    FUNC_UI --> TRIAGE
    REVIEW --> MERGE(["合并 main"])

    style HUMAN fill:#f8d7da
    style READY fill:#d4edda
    style DESIGN_DOC fill:#e2e3e5
    style D_GLOBAL fill:#d1e7dd
    style D_PAGE fill:#d1e7dd
```



---



## 三个关键「闸门」

```mermaid
flowchart LR
    subgraph GATE1["闸门 1：文档路由"]
        Q["每个 UI 决策"]
        Q -->|"品牌视觉/通用原语?"| DES["docs/design/DESIGN.md"]
        Q -->|"页面布局/状态/字段?"| PRD["PRD 页面清单 + 状态策略"]
        Q -->|"业务规则?"| CTX["CONTEXT.md"]
        Q -->|"架构选型?"| ADR["docs/adr/*"]
    end

    subgraph GATE2["闸门 2：Issue 状态"]
        S1["needs-triage"]
        S1 -->|"mockup-driven（稿驱动 UI）: references/ 缺失<br/>或 PRD 必读 7 项 / States 矩阵不完整"| S2["ready-for-human"]
        S1 -->|"UI 输入 checklist 全绿"| S3["ready-for-agent"]
        S2 -->|"人工补齐 PNG / PRD 绑定"| S3
    end

    subgraph GATE3["闸门 3：TDD 预检"]
        T1["/tdd 启动前"]
        T1 --> T2["按 PRD 必读 7 项逐项打开 PRD / design"]
        T1 --> T3["确认 ready-for-agent + 依赖已合并"]
        T1 --> T4["RED 循环按 States 矩阵 PRD 来源列精读"]
        T2 & T3 & T4 --> T6["才开始写测试/代码"]
    end
```



---



## Triage 状态机（UI 相关）

```mermaid
stateDiagram-v2
    [*] --> needs_triage: 新 Issue 进入

    needs_triage --> needs_info: 信息不足
    needs_triage --> ready_for_agent: 规范完整，设计输入就绪
    needs_triage --> ready_for_human: 缺 references / PRD 必读 7 项 / States 矩阵
    needs_triage --> wontfix: 不予处理

    needs_info --> needs_triage: 报告人回复后

    ready_for_agent --> [*]: /tdd 实现
    ready_for_human --> ready_for_agent: 人工补齐后
    wontfix --> [*]

    note right of ready_for_agent
        UI Issue：PRD 必读 7 项 + States 矩阵已齐
        Agent 简报原样复制 PRD 必读
        类别标签：design-input（仅设计 Issue）
        headless（无可视化 UI）跳过 UI 门禁
    end note
```





### UI 工作流标签映射


| 情况                             | 状态标签                     | 含义                                                                |
| ------------------------------ | ------------------------ | ----------------------------------------------------------------- |
| 设计输入完成，Agent 可 `/tdd`          | `ready-for-agent`        | PRD 必读 7 项 + States 矩阵 + DESIGN.md（+ mockup-driven references）已就绪 |
| 缺 references、PRD 必读或 States 矩阵 | `ready-for-human`        | 不要对 UI 页面开 `/tdd`                                                 |
| 仅设计 issue                      | `design-input`（类别）+ 适当状态 | 仅产出 `docs/design/`                                                |




### Triage UI 门禁核对项

**共有（spec-driven（规范驱动 UI）与 mockup-driven（稿驱动 UI））**：

- Issue 正文含 **PRD 绑定**（父 PRD Issue、page-id、**PRD 必读 7 项**、壳层关系、覆盖的用户故事 `US-n`）
- Issue 正文含 **States 矩阵**（每态：**PRD 来源**为可定位字符串 + 可观察预期）
- `DESIGN.md` 存在且已就绪
- Issue 正文 **验收标准** 分三类且非空：**功能**（可测试）、**UI 行为**（可测试）、**设计 QA**（PR 人工；mockup 须含默认态对齐项）

**spec-driven（规范驱动 UI）追加**：PRD 绑定含 **布局 SSOT** 指向 PRD 页面清单「UI 设计描述」；**不检查** `references/`。

**mockup-driven（稿驱动 UI）追加**：PRD 绑定含稿面 / 变体 SSOT 与默认态 PNG 路径；`references/{platform-id}-*.png` 默认态存在；PRD 标注的额外态 PNG 已提供（若有）。

**功能页追加**（`page-id` ≠ `app-shell`）：**依赖** 含同端 app-shell issue，或注明「app-shell 已在主干合并」+ PR 链接。

**多端追加**：`platform-id` 在 `platforms.md` 平台清单中。

**Agent 简报**（移至 `ready-for-agent` 时）：从 issue 正文 **PRD 必读** **原样复制**「实现前必读」；含 PRD 绑定摘要与设计参考路径；**不要**补全或改写 PRD 必读项。