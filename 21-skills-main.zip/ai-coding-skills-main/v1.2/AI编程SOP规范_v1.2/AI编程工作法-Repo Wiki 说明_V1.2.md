# AI 编程工作法 — Repo Wiki 说明

> 基于 `skills/repo-wiki/` 与 `skills/setup-skills/wiki.md` 梳理而成，说明为何引入 `/repo-wiki`、它解决什么问题、以及如何在本工作法中使用。

## 核心思想（一句话）

**Repo Wiki** 是挂在业务仓库上的**代码库架构导读**——由 Agent 扫描源码生成、每条结论标注**源码位置**（文件路径与行号），供**人**快速理解「项目干什么、主流程怎么走、模块怎么连」；**不参与** workflow skills 的自动读序，与 `CONTEXT.md` / PRD 等规范层严格分工。

---

## 为何新增

### 痛点

接手陌生项目（尤其是二次开发、开源 Fork、历史仓）时，最耗时的往往不是写代码，而是：

- 搞清项目边界与主执行链路
- 理解核心模块如何划分、如何互相调用
- 在 IDE 里来回跳转，却缺少一份**带源码位置**的总览

现有 skills 的应对：


| 现有 Skill                         | 局限                        |
| -------------------------------- | ------------------------- |
| `/zoom-out`                      | 产出在**对话内**，会话结束即散；适合局部、临时 |
| `/grill-with-docs`               | 写**规范**（术语、决策），不写代码结构地图   |
| `/improve-codebase-architecture` | 面向**重构机会**，不是接手上手导读       |


### 解法

新增 `/repo-wiki`，将代码库扫描结果**持久化**到 `docs/repo-wiki/`：

- 固定 8 类架构主题（主链路、模块、边界、数据流……）
- 每条结论带源码位置标注，供人在 IDE 中按路径与行号**自行打开**对应文件核对
- 随代码变更可刷新；元数据记录对应 commit

### 工作法扩展


| 维度    | 原先                                | 扩展后                                    |
| ----- | --------------------------------- | -------------------------------------- |
| 基建项   | Issue 跟踪器 + Triage 标签 + 领域文档（3 项） | + **Repo Wiki**（4 项，`/setup-skills` D） |
| Skill | 10 个 workflow skills              | + `/repo-wiki`（独立生产者）                  |
| 文档分层  | 规范层（CONTEXT / ADR / DESIGN / PRD） | + **导航层**（`docs/repo-wiki/`，供人阅读）      |


---

## Repo Wiki 是什么、不是什么

### 是

- **代码库架构导读** — 项目身份、主执行链路、核心模块、跨端边界、数据与状态流、配置边界、扩展点、风险点
- **人类接手上手文档** — 新人、维护者、隔几周回到项目时的架构地图
- **带源码位置标注** — 标注文件路径与行号，便于对照 `src/` 自行验证

### 不是

- 产品文档站或使用手册
- 安装部署、CI/CD 教程
- 领域术语表（→ `CONTEXT.md`）
- 架构决策记录（→ `docs/adr/`）
- 功能需求规格（→ PRD / Issue）
- Agent 工作流的自动输入（workflow skills **默认不读** Wiki）
- 完整的 LLM Wiki / 会话复利知识库（见下节）

---

## 与 LLM Wiki 的关系

**一句话：`/repo-wiki` 是「LLM Wiki」思路的窄化落地——只做代码库架构导读，不是完整的会话复利知识库。**

### 各自是什么


|        | **LLM Wiki**（广义，如 Karpathy 式）   | **Repo Wiki**（本工作法落地）                         |
| ------ | ------------------------------- | --------------------------------------------- |
| 目标     | 把 Raw（会话、代码、笔记）编译成可检索、可互链的复利知识层 | 扫描源码，生成「代码现在长什么样」的架构地图                        |
| 典型内容   | 概念页、模块图、调试笔记、会话摘要……             | 固定 8 类：身份、主链路、模块、边界、数据流、配置、扩展点、风险点            |
| 读者     | 人 + Agent（常作为检索 / 上下文输入）        | **主要供人**；workflow skills **默认不读**             |
| 与规范层关系 | 可吸收 / 混入多种知识                    | **导航层**，与 `CONTEXT` / ADR / PRD 严格分工，冲突以规范层为准 |


### 怎么理解这段关系

1. **同源**：都是「用 LLM 把仓库信息落成持久 Markdown Wiki，并可刷新」。
2. **Repo Wiki ≠ 完整 LLM Wiki**：刻意收窄为代码库架构导读，不做会话沉淀、概念百科、调试知识库。
3. **在工作法里的位置**：补上「导航层」；规范层（CONTEXT / ADR / PRD）仍是 Agent 的 SSOT；`/zoom-out` 仍是对话内临时地图。

```text
LLM Wiki（广义：复利知识层）
    └── 本工作法实现的切片 → Repo Wiki（代码架构导读 / docs/repo-wiki/）
```

**结论：** 灵感来自 LLM Wiki 那一类「持久 Wiki」能力，落地形态是专用的 Repo Wiki，而不是把整套 LLM Wiki 融进工作法。

---

## 文档分层（与规范 SSOT 的分工）

```mermaid
flowchart TB
    SSOT["规范层 — 应该怎么做<br/>CONTEXT · ADR · DESIGN · PRD + Issue<br/>读者：人 + Agent"]
    WIKI["导航层 — 代码长什么样<br/>docs/repo-wiki/<br/>读者：主要供人"]
    CODE["src/ 源码 — 最终事实"]

    CODE -->|" /repo-wiki 扫描生成 "| WIKI
    WIKI -.->|"冲突时以规范层为准"| SSOT

    HUMAN["人"] --> WIKI
    HUMAN --> CODE

    AGENT["Agent workflow"] --> SSOT
    AGENT --> CODE
    AGENT -.->|"默认不读 Wiki"| WIKI
```



**读序一句话：**

- **人**接手项目：Wiki → 对照源码核对
- **Agent** 实现 Issue：Issue 简报 + PRD → 规范层 → 探索 `src/`


| 文档                | 读者        | 回答什么         |
| ----------------- | --------- | ------------ |
| `CONTEXT.md`      | 人 + Agent | 领域术语与业务含义    |
| `docs/adr/`       | 人 + Agent | 架构决策与理由      |
| `docs/design/`    | 人 + Agent | 品牌视觉设计系统     |
| PRD + Issue       | 人 + Agent | 功能规格与执行契约    |
| `docs/repo-wiki/` | **人**     | **代码现在长什么样** |


---

## 涉及文件一览

### Skills 包内（`skills/`）

```
skills/
├── repo-wiki/
│   ├── SKILL.md                  # 生成 / 刷新 / 删除 主流程
│   ├── TOC-TEMPLATE.md           # 8 类固定目录
│   ├── PAGE-FORMAT.md            # 源码位置标注与页面模板
│   ├── SCAN-RULES.md             # 扫描与安全规则
│   └── META-FORMAT.yaml          # _meta.yaml 字段说明
└── setup-skills/
    ├── SKILL.md                  # 扩展 D — Repo Wiki
    └── wiki.md                   # 布局与维护说明（写入业务仓 docs/agents/）
```

### 业务仓库内（运行 `/setup-skills` 与 `/repo-wiki` 后）

```
/                                 # 业务仓库根目录
├── docs/                         # 文档根目录（规范层 + 导航层并存）
│   ├── agents/                   # Agent 工程配置（/setup-skills 写入）
│   │   └── wiki.md               # Repo Wiki 布局、维护方式与人类阅读说明
│   └── repo-wiki/                # Repo Wiki 正文目录（/repo-wiki 扫描源码生成）
│       ├── _meta.yaml            # 元数据：分支、commit、语言、生成时间、页数、生成状态
│       ├── README.md             # Wiki 首页：项目身份、技术栈摘要、入口文件、阅读指引
│       ├── 01-execution-flow.md  # 主执行链路：从请求/CLI/事件到核心逻辑的端到端路径
│       ├── 02-core-modules/      # 核心模块目录
│       │   ├── index.md          # 模块总览：模块列表、职责摘要、模块间依赖
│       │   └── {module-name}.md  # 各模块详情：职责、对外接口、依赖与调用者（按 package 拆分）
│       ├── 03-cross-boundaries.md # 跨端边界：前后端、服务间、monorepo packages 交界
│       ├── 04-data-state-flow.md # 数据与状态流：持久化、缓存、状态机、事件传播
│       ├── 05-config-boundaries.md # 配置边界：env、配置文件、feature flag 生效点
│       ├── 06-extension-points.md  # 扩展点：插件 hook、策略 seam、可替换适配器
│       ├── 07-risk-points.md     # 风险点：高耦合、缺测试、与 ADR 不一致、技术债
│       └── diagrams/             # 可选：Mermaid 架构/流程/时序图源文件，由正文页引用
├── CONTEXT.md                    # 规范层 — 领域术语表（/grill-with-docs 维护）
└── docs/adr/                     # 规范层 — 架构决策记录（/grill-with-docs 维护）
    └── *.md                      # 各条 ADR，如 0001-xxx.md
```

---

## 如何使用

### 第一步：基建 — `/setup-skills`

每个业务仓库**首次**接入本工作法时运行。在原有 A / B / C 之后增加 **D — Repo Wiki**：


| 步骤    | 配置项           | 说明                             |
| ----- | ------------- | ------------------------------ |
| A     | Issue 跟踪器     | 不变                             |
| B     | Triage 标签     | 不变                             |
| C     | 领域文档          | 不变                             |
| **D** | **Repo Wiki** | 是否启用、默认语言（zh-CN / en）、是否纳入 Git |


完成后写入：

- `docs/agents/wiki.md` — 布局与维护说明
- `AGENTS.md` / `CLAUDE.md` 中 `### Repo Wiki 代码导读` 一节

**示例对话：**

```text
/setup-skills
```

按提示完成 A → B → C → **D**（默认启用 Wiki、简体中文、纳入 Git）。

### 第二步：首次生成 — `/repo-wiki`

建议在 `/setup-skills` 完成后、开始 `/grill-with-docs` 或 `/to-prd` **之前**运行，尤其适用于：

- 二次开发 / Fork 开源项目
- 接手他人代码库
- 自己很久没打开的仓

**示例对话：**

```text
/repo-wiki
```

Skill 会**一次一问**确认：


| 选项   | 默认   | 说明                   |
| ---- | ---- | -------------------- |
| 语言   | 简体中文 | 同仓只保留一种语言；换语言会覆盖全部页面 |
| 生成图表 | 开启   | 有源码依据时才生成 Mermaid 图  |
| 重试次数 | 0    | 单页失败时的自动重试次数         |


然后依次：**分析代码库 → 生成目录（可确认）→ 逐页生成 → 保存**。

生成过程中：

- 可看到进度（如「5/12 页」）
- 已完成的页可提前阅读
- 可随时「停止」，已完成页会保留

### 第三步：人类阅读 Wiki

推荐顺序：

1. `docs/repo-wiki/README.md` — 项目身份与入口
2. `01-execution-flow.md` — 主执行链路
3. 按需打开 `02-core-modules/` 等主题页
4. 根据页内 `path:startLine-endLine`，在 IDE 中**手动打开**对应文件与行号，对照源码验证

展开 `_meta.yaml` 可查看：分支、commit、生成时间、页数。若 `commit` 与当前 `main` 不一致，Wiki 可能过时，**以源码为准**。

### 第四步：代码变更后刷新

PR 合并或大重构后，人工运行：

```text
/repo-wiki 刷新
```

Skill 会对比 `_meta.yaml` 中的 commit 与当前 HEAD：

- 无变更 → 提示已是最新，询问是否仍要刷新
- 有变更 → 选择**增量更新**（受影响模块页）或**整库重新生成**

### 其他操作


| 意图      | 说法                                           |
| ------- | -------------------------------------------- |
| 删除 Wiki | `/repo-wiki 删除` — 只删 `docs/repo-wiki/`，可随时重生 |
| 生成中停止   | 「停止」— 保留已完成页                                 |
| 换语言     | 重新 `/repo-wiki` 并选新语言（会覆盖原 Wiki）             |


---

## 典型场景路径

### 场景 A：从零新建项目

```text
/setup-skills
  → /grill-with-docs（写 CONTEXT / ADR / DESIGN）
  → /to-prd → /to-issues → …
```

Wiki **可选**。代码量尚少时收益不大；首个垂直切片合入后再生成亦可。

### 场景 B：二次开发 / 接手陌生仓（推荐）

```text
/setup-skills
  → /repo-wiki          ← 先建架构地图
  → /grill-with-docs    ← 对齐术语与决策时对照 Wiki 中的代码现状
  → /to-prd → …
```

### 场景 C：实现 Issue 过程中看不懂某模块

```text
/zoom-out               ← Agent 在对话内画局部模块图（临时）
```

或人自行打开 `docs/repo-wiki/02-core-modules/` 对应页。  
若需 Agent 同时读 Wiki，显式 `@docs/repo-wiki/02-core-modules/xxx.md`。

### 场景 D：PR 合并后

```text
/repo-wiki 刷新
```

保持 Wiki 与 `main` 同步。

---

## Wiki 目录结构（8 类主题）


| 文件                        | 主题     | 覆盖内容                  |
| ------------------------- | ------ | --------------------- |
| `README.md`               | 项目身份   | 定位、技术栈、入口文件           |
| `01-execution-flow.md`    | 主执行链路  | 请求 / CLI / 事件 → 核心逻辑  |
| `02-core-modules/`        | 核心模块   | 各 package / 目录职责与接口   |
| `03-cross-boundaries.md`  | 跨端边界   | 前后端、服务间、monorepo 交界   |
| `04-data-state-flow.md`   | 数据与状态流 | 持久化、缓存、状态机、事件         |
| `05-config-boundaries.md` | 配置边界   | env、配置文件、feature flag |
| `06-extension-points.md`  | 扩展点    | 插件 hook、策略 seam       |
| `07-risk-points.md`       | 风险点    | 高耦合、缺测试、与 ADR 不一致     |


**刻意不单独成章**：安装部署、CI/CD、PRD 功能规格。

---

## 与 `/zoom-out` 的分工


|     | `/repo-wiki`           | `/zoom-out`   |
| --- | ---------------------- | ------------- |
| 范围  | 全仓 8 类架构导读             | 当前关注的模块 / 子图  |
| 产物  | `docs/repo-wiki/` 持久文件 | 对话内临时地图       |
| 读者  | 人（需要时可 `@` 给 Agent）    | Agent + 人     |
| 时机  | 接手项目、PR 合并后刷新          | 实现 / 诊断中局部看不懂 |


---

## 限制与注意事项

- **同一仓库同时只跑一个** Wiki 生成任务
- **同一仓库只保留一种语言**；不支持中英文 Wiki 并存
- **不支持单页独立重新生成** — 增量更新相关页、整库重生，或手动编辑
- **不支持 Wiki 内置历史版本** — 版本管理交给 Git
- Wiki **不读取** `docs/prd/` 全文，避免成为第二 SSOT
- 扫描时**排除**密钥、依赖目录、构建产物等（见 `SCAN-RULES.md`）
- **Workflow skills 默认不读 Wiki** — Issue 简报、PRD 绑定等纪律不变

---

## 常见问题

**Q：Wiki 和 CONTEXT.md 会不会冲突？**  
A：不会替代。CONTEXT 定义**术语**；Wiki 描述**代码结构**。生成时 Wiki 优先用 CONTEXT 词汇命名模块；冲突以 CONTEXT 为准。

**Q：Agent 实现 Issue 时会自动读 Wiki 吗？**  
A：**不会**。Agent 仍按 Issue 简报 → CONTEXT / ADR / PRD → 探索 `src/`。需要 Agent 参考 Wiki 时，请 `@` 具体页面。

**Q：Wiki 要 commit 进 Git 吗？**  
A：「纳入 Git」，便于团队共享。

**Q：生成失败了几页怎么办？**  
A：查看 `_meta.yaml` 的 `failed_pages`，可整库重新生成或手动补写该页。

**Q：已有项目如何接入 Repo Wiki？**  
A：更新 skills 包 → 重跑 `/setup-skills`（补 D 项）→ 运行 `/repo-wiki` 首次生成。无需改动已有 CONTEXT / PRD / Issue 流程。

---

## 最短上手（复制即用）

```text
# 1. 基建（含 Repo Wiki）
/setup-skills

# 2. 首次生成架构导读
/repo-wiki

# 3. 人读 README → 主链路 → 模块页，按源码位置标注在 IDE 中自行核对

# 4. 之后按原工作法继续
/grill-with-docs → /to-prd → /to-issues → /triage → /tdd

# 5. PR 合并后刷新
/repo-wiki 刷新
```

