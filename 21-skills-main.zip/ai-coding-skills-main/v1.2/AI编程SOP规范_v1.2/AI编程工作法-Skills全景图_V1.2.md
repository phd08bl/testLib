# AI 编程工作法 — Skills 全景图

> 基于 `skills/` 目录下 10 个 Skill 梳理而成，帮助快速理解整套 AI 编程协作工作法。

## 核心思想（一句话）

把 AI 编程拆成**可组合的小步骤**，每步都有**可检查产物**；用 **Issue 跟踪器** 做工作流中枢，用 **垂直切片（tracer-bullet）** 贯穿 schema → API → UI → 测试，避免「先写完全部测试/设计再实现」的水平切片陷阱。

---

## 总览图：全流程 Skill 地图

```mermaid
flowchart TB
    subgraph P0["🏗️ 阶段 0：工程基建（每仓一次）"]
        SETUP["/setup-skills"]
        SETUP --> AGENTS["AGENTS.md / CLAUDE.md"]
        SETUP --> DOCS_AGENTS["docs/agents/<br/>issue-tracker · triage-labels · domain"]
    end

    subgraph P1["💬 阶段 1：需求对齐"]
        IDEA["想法 / Bug / 功能请求"]
        GRILL_ME["/grill-me<br/>纯拷问，不写文档"]
        GRILL_DOCS["/grill-with-docs<br/>拷问 + 同步写文档"]
        IDEA --> GRILL_ME
        IDEA --> GRILL_DOCS
        GRILL_DOCS --> CTX["CONTEXT.md<br/>领域术语表"]
        GRILL_DOCS --> ADR["docs/adr/<br/>架构决策记录"]
        GRILL_DOCS --> DESIGN["docs/design/DESIGN.md<br/>品牌视觉设计系统"]
        GRILL_ME -.->|"想清楚后再沉淀"| GRILL_DOCS
    end

    subgraph P2["📋 阶段 2：规划与拆解"]
        TOPRD["/to-prd"]
        TOISS["/to-issues"]
        PRD_LOCAL["docs/prd<br/>本地确认"]
        PRD["PRD Issue<br/>ready-for-agent"]
        SLICES["垂直切片 Issues<br/>AFK / HITL"]
        D_ISSUES["Design Issues<br/>#D-global → #D-xxx（mockup）"]
        GRILL_DOCS --> TOPRD
        TOPRD --> PRD_LOCAL
        PRD_LOCAL --> PRD
        PRD --> TOISS
        TOISS --> SLICES
        TOISS --> D_ISSUES
    end

    subgraph P3["⚙️ 阶段 3：分拣与实现"]
        TRIAGE["/triage<br/>Issue 状态机"]
        READY["ready-for-agent"]
        BRIEF["Agent 简报<br/>PRD 必读原样复制"]
        BRANCH["拉分支 issue/N-xxx"]
        TDD["/tdd<br/>红→绿→重构"]
        PR["PR + CI + 设计 QA"]
        MERGE["合并 main"]
        SLICES --> TRIAGE
        D_ISSUES --> TRIAGE
        TRIAGE --> READY
        READY --> BRIEF
        BRIEF --> BRANCH
        BRANCH --> TDD
        TDD --> PR
        PR --> MERGE
        MERGE -.->|"下一个 Issue"| TRIAGE
    end

    subgraph P4["🔧 横切能力（随时可用）"]
        DIAG["/diagnose<br/>反馈回路→假设→探针→修复"]
        ZOOM["/zoom-out<br/>拉高视角看代码"]
        ARCH["/improve-codebase-architecture<br/>加深模块重构"]
    end

    P0 --> P1
    P1 --> P2
    P2 --> P3
    TDD -.->|"出 Bug"| DIAG
    DIAG -.->|"架构根因"| ARCH
    TDD -.->|"看不懂代码"| ZOOM
    MERGE -.->|"v1 后维护"| ARCH

    style SETUP fill:#e8f4fd
    style GRILL_DOCS fill:#fff3cd
    style TDD fill:#d4edda
    style TRIAGE fill:#f8d7da
    style CTX fill:#e2e3e5
    style ADR fill:#e2e3e5
    style DESIGN fill:#e2e3e5
    style PRD_LOCAL fill:#e2e3e5
```



---

## 三类文档的分工（`grill-with-docs` 的路由规则）

这是整套工作法的**知识底座**——不同决策写进不同文件，避免 `CONTEXT.md` 变成大杂烩：

```mermaid
flowchart LR
    Q["每个决策问自己"]
    Q --> Q1{"业务含义<br/>状态/角色/规则?"}
    Q --> Q2{"难以逆转的<br/>技术/架构选择?"}
    Q --> Q3{"品牌视觉/交互<br/>通用 UI 原语?"}

    Q1 -->|是| CTX["CONTEXT.md<br/>纯词汇表，无实现细节"]
    Q2 -->|是| ADR["docs/adr/*.md<br/>ADR 格式"]
    Q3 -->|是| DES["docs/design/DESIGN.md<br/>品牌视觉板 · 组件 · 宜忌"]

    style CTX fill:#cfe2ff
    style ADR fill:#fff3cd
    style DES fill:#d1e7dd
```



**拷问顺序（固定）**：领域规格 → 技术规格（含 14 项技术栈基线） → UI 规格（含 UI 模式选定 + 品牌视觉规范）。

**UI 编码模式（三选一）**：


| 模式            | 含义                    | 设计输入                             |
| ------------- | --------------------- | -------------------------------- |
| headless      | 无可视化页面（API / CLI / 库） | 不创建 `docs/design/`               |
| spec-driven   | 有页面，永不提供 PNG 设计稿      | `DESIGN.md` + PRD 页面清单 UI 设计描述   |
| mockup-driven | 有页面，全部 UI 页须提供 PNG    | `DESIGN.md` + `references/*.png` |


**功能页面规格不进 DESIGN.md**：mockup-driven 由 PNG 承载；spec-driven 在 `/to-prd` 阶段写入 PRD 页面清单。

---

## PRD → Issue 的知识路由

Issue **不重复 PRD 全文**，用 **PRD 绑定** 把 Agent 路由到正确段落：

```mermaid
flowchart TB
    PRD["PRD Issue"]
    PRD --> ST["### 状态策略<br/>（非 headless 必填）"]
    PRD --> PL["### 页面清单<br/>page-id · UI 设计描述 · 变体段"]
    PRD --> ID["## 实现决策 / 测试决策<br/>（功能切片）"]

    TOISS["/to-issues"]
    ST --> TOISS
    PL --> TOISS
    ID --> TOISS

    TOISS --> UI["UI Issue<br/>PRD 必读 7 项 + States 矩阵"]
    TOISS --> FN["功能 Issue<br/>PRD 必读 3 项 + PRD 依据"]
    TOISS --> DI["Design Issue<br/>#D-global / #D-xxx"]

    UI --> TDD_UI["/tdd 预检 7 项<br/>RED 按 States 矩阵 PRD 来源"]
    FN --> TDD_FN["/tdd 预检 3 项<br/>RED 按验收标准 PRD 依据"]

    style PRD fill:#cfe2ff
    style UI fill:#d4edda
    style FN fill:#d4edda
    style DI fill:#fff3cd
```




| Issue 类型          | PRD 必读                                                            | 编码时打开什么                                     |
| ----------------- | ----------------------------------------------------------------- | ------------------------------------------- |
| **UI 实现**         | 7 项（页面清单全文、状态策略、用户故事、app-shell、DESIGN §5/§6、platforms、references） | 预检读 7 项；每个 RED 循环按 States 矩阵 **PRD 来源** 列精读 |
| **功能 / headless** | 3 项（实现决策子项、测试决策子项、用户故事）                                           | 每个 RED 循环按验收标准 **PRD 依据** 打开 PRD 段落         |


---

## Triage 状态机 + Issue 类型

Issue 跟踪器是整套流程的**中枢**；`/triage` 负责把 issue 推到正确状态：

```mermaid
stateDiagram-v2
    [*] --> needs_triage: 新 Issue 进入

    needs_triage --> needs_info: 信息不足
    needs_triage --> ready_for_agent: 规范完整，AFK 可接
    needs_triage --> ready_for_human: 需人工（设计稿缺失等）
    needs_triage --> wontfix: 不予处理

    needs_info --> needs_triage: 报告人回复后

    ready_for_agent --> [*]: /tdd 实现
    ready_for_human --> ready_for_agent: 人工补齐后
    wontfix --> [*]

    note right of ready_for_agent
        类别标签：
        bug / enhancement / design-input
        每个 Issue 恰好 1 类别 + 1 状态
        headless 跳过 UI 门禁
    end note
```



**UI 实现 Issue 门禁**（spec-driven / mockup-driven）：

- **PRD 绑定** 含 **PRD 必读 7 项** + 壳层关系 + 覆盖用户故事 `US-n`
- **States 矩阵** 每态一行，**PRD 来源** 为可定位字符串
- `DESIGN.md` 就绪；多端时 `platforms.md` 就绪
- **验收标准** 分三类：功能 / UI 行为 / 设计 QA
- mockup 额外检查 `references/` 默认态 PNG
- 功能页（`page-id` ≠ `app-shell`）须依赖同端 app-shell issue

**功能 / headless Issue 门禁**：

- **PRD 绑定** 含 **PRD 必读 3 项** + Seam + 覆盖用户故事
- **验收标准** 每条为可观察行为，含 **PRD 依据**

移至 `ready-for-agent` 时，Agent 简报须从 issue 正文 **PRD 必读原样复制**「实现前必读」。

---

## 10 个 Skill 速查表


| Skill                            | 阶段  | 一句话                                                   | 产出物                                |
| -------------------------------- | --- | ----------------------------------------------------- | ---------------------------------- |
| `/hi-ai-coding`                  | 入门  | 零基础 AI Coding 认知引导：是什么、vs Vibe 与可控、工程常识、协作方式、工作法全流程导览 | 认知报告                               |
| `/setup-skills`                  | 基建  | 配置 Issue 跟踪器（GitHub / GitLab / 本地 md / 其他）、标签、领域文档布局  | `docs/agents/*`                    |
| `/grill-me`                      | 对齐  | 纯拷问，压力测试想法                                            | 对话共识（不写文件）                         |
| `/grill-with-docs`               | 对齐  | 拷问 + 实时写文档 + 定 UI 模式 + 品牌视觉规范                         | `CONTEXT.md` / ADR / `DESIGN.md`   |
| `/to-prd`                        | 规划  | 会话 → 先写 `docs/prd` 确认 → 发布 PRD Issue                  | PRD（含状态策略、页面清单、app-shell）          |
| `/to-issues`                     | 规划  | PRD → 垂直切片 Issues（不重新拆 UI 页）                          | 功能 Issue + Design Issue + UI Issue |
| `/triage`                        | 协作  | Issue 分拣、写 Agent 简报（含 PRD 必读）                         | 状态标签 + 评论                          |
| `/tdd`                           | 实现  | 红-绿-重构，预检 PRD 必读后逐条循环                                 | 代码 + 测试 + PR（UI 须过设计 QA）           |
| `/diagnose`                      | 排错  | 反馈回路 → 假设 → 探针 → 修复                                   | 回归测试                               |
| `/zoom-out`                      | 理解  | 拉高视角，画模块调用图                                           | 架构地图（对话）                           |
| `/improve-codebase-architecture` | 维护  | 找「加深模块」重构机会 + UI Token 合规检查                           | HTML 架构报告（临时目录）                    |


---

## 四个痛点 ↔ Skill 对应


| 痛点  | 现象           | 对应 Skill + 产物                                              |
| --- | ------------ | ---------------------------------------------------------- |
| 没听懂 | AI 做出来的不是你要的 | `/grill-me` · `/grill-with-docs`                           |
| 太啰嗦 | 对话和代码都冗长     | `CONTEXT.md` 统一术语 · PRD 绑定路由（Issue 不重复全文）                  |
| 跑不通 | 看起来对，一运行就挂   | `/tdd` · `/diagnose`                                       |
| 变泥球 | 越改越不敢动       | `/zoom-out` · `/to-prd` · `/improve-codebase-architecture` |


---

## 两条关键纪律

### 1. 垂直切片，不要水平切片

```
❌ 错误：先写 test1~5，再写 impl1~5
✅ 正确：test1→impl1 → test2→impl2 → …（每条路径端到端可演示）
```

### 2. UI 设计治理（非 headless）的分层

**设计输入（三类文件）**：

```
docs/design/DESIGN.md          ← 品牌视觉 SSOT（grill 写入，#D-global 验收关闭）
docs/design/platforms.md       ← 多端时：platform-id 清单 + 组件库映射
docs/design/references/*.png   ← mockup-driven 每页默认态设计稿
```

**页面规格 SSOT 在 PRD**，不在 Issue 正文重复：

```
PRD「状态策略」              ← 全局 loading / empty / error 约定
PRD「页面清单」              ← page-id · UI 设计描述 · 变体段 · DESIGN 复用
```

**Design Issue 分层**：

```
#D-global（验收关闭 DESIGN.md；多端时含 platforms.md）
    ↓
#D-xxx（仅 mockup-driven：每页一张默认态 PNG）
    ↓
app-shell UI Issue（各端整体框架页，功能页之前）
    ↓
功能 UI Issue（ready-for-agent 后才能 /tdd）
```

- **spec-driven**：不开 `#D-xxx`；布局 SSOT 在 PRD 页面清单「UI 设计描述」
- **headless**：不开任何 Design Issue
- API 切片可与 `#D-global` **并行**——后端不依赖设计稿

**Issue 正文关键字段**：


| 字段        | UI Issue              | 功能 Issue          |
| --------- | --------------------- | ----------------- |
| PRD 绑定    | 7 项 PRD 必读 + 壳层关系     | 3 项 PRD 必读 + Seam |
| States 矩阵 | 每态一行（PRD 来源 + 可观察预期）  | —                 |
| 验收标准      | 功能 / UI 行为 / 设计 QA 三类 | 每条含 PRD 依据        |


---

## 典型新功能路径（最短闭环）

```
/setup-skills（首次）
  → /grill-with-docs（对齐 + 写 CONTEXT/ADR/DESIGN.md + 定 UI 模式）
  → /to-prd（先 docs/prd 确认，再发布 PRD Issue）
  → /to-issues（以 PRD 页面清单为 SSOT 拆垂直切片 + Design Issues）
  → /triage（推到 ready-for-agent，写 Agent 简报含 PRD 必读）
  → 拉分支 → /tdd（预检 PRD 必读 → 红绿循环）→ push → PR → 合并
  → 重复下一个 Issue
```

出 Bug 时插入 `/diagnose`；看不懂旧代码用 `/zoom-out`；v1 跑通后用 `/improve-codebase-architecture` 做架构体检。