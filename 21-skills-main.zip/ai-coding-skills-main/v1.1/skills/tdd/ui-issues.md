# TDD 中的 UI Issue

当当前 issue 实现的是Web端、移动端、系统页或 H5/小程序 UI 时，在标准的 TDD 规划步骤**之前**，遵循以下门禁。

## 预检清单

- [ ] 阅读 issue 中引用的 `docs/design/` 相关章节（以 issue 列出为准）
- [ ] 阅读引用的 `references/` 文件
- [ ] issue 状态为 `ready-for-agent`（而非 `ready-for-human`）
- [ ] 禁止硬编码颜色/间距字面量；语义值见 `docs/design/tokens.md`；与仓库已有 token/theme/变量约定保持一致
- [ ] 遵循 `platforms.md` 中的组件映射 —— 禁止裸用 button 或 div 画表格
- [ ] 交互反馈、浮层、危险操作遵循 `patterns.md`（若 issue 引用）
- [ ] 导航、返回、Tab 选中态遵循 `navigation.md`（若 issue 引用）
- [ ] 文案遵循 `content.md`（若 issue 引用）
- [ ] 动效遵循 `motion.md`，并尊重 `accessibility.md` 中的 prefers-reduced-motion
- [ ] 多语言/RTL 遵循 `i18n.md`（若产品启用）
- [ ] 偏离 `references/` 的实现已按 `acceptance.md` § 例外流程 批准

## 需要实现的状态

每个列表页或表单页都必须覆盖 `docs/design/states.md` 中定义的状态，通常包括：

- 加载中（Loading）
- 空状态（Empty）
- 错误状态（Error）
- 禁用状态 / 提交守卫（Disabled / submit guard）

含上传的流程另实现 `states.md` § 上传（进行中、成功、失败、重试）。

## 验收标准


| 项          | 谁负责        | 说明                                                                                              |
| ---------- | ---------- | ----------------------------------------------------------------------------------------------- |
| 代码检查（lint） | CI / Agent | 见 `acceptance.md` § 代码侧验收                                                                       |
| 人工审查       | PR 评审者     | 见 `acceptance.md` § 设计 QA；对照 `page-templates`、`references/`、`states.md` 与 issue 引用的其他 design 章节 |


## GREEN 阶段之后

- 发现新的反模式：添加到 `docs/design/anti-patterns.md`
- 不要修改全局 token 定义 —— 改用 Design Issue

## PR 中的 UI 验收标准章节（用于 UI issue）

```markdown
## UI 输入（ready-for-agent 前已满足）
- [ ] page-templates.md §「___」章节已存在
- [ ] references/___
- [ ] states.md 覆盖此流程（含上传态，若适用）
- [ ] patterns.md 已覆盖此流程涉及的反馈/浮层/危险操作（若适用）
- [ ] navigation.md 已覆盖此流程的导航/返回/深链接（若适用）
- [ ] content.md 已覆盖此流程的文案规则（若适用）

## UI 验收标准
- [ ] 引用的 docs/design/ 章节：___
- [ ] 代码检查（lint）通过（见 acceptance.md § 代码侧验收）
- [ ] 人工审查（见 acceptance.md § 设计 QA）：
  - [ ] 匹配 page-templates §___
  - [ ] 与 references/___ 对齐（或已按 acceptance.md § 例外流程 批准偏离）
  - [ ] states 已覆盖（含上传态，若适用）
  - [ ] patterns / navigation / content / accessibility / motion / i18n 已按 issue 引用落实（删去不适用项）

## 设计参考
- 布局：docs/design/page-templates.md §___
- 视觉参考：docs/design/references/___
- 设计令牌：docs/design/tokens.md
- 组件：docs/design/components.md §___；docs/design/platforms.md §___
- 交互模式：docs/design/patterns.md §___（若适用）
- 导航：docs/design/navigation.md §___（若适用）
- 文案：docs/design/content.md §___（若适用）
- 状态：docs/design/states.md §___
- 无障碍：docs/design/accessibility.md §___（若适用）
- 动效：docs/design/motion.md §___（若适用）
- 国际化：docs/design/i18n.md §___（若适用）
- 验收：docs/design/acceptance.md § 设计 QA
```

