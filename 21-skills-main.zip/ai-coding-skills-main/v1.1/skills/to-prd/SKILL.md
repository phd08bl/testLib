---
name: to-prd
description: 将当前对话上下文转为 PRD 并发布到项目 Issue 跟踪器。当用户想从当前上下文创建 PRD 时使用。
---

本 skill 将当前会话上下文和代码库理解转化为 PRD。不要向用户提问 — 只需综合你已经了解的信息即可。

Issue 跟踪器与 triage 标签词汇已经提供给你了 — 如果没有，请先运行 `/setup-skills`。

## 流程

1. 若尚未探索，探索代码库，了解代码库的当前状态。在整个 PRD 中使用项目的领域术语表词汇，并尊重你所涉及领域内的任何 ADR。

2. 勾画出你将用于测试该功能的接缝（seams）。应优先使用现有接缝而非新建接缝。尽可能使用最高层级的接缝。如果需要新建接缝，请在你能达到的最高点提出它们。

与用户确认这些接缝是否符合他们的预期。

3. 使用下面的模板编写 PRD，然后将其发布到项目 Issue 跟踪器。应用 `ready-for-agent` triage 标签 — 无需额外的 triage。

<prd-template>

## 问题陈述

从用户视角出发，描述用户当前面临的问题。

## 解决方案

从用户视角出发，描述问题的解决方案。

## 用户故事

一个长篇幅的、带编号的用户故事列表。每个用户故事应采用以下格式：

1. 作为 <actor>，我想要 <feature>，以便 <benefit>

<user-story-example>
1. 作为移动银行客户，我想要查看我的账户余额，以便更明智地决定我的支出。
</user-story-example>

这个用户故事列表应该极其详尽，覆盖该功能的所有方面。如果存在多端（如 Web 端、APP端、小程序端等）分开列出。

## UI 与设计要求

当 PRD 涉及Web 端、移动端、系统页或 H5/小程序 UI 时，包含此章节。对于仅涉及 API 的 PRD，则省略。

**Design Issue 分层**（若 `docs/design/` 尚未就绪）：

- `#D-global` — 全局基线（tokens、platforms、components、patterns、navigation、content 等）
- `#D-templates` — `page-templates.md` 各 § 节与 `states.md`
- `#D-xxx` — 各核心页面的 `references/` PNG

**每个 UI 用户故事须注明：**

- 适用的 `page-templates.md` § 节
- 需要的 `references/`（系统页等无可视稿时，见 [DESIGN-ISSUES.md](../to-issues/DESIGN-ISSUES.md) 按页面类型的最小引用）
- 适用的 UI 状态：加载中 / 空状态 / 错误 / 禁用 / 上传态（若适用）
- 若适用：`patterns.md`（反馈/浮层）、`navigation.md`、`content.md`
- 验收：代码检查 + 人工审查（`acceptance.md`）

**PRD 末尾列出：**

- 需创建的 `#D-xxx` Design Issues（核心 UI 页面，Web端与移动端均包含）
- 尚未存在的 `docs/design/` 章节及对应待创建的 Design Issue 层级

## 实现决策

已做出的实现决策列表。可包括：

- 将要构建/修改的模块
- 这些模块中将修改的接口
- 来自开发者的技术澄清
- 架构决策
- 模式（schema）变更
- API 契约
- 具体的交互方式

**不要**包含具体的文件路径或代码片段。它们会很快过时。

## 测试决策

已做出的测试决策列表。包括：

- 什么构成一个好的测试的描述（只测试外部行为，不测试实现细节）
- 哪些模块将被测试
- 测试的先例（即代码库中已有的类似类型的测试）

## 范围外

描述此 PRD 范围之外的事项

## 补充说明

关于该功能的任何进一步说明。

</prd-template>
