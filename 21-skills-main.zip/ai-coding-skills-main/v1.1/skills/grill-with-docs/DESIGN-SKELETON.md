# 设计文档骨架

当 UI 设计治理启用后，惰性创建 `docs/design/`。仅在存在内容要写入时才创建文件 — 会话结束时包含章节标题的空骨架是可以接受的。

## `tokens.md`

```markdown
# 设计令牌

## 调色板
- primary, success, warning, error, info（若与 primary 区分）, neutral-*

## 品牌调性
- 主色方向、视觉气质

## Logo
- 用法、最小尺寸、留白

## 暗色模式 / 多主题
- 是否支持及令牌 doubling 策略

## 语义背景色
- page / surface / elevated / overlay

## 语义文本色
- primary / secondary / disabled / inverse / link

## 边框与分割线
- border-default / border-strong / divider

## 交互状态色
- hover / active / focus ring（各语义色对应态）

## 字体排版
- 字体族、字号 (xs/sm/base/lg/xl/2xl)、字重

## 字体层级
- h1–h6 或 display/title/body/caption 与字号/字重/行高对应表

## 文本间距
- 段落间距、列表项间距、标题与正文间距

## 间距
- 4 / 8 / 12 / 16 / 24 / 32

## 断点与容器
- sm / md / lg / xl 及容器最大宽度

## 栅格
- 列数（如 12 列）、页面 gutter

## 层级叠放
- Modal、Drawer、Dropdown、Tooltip 的 z-index

## 图标
- 图标库（如 Ant Design Icons / TDesign Icons）
- 尺寸阶梯：xs / sm / md / lg 与文本对齐

## 圆角、阴影
- （会话中决定）

## 图表色板
- 与 status 色区分的数据可视化专用色
```

## `components.md`

```markdown
# 组件

## 组件库选择
- Web端: (如 Ant Design)
- 移动端: (如 TDesign)

## 自定义包装规则
- 何时包装 vs 使用库默认（落到具体组件）

## Button
- variant：primary / secondary / ghost / danger / link
- size、icon-only、loading

## Input / Select / DatePicker
- size、error、clear、prefix / suffix

## Tag / Badge / Alert
- 语义色与使用场景

## Card / List item
- 内边距、标题区、操作区布局

## Empty / Skeleton
- 与 states.md、references/ 一致

## 图标用法
- 仅图标按钮与 accessibility.md aria-label 联动

## 数据可视化
- 图表类型与色板（见 tokens.md § 图表色板）
- 大数据量加载与降级展示

## 文件上传
- 拖拽、进度、失败重试、类型与大小限制 UI
- 图片预览与裁剪（若适用）

## 列表与表格
- 分页 vs 无限滚动（Web / 移动端差异）
- 排序、筛选、搜索 UI 模式（内联 / 抽屉 / 顶栏）
- 批量操作与行选择（若适用）
- 表格密度（紧凑 / 默认 / 宽松）→ 见 platforms.md 映射

## 表单控件
- 必填标识（* vs 文案「必填」）
- 校验时机：失焦 / 提交 / 实时
- 错误展示：字段下 inline vs 顶部汇总 vs Toast
- 只读 / 禁用 / 查看态 vs 编辑态
- 多步表单（若适用）：步骤条、上一步/下一步、草稿保存
```

## `page-templates.md`

```markdown
# 页面模板

## §admin-web
- 布局: 侧边栏 / 顶栏、列表页、表单页等
- 侧栏行为：固定 / 可折叠 / 窄屏隐藏
- 列表页：空态 / 错态 / 加载态 copy 与操作入口
- 仪表盘：布局与表格页关系
- （会话中决定）

## §mobile-customer
- TabBar、卡片流、安全区等
- 键盘顶起、横竖屏
- 列表：分页 vs 无限滚动（与 Web 差异）
- （会话中决定）

## §system
- 403 / 404 / 500 或统一错误页
- 会话过期 / 未登录：跳转与提示
- 会话超时：提示与续期 UI
- 登录 / 注册 / 找回密码（若产品包含）

## §privacy
- 敏感信息脱敏展示规则
```

## `patterns.md`

```markdown
# 交互模式

## 轻量反馈
- Toast / Message / Notification 选用规则（成功、失败、警告、进行中）

## 浮层选用
- Modal vs Drawer vs Popover 使用边界（确认、表单、详情、筛选）

## 危险操作
- 二次确认：按钮顺序、不可逆文案、默认焦点

## 提交与并发
- 按钮 loading、防重复提交、乐观更新是否允许

## 全局异常
- 网络离线、请求超时、5xx 的用户可见处理方式
```

## `navigation.md`

```markdown
# 导航

## 主导航
- 侧栏 / TabBar 项与层级对应关系

## 面包屑
- 是否使用及规则

## 返回行为
- 浏览器返回 vs 应用内返回 vs 关闭 Drawer

## 深链接与路由
- 路由与 Tab 选中态同步

## 功能 parity
- 仅 Web / 仅移动端 页面清单
```

## `content.md`

```markdown
# 文案

## 语气
- 正式 / 友好 / 中性及禁止用语

## 按钮动词
- 「保存」「提交」「确认删除」等统一表

## 空状态文案
- 说明 + 引导操作

## 错误文案
- 发生了什么 + 用户能做什么

## 格式
- 日期、数字、货币、单位展示格式

## 敏感信息
- 脱敏展示规则（见 page-templates.md §privacy）
```

## `motion.md`

```markdown
# 动效

## 时长与缓动
- fast / normal / slow 及缓动曲线

## 允许动效的场景
- 页面切换、展开折叠、微反馈

## 禁止动效的场景
- 与 accessibility.md prefers-reduced-motion 联动
```

## `i18n.md`

```markdown
# 国际化

## RTL
- 是否支持

## 文案膨胀
- 截断、换行规则

## locale 格式
- 日期、数字、货币与 content.md § 格式 一致
```

## `states.md`

```markdown
# UI 状态

## 列表页
- Loading、Empty、Error、禁用操作
- Empty / Error copy 结构与引导操作（见 page-templates）

## 表单页
- Loading、校验错误、提交禁用
- 校验时机与错误展示（见 components.md § 表单控件）

## 骨架屏
- （若适用）

## 上传
- 进行中、成功、失败、重试
```

## `platforms.md`

```markdown
# 平台

## 单一事实来源
- tokens.md vs platforms.md 重复项以哪份为准

## 共享语义（见 tokens.md）
- primary, success, warning, error, neutral-*
- spacing: 4/8/12/16/24/32
- font-size: xs/sm/base/lg/xl

## 组件语义映射
| 语义 | Web端 | 移动端 |
|----------|-------------|-------------------------|
| Primary button | Ant Design Button primary | t-button theme=primary |
| Secondary button | Ant Design Button default | t-button theme=default |
| Status tag | Tag color=processing/success | t-tag variant=light |
| Empty list | Empty + guidance text | t-empty + button |
| Toast / Message | message / notification | t-message / t-toast |
| Confirm dialog | Modal.confirm | t-dialog |
| Input | Input | t-input |
| Select | Select | t-picker / t-select |
| Modal / Drawer | Modal / Drawer | t-dialog / t-popup |
| Table | Table | t-list / 卡片列表 |
| （会话中扩展） | | |

## 分平台规则
- Web端: Ant Design 默认密度；表格优先布局；表格密度（紧凑/默认/宽松）
- 移动端: 安全区、TabBar 高度；键盘顶起、横竖屏；除非 ADR 批准否则不用自定义导航栏

## §h5-miniprogram
- 模板约定（若技术栈包含）
- 组件映射行（若适用）

## 参考资产
- Web端: references/admin-*.png
- 移动端: references/mobile-*.png（分开维护）
```

## `anti-patterns.md`

开始时为空，或包含一个简短的“禁止”清单；随着 PR 返工而逐渐增长。

## `accessibility.md`

```markdown
# 无障碍

## 基线
- 对比度、焦点顺序、仅图标控件上的 aria-label

## 键盘
- Tab 顺序、Skip link、Esc 关闭浮层

## 焦点管理
- Modal 焦点陷阱与关闭后焦点还原

## 表单与动态内容
- 错误关联：aria-describedby / aria-invalid
- Live region：动态 Toast、异步校验播报

## 动效与触控
- prefers-reduced-motion 降级策略
- 移动端最小点击区域（如 44×44）与间距
```

## `references/`

所有 UI 设计图（如页面视觉稿、品牌资产、插图等）统一放在 `docs/design/references/` 目录下。

- 页面相关设计图：按 Design Issue 编号整理（如 references/web-*.png、references/*mobile*-*.png）。
- 品牌相关资产：references/brand-*.png。
- 插图/空态图：references/illustrations-*.png。

如需补充页面，请由相应的 #D-xxx Design Issue 添加 PNG 文件到本目录。

## `acceptance.md`

```markdown
# 验收

## 核心页面清单
- 页面与 #D-xxx 编号对应

## 设计 QA
- 对照 references/ PNG 的检查项（布局、间距、状态、文案）

## 代码侧验收
- lint 设计令牌、Storybook、视觉回归是否纳入

## 例外流程
- 偏离 references 需 ADR 还是 Design Issue 批准
```

## 关于设计治理（design-governance）的 ADR

当以下三个条件均满足时记录：

1. 仓库包含需要视觉管控的 UI 页面
2. 采用了双轨 Design Issue 工作流

包含内容：双轨规则、分层推进（`#D-global` → `#D-templates` → `#D-xxx`）、分平台设计输入与统一验收标准（代码检查 + 人工审查）、例外批准流程（见 acceptance.md）。