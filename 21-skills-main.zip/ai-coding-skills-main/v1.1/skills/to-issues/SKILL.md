---
name: to-issues
description: 采用 tracer-bullet 垂直切片的方式，将一个计划、规范或 PRD 分解为项目 Issue 跟踪器中可独立领取的 issue。当用户希望将计划转化为 issue、创建实现工单或把工作拆解成多个 issue 时使用。
---

# 拆分为 Issue

使用垂直切片（tracer-bullet）将一个计划分解为可独立领取的 issue。

Issue 跟踪器和 triage 标签词汇表已经提供给你了 — 如果没有，请先运行 `/setup-skills`。

如果存在 `docs/design/`（或者计划中包含Web端或移动端 UI），阅读 [DESIGN-ISSUES.md](./DESIGN-ISSUES.md) ，并将 Design Issues 与功能切片一并拆分。

## 流程

### 1. 收集上下文

基于对话上下文中已有的信息开展工作。如果用户传递了一个 issue 引用（编号、URL 或文件路径）作为参数，请从 Issue 跟踪器中获取该 issue，并阅读其完整正文和评论。

### 2. 探索代码库

如果你尚未探索代码库，请现在进行，以了解代码的当前状态。Issue 标题和描述应使用项目的领域术语表词汇，并尊重你所涉及领域内的 ADR。

### 3. 起草垂直切片

将计划拆解为**tracer-bullet**式的 issue。每个 issue 都是一个细粒度的垂直切片，端到端地贯穿所有集成层，而不是单一层级的水平切片。

切片可以是“HITL”或“AFK”类型。HITL 切片需要人工交互，例如架构决策或设计评审。AFK 切片可以在无需人工交互的情况下实现并合并。在可能的情况下，优先选择 AFK 而非 HITL。

当 UI 设计治理启用时，同时起草 **Design Issues**（详见 [DESIGN-ISSUES.md](./DESIGN-ISSUES.md)）：

- `#D-global`（全局基线）→ `#D-templates`（页面/状态模板）→ 每个 UI 页面的 `#D-xxx`（`references/`）
- API/后端切片可与 `#D-global` 并行 —— 无设计依赖
- 如有 `#D-global`（全局基线）和 `#D-templates`（页面/状态模板）类型的 Design Issues，将它们的初始状态标记为 `ready-for-agent`
- 缺少 `references/` 的 UI 页面 → 将初始状态标记为 `ready-for-human`，而非 `ready-for-agent`
- 偏离 `references/` 的实现须按 `acceptance.md` § 例外流程 批准

<vertical-slice-rules>
- 每个切片都交付一条狭窄但完整的路径，贯穿每一个层级（schema、API、UI、测试）
- 一个完成的切片本身是可演示或可验证的
- 优先采用多个薄切片，而不是少数厚切片
- 不要拆分为“先设计所有页面，再实现所有页面”
</vertical-slice-rules>

### 4. 向用户提问

将提议的拆解方案以编号列表的形式呈现。对于每个切片，展示：

- **标题**：简短的描述性名称
- **类型**：HITL / AFK（Design Issues 使用 `design-input`）
- **依赖**：必须优先完成的其他切片（如有）
- **覆盖的用户故事**：此切片解决了哪些用户故事（如果源材料中包含用户故事）
- **设计依赖**（UI 切片）：需要哪些 `docs/design/` 章节和 Design Issues

向用户提问：

- 粒度是否合适？（太粗 / 太细）
- 依赖关系是否正确？
- 是否有任何切片需要合并或进一步拆分？
- HITL 和 AFK 的标记是否正确？
- （如果启用了 UI 设计治理）Design Issues 和 UI 依赖是否正确？

持续迭代，直到用户批准该拆解方案。

### 5. 将 issue 发布到 Issue 跟踪器

对于每个已批准的切片，向 Issue 跟踪器发布一个新 issue。

- **功能切片**：使用下面的 issue 正文模板发布。如果 AFK 就绪，则标记 `ready-for-agent`；否则标记正确的状态标签。
- **Design Issues**：使用 [DESIGN-ISSUES.md](./DESIGN-ISSUES.md) 中的模板发布。应用类别标签 `design-input`。

按依赖顺序发布 issue（被依赖的在前），这样你就可以在“依赖”字段中引用真实的 issue 标识符。

<issue-template>

## 父 Issue

对 Issue 跟踪器中父 issue 的引用（如果源材料是一个已有 issue，则包含此章节；否则省略）。

## 构建内容

对此垂直切片的简洁描述。描述端到端的行为，而不是逐层的实现细节。

避免使用具体的文件路径或代码片段 — 它们很快就会过时。

## UI 输入（当切片包含Web端、移动端、系统页或 H5/小程序 UI 时包含）

- [ ] page-templates.md §「___」章节已存在
- [ ] references/___
- [ ] states.md 覆盖此流程（含上传态，若适用）
- [ ] patterns.md 已覆盖此流程涉及的反馈/浮层/危险操作（若适用）
- [ ] navigation.md 已覆盖此流程的导航/返回/深链接（若适用）
- [ ] content.md 已覆盖此流程的文案规则（若适用）
- [ ] UI 验收标准：代码检查 + 人工审查（见 acceptance.md）

## 参考资料（UI 切片）

- 布局：docs/design/page-templates.md §___
- 视觉参考：docs/design/references/___
- 设计令牌：docs/design/tokens.md
- 组件：docs/design/components.md §___；docs/design/platforms.md §___
- 交互模式：docs/design/patterns.md §___（若适用）
- 导航：docs/design/navigation.md §___（若适用）
- 文案：docs/design/content.md §___（若适用）
- 状态：docs/design/states.md §___
- 无障碍：docs/design/accessibility.md §___（若适用）
- 动效：docs/design/motion.md §___（若适用）
- 国际化：docs/design/i18n.md §___（若适用）
- 验收：docs/design/acceptance.md § 设计 QA

按页面类型的最小引用见 [DESIGN-ISSUES.md](./DESIGN-ISSUES.md)。

## 验收标准

- [ ] 标准 1
- [ ] 标准 2
- [ ] 标准 3

## 阻塞项

- 对阻塞项的引用（如有）

如果没有阻塞项，则写“无 — 可立即开始”。

</issue-template>

**不要**关闭或修改任何父 issue。
