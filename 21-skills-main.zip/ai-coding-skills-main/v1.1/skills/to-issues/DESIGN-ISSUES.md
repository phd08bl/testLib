# Design Issues

当仓库包含 `docs/design/` 或设计治理 ADR 时，将 **Design Issues** 与功能垂直切片一并拆分。

## 三层


| Issue          | 产出物                                                                                                                                                                                   | 依赖             | 谁需要它              |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- | ----------------- |
| `#D-global`    | 全局设计基线：`tokens.md`、`platforms.md`、`components.md`、`patterns.md`、`navigation.md`、`content.md`、`motion.md`、`i18n.md`（若适用）、`accessibility.md`、`acceptance.md`（框架节）；及按技术栈建立的 token 代码（如有） | 无              | 所有 UI 工作          |
| `#D-templates` | 页面与状态模板：`page-templates.md`（§admin-web / §mobile-customer / §system / §privacy）、`states.md`                                                                                           | `#D-global`    | 所有 UI 工作          |
| `#D-xxx`       | 单页视觉输入：`references/` 中该页的 PNG（及关联的 `acceptance.md` § 核心页面清单 条目）                                                                                                                       | `#D-templates` | 该 UI 页面（Web端与移动端） |


`anti-patterns.md` 不由单独 Design Issue 创建——从 PR 返工中积累；`#D-global` 可留空或写首批禁止项。

## 依赖示例

```
#D-global              → 无（主分支上第一批）
#D-templates           → #D-global
#5 API 预约             → 可与 #D-global 并行（AFK，无 UI）
#D-mini-预约列表        → #D-templates
#8 小程序预约列表       → #5、#D-mini-预约列表
#D-admin-预约列表       → #D-templates
#9 管理后台预约列表     → #5、#D-admin-预约列表
```

## 规则

- **仅垂直切片** —— 不要拆分为「先设计所有页面，再实现所有页面」。
- 如有 `#D-global`（全局基线）和 `#D-templates`（页面/状态模板）类型的 Design Issues，将它们的初始状态标记为 `ready-for-agent`
- 缺少 `references/` 的 UI 页面 → 将初始状态标记为 `ready-for-human`，而非 `ready-for-agent`
- 功能 UI 的 PR 不得修改全局 token 定义（`docs/design/tokens.md` 或共享 token 代码）—— 应使用单独的 Design Issue。
- 偏离 `references/` 的实现须按 `acceptance.md` § 例外流程 批准。

## Design Issue 正文模板

```markdown
## 类型
`design-input` — 仅产出 `docs/design/`，不包含业务页面代码

## 层级
- [ ] `#D-global` / `#D-templates` / `#D-xxx`（删去不适用项）

## 产出物
- [ ] 要创建/更新的文件（列出 `docs/design/` 下的路径；若含代码层 token 则一并列出）

## 验收标准
- [ ] 文档已合并；代码层 token 在相关端可用（若 `#D-global` 包含代码产出）
- [ ]（对于 `#D-templates`）`page-templates.md` 各 § 节与 `states.md` 已闭合
- [ ]（对于 `#D-xxx`）`references/` 中存在参考文件；人工评审已通过；`acceptance.md` 核心页清单已更新

## 阻塞于
- （阻塞的 issue）

## 范围外
- 业务路由、API handler、数据库变更
```

## UI 实现 Issue

当切片包含管理后台、移动端、系统页或 H5/小程序 UI 时，在标准 issue 模板中增加以下内容。按页面类型勾选适用项。

```markdown
## UI 输入（标记 ready-for-agent 前必须满足）
- [ ] page-templates.md §「___」章节已存在
- [ ] references/___
- [ ] states.md 覆盖此流程（含上传态，若适用）
- [ ] patterns.md 已覆盖此流程涉及的反馈/浮层/危险操作（若适用）
- [ ] navigation.md 已覆盖此流程的导航/返回/深链接（若适用）
- [ ] content.md 已覆盖此流程的文案规则（若适用）
- [ ] UI 验收标准：代码检查 + 人工审查（见 acceptance.md）

## 参考资料
- 布局：docs/design/page-templates.md §___
- 视觉参考：docs/design/references/___
- 设计令牌：docs/design/tokens.md
- 组件：docs/design/components.md §___；docs/design/platforms.md §___
- 交互模式：docs/design/patterns.md §___（若适用）
- 导航：docs/design/navigation.md §___（若适用）
- 文案：docs/design/content.md §___（若适用）
- 状态：docs/design/states.md §___
- 无障碍：docs/design/accessibility.md §___（若适用）
- 动效：docs/design/motion.md §___（若适用）
- 国际化：docs/design/i18n.md §___（若适用）
- 验收：docs/design/acceptance.md § 设计 QA
```

### 按页面类型的最小引用


| 页面类型         | 通常必需的参考资料                                                                                                                                |
| ------------ | ---------------------------------------------------------------------------------------------------------------------------------------- |
| 管理后台列表/表单    | `page-templates §admin-web`、`references/`、`tokens.md`、`platforms.md`、`components.md`、`states.md`、`patterns.md`；`references/` 视产品而定       |
| 移动端页面        | `page-templates §mobile-customer`、`references/`、`tokens.md`、`platforms.md`、`components.md`、`states.md`、`patterns.md`；`references/` 视产品而定 |
| 系统页（403/登录等） | `page-templates §system`、`content.md`、`patterns.md`；`references/` 视产品而定                                                                  |
| 含敏感信息展示      | 另加 `page-templates §privacy`、`content.md § 敏感信息`                                                                                         |
| H5 / 小程序     | 另加 `platforms.md §h5-miniprogram`                                                                                                        |


