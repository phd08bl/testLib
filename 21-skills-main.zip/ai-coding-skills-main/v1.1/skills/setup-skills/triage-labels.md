# Triage 标签

Skills 以规范 triage 角色表述。本文件将这些角色映射到本仓库 issue 跟踪器实际使用的标签字符串。

## 状态角色


| skills 中的标签       | 我们跟踪器中的标签         | 含义                 |
| ----------------- | ----------------- | ------------------ |
| `needs-triage`    | `needs-triage`    | 维护者须评估此 issue      |
| `needs-info`      | `needs-info`      | 等待报告者更多信息          |
| `ready-for-agent` | `ready-for-agent` | 完全指定，无人值守 agent 可接 |
| `ready-for-human` | `ready-for-human` | 需人工实现              |
| `wontfix`         | `wontfix`         | 不处理                |


## 类别标签（可选）


| 标签             | 含义                                      |
| -------------- | --------------------------------------- |
| `design-input` | Design Issue — 产出 `docs/design/` 及 `#D-global` 建立的 token 代码（如有），无业务页面 |


类别标签可与恰好一个状态角色共存。

## UI 工作流映射

仓库有 `docs/design/`（启用 UI 设计治理）时：


| 情况                                 | 应用状态标签                |
| ---------------------------------- | --------------------- |
| UI issue：设计输入完成，agent 可 `/tdd`     | `ready-for-agent`     |
| UI issue：缺 `references/` 或设计评审待办 | `ready-for-human`     |
| 仅设计 issue                          | `design-input` + 适当状态 |


当 Skill 提到某个角色（如「应用 AFK-ready triage 标签」）时，请使用本表中对应的标签字符串。