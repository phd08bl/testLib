# 领域文档

工程 skills 探索代码库时应如何消费本仓库领域文档。

## 探索前先读这些

- 仓库根目录的 **`CONTEXT.md`**，或
- 若仓库根目录存在 **`CONTEXT-MAP.md`** — 它指向的各个上下文各自的 `CONTEXT.md` 文件。读与领域相关的每个。
- `docs/adr/**` — 读领域相关的 ADR。多上下文仓库还查 `src/<context>/docs/adr/` 的上下文范围决策。

如果仓库包含 `docs/design/`，在进行 UI 相关工作前，请先阅读其中引用的章节。Web端与移动端 UI 验收标准为代码检查 + 人工审查；在标记为 `ready-for-agent` 之前，必须先有 `references/`。

如果这些文件中的任何一个不存在，**静默继续**。不要指出它们缺失，也不要建议提前创建它们。生产者 skill（`/grill-with-docs`）会在术语或决策实际确定时，再按需创建它们。

## 文件结构

Single-context 仓库（大多数）：

```
/
├── CONTEXT.md
├── docs/
│   ├── adr/
│   │   ├── 0001-event-sourced-orders.md
│   │   └── 0002-postgres-for-write-model.md
│   └── design/                    ← 若启用设计治理
│       ├── tokens.md
│       ├── page-templates.md
│       └── references/
└── src/
```

Multi-context 仓库（根目录存在 `CONTEXT-MAP.md`）：

```
/
├── CONTEXT-MAP.md
├── docs/adr/                          ← 系统级决策
├── docs/design/                       ← 若启用设计治理，系统级设计
└── src/
    ├── ordering/
    │   ├── CONTEXT.md
    │   ├── docs/adr/                  ← ordering专属决策
    │   └── docs/design/               ← 若启用设计治理，ordering专属设计
    └── billing/
        ├── CONTEXT.md
        ├── docs/adr/                  ← billing专属决策
        └── docs/design/               ← 若启用设计治理，billing专属设计
```

## 使用词汇表词汇

当你的输出中提及某个领域概念时（无论是在 issue 标题、重构提案、假设还是测试名称中），请使用 `CONTEXT.md` 中定义的术语。不要偏离到术语表中明确避免使用的同义词上。

如果你需要的概念尚未出现在术语表中，这本身就是一个信号 —— 要么你正在创造项目不使用的语言（请重新考虑），要么确实存在一个缺口（请记录下来，供 `/grill-with-docs` 使用）。

## 标记 ADR 冲突

如果你的输出与现有 ADR 存在冲突，请明确指出来，而不是静默地覆盖：

> *与 ADR-0007（event-sourced orders）矛盾——但值得重开因为…*
