# UI 设计治理

面向每个仓库的 UI 设计治理配置的种子模板，在启用 UI 设计治理时，由 `/setup-skills` 写入。

## 何时适用

当仓库包含 `docs/design/` 或 存在关于 UI 设计治理的 ADR 时启用。如果两者都不存在，skill 将继续执行而不设置设计门禁。

## 文件结构

```
docs/design/
├── tokens.md              # 调色板、品牌、语义色、字体、间距、断点、栅格、图标、圆角/阴影
├── components.md          # 组件库、包装规则、核心组件约定、列表/表格、表单
├── page-templates.md      # §admin-web / §mobile-customer / §system / §privacy
├── navigation.md          # 主导航、面包屑、返回、深链接、功能 parity
├── content.md             # 语气、按钮动词、空态/错误文案、格式、敏感信息
├── patterns.md            # Toast/Modal 选用、危险操作、提交并发、全局异常
├── motion.md              # 时长缓动、允许/禁止动效（与 a11y reduced-motion 联动）
├── i18n.md                # RTL、文案膨胀、locale 格式
├── states.md              # 列表/表单/骨架屏/上传态
├── platforms.md           # 单一事实来源、组件语义映射、分平台规则、h5-miniprogram
├── accessibility.md       # 对比度、键盘、焦点、表单 a11y、触控
├── acceptance.md          # 核心页清单、设计 QA、代码验收、例外流程
├── anti-patterns.md       # 禁止使用的模式（从 PR 返工中积累）
└── references/            # UI 设计图与品牌/插图资产
    ├── admin-*.png
    ├── mobile-*.png
    ├── brand-*.png
    └── illustrations-*.png
```

## UI issue 的 Agent 规则

- 在编码前阅读 issue 引用的 `docs/design/` 章节及 `references/` 文件
- 对 `references/` 中的页面 UI 设计图，编码时需 1:1 复刻，确保像素级还原
- 禁止硬编码颜色/间距等字面量；语义值见 `tokens.md`；与仓库已有 token/theme/变量约定保持一致；尚无代码层约定时在 `#D-global` 建立，后续 issue 沿用
- 禁止裸用 button 或 div 画表格；遵循 `platforms.md` 中的组件映射
- 列表页和表单页需实现 `states.md` 中对应状态（Loading / Empty / Error / 禁用等）；含上传的流程另见 `states.md` § 上传
- 交互反馈、浮层选用、危险操作确认遵循 `patterns.md`
- 导航、返回、Tab 选中态遵循 `navigation.md`（若 issue 引用）
- 文案、按钮动词、错误/空态 copy 遵循 `content.md`（若 issue 引用）
- 动效遵循 `motion.md`，并尊重 `accessibility.md` 中的 prefers-reduced-motion
- 多语言/RTL 遵循 `i18n.md`（若产品启用）

## 双轨规则

- **Design Issues**（`design-input` 标签）负责维护 `docs/design/`，并在 `#D-global` 时按技术栈建立代码层 token（如有）— 不包含业务页面代码
- **UI 实现 Issues** 引用设计文档 — 不得在同一个 PR 中修改全局 token 定义（文档或共享代码）
- 偏离 `references/` 的实现须按 `acceptance.md` § 例外流程 批准

## 分平台默认规则


| 平台       | 设计输入                                                                                                      | 验收标准        | 页面级 Design Issue |
| -------- | --------------------------------------------------------------------------------------------------------- | ----------- | ---------------- |
| Web端     | `page-templates §admin-web` + `components.md` + `navigation.md`（若适用）+ `patterns.md` + `references/`       | 代码检查 + 人工审查 | 视产品而定            |
| 移动端      | `page-templates §mobile-customer` + `components.md` + `navigation.md`（若适用）+ `patterns.md` + `references/` | 代码检查 + 人工审查 | 视产品而定            |
| 系统页      | `page-templates §system` + `content.md` + `patterns.md`                                                   | 代码检查 + 人工审查 | 视产品而定            |
| H5 / 小程序 | `platforms.md §h5-miniprogram` + `page-templates` 对应章节                                                    | 代码检查 + 人工审查 | 视产品而定            |


**验收标准：**

- **代码检查（lint）** — 禁止硬编码字面量、组件映射等静态规则通过 CI / 本地 lint（详见 `acceptance.md` § 代码侧验收）
- **人工审查** — PR 评审者对照 `acceptance.md` § 设计 QA 核对 `page-templates`、`references/`、`states.md` 与整体实现质量

## UI 工作流标签映射


| 情况                    | 状态标签                     | 含义                |
| --------------------- | ------------------------ | ----------------- |
| 设计输入完成，Agent 可 `/tdd` | `ready-for-agent`        | 所需设计输入已就绪         |
| 缺 references，或设计评审待办  | `ready-for-human`        | 不要对 UI 页面开 `/tdd` |
| 仅设计 issue             | `design-input`（类别）+ 适当状态 | 仅产出文档             |


## 在针对 UI issue 执行 /tdd 之前

1. 阅读 issue 引用的 `docs/design/` 相关章节（含 `patterns.md`、`navigation.md`、`content.md` 等，以 issue 列出为准）
2. 阅读引用的 `references/` UI 设计图文件
3. 确认状态为 `ready-for-agent`，非 `ready-for-human`
4. 遵循上述 Agent 规则；例外偏离已按 `acceptance.md` 批准

