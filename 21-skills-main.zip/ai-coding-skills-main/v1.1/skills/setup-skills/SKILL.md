---
name: setup-skills
description: 在 AGENTS.md/CLAUDE.md 与 docs/agents/ 中设置「## Agent skills」块，使工程 skills 知晓本仓库的 issue 跟踪器（GitHub 或本地 markdown）、triage 标签词汇与领域文档布局。在首次使用 to-prd、to-issues、tdd、improve-codebase-architecture、triage、diagnose 或 zoom-out 前运行——或当这些 skills 似乎缺少 issue 跟踪器、triage 标签或领域文档上下文时。
---

# 设置 Skills

搭建工程 skills 假定的仓库配置：

- **Issue 跟踪器** — issue 所在处（默认 GitHub；开箱也支持本地 markdown）
- **Triage 标签** — 规范 triage 角色用的字符串
- **领域文档** — `CONTEXT.md`、`docs/adr/` 、`docs/design/` 位置及读取规则
- **设计治理**（可选项）— UI 设计门禁、UI issue 标签映射、分平台验收标准

这是 prompt 驱动的 skill，非确定性脚本。探索、呈现发现、与用户确认、然后写入。

## 流程

### 1. 探索

查看当前仓库以了解其初始状态。读取所有已存在的文件，不要做假设：

- `git remote -v` 和 `.git/config` — 这是一个 GitHub 仓库吗？是哪一个？
- 仓库根目录下的 `AGENTS.md` 和 `CLAUDE.md` — 这两个文件是否存在？若存在其内容是否已经有 `## Agent skills` 章节？
- 仓库根目录下的 `CONTEXT.md` 和 `CONTEXT-MAP.md` — 这两个文件是否存在？
- `docs/adr/` 以及所有 `src/*/docs/adr/` 目录是否存在？
- `docs/agents/` 目录是否存在？
- `docs/design/` 和关于设计治理（design-governance）的 ADR 是否存在？设计治理是否已启用？
- `.scratch/` — 若存在，则表明已在使用本地 Markdown Issue 跟踪规范

### 2. 呈现发现并询问

总结当前存在的内容以及缺失的内容。然后逐一引导用户完成各项决策 — 呈现一个部分，获取用户的答案，然后继续下一部分。不要一次性抛出所有部分。

假设用户不知道这些术语的含义。每个部分以一个简短的解释性说明开头（解释这是什么、为什么这些 skills 需要它、以及不同选择会带来什么变化）。然后展示选项和默认值。

**A — Issue 跟踪器**

> 说明：「issue 跟踪器」是本仓库 issue 所在处。`to-prd`、`triage`、`to-issues`等 skills 从中读写—须知调用 `gh issue create` 或写 `.scratch/` 下的 Markdown 文件，也可以是遵循你描述的其他方式。选你实际跟踪本仓库工作的地方。

默认姿态：这些 skills 为 GitHub 设计。若 `git remote` 指向 GitHub，提议 GitHub。若指向 GitLab（`gitlab.com` 或自托管），提议 GitLab。否则（或用户偏好）提供：

- **GitHub** — issue 在仓库 GitHub Issues（用 `gh` CLI）
- **GitLab** — issue 在仓库 GitLab Issues（用 `[glab](https://gitlab.com/gitlab-org/cli)` CLI）
- **Local markdown** — issue 为本仓库 `.scratch/<feature>/` 下文件（适合无 remote 仓库）
- **Other**（如 Jira、Linear 等）— 请用户简要描述实际的 issue 跟踪工作流，skill 将按原文记录为一段说明

**B — Triage 分拣标签**

> 说明：当 `triage` skill 处理新提交的 issue 时将其移经一个状态机—待评估、等待报告人反馈、可由AFK Agent 接手、待人工处理、或不予处理。为此，它需要应用与你**实际已配置**的字符串相匹配的标签（或 Issue 跟踪器中对应的等效标签）。若仓库已用不同标签名（如 `bug:triage` 而非 `needs-triage`），在此映射以便 skill 应用正确标签而非创建重复。

五个**状态**角色标签：

- `needs-triage` — 待评估
- `needs-info` — 待报告人反馈
- `ready-for-agent` — 完全指派给 Agent，无需人工参与
- `ready-for-human` — 待人工处理
- `wontfix` — 不处理

可选**类别**标签（有 UI 设计治理的仓库）：

- `design-input` — 仅 Design Issue；产出 `docs/design/` 及 `#D-global` 建立的 token 代码（如有），无业务页面代码

UI 实现 issue：设计输入完成时用 `**ready-for-agent`**；UI 页面缺 `references/` 或设计评审待办时用 `**ready-for-human**`。

默认：每角色字符串等于其名。问用户是否覆盖任何。若跟踪器无现有标签，默认即可。

**C — Domain 领域语言**

> 说明：部分 skills（`to-prd`、`diagnose`、`tdd`、`improve-codebase-architecture`）读 `CONTEXT.md` 学项目领域语言，`docs/adr/` 学过往架构决策。须知仓库是单一全局上下文还是多个以便查对地方。

确认布局：

- **Single-context** — 根目录下一个 `CONTEXT.md` + `docs/adr/`。大多数仓库如此。
- **Multi-context** — 根目录下的 `CONTEXT-MAP.md` 文件，指向各个上下文各自的 `CONTEXT.md` 文件。

**D — UI 设计治理（可选）**

> 说明：若仓库有 Web 端或移动端 UI 页面，skills 须知 Design Issues、`docs/design/`、分平台验收标准是否适用。纯 API 仓库跳过本节。

确认是否启用：

- **Enabled** — `docs/design/` + Design Issue 工作流（`#D-global` → `#D-templates` → 每个 UI 页面的 `#D-xxx`）。从 [design-governance.md](./design-governance.md) 写设计治理配置。
- **Disabled** — 无 UI 设计门禁；skills 仅用组件库默认。

默认：若已有 `docs/design/`，或计划含 Web 端或移动端 UI 页面，则启用。

### 3. 确认并编辑

向用户展示草稿：

- 将加到正在编辑的 `CLAUDE.md` / `AGENTS.md` 的 `## Agent skills` 块（见步骤 4 选择规则）
- `docs/agents/issue-tracker.md`、`docs/agents/triage-labels.md`、`docs/agents/domain.md` 内容
- 若启用 UI 设计治理：设计治理配置（来自 [design-governance.md](./design-governance.md)）

让用户写入前编辑。

### 4. 写入

**选要编辑的文件：**

- 若存在 `CLAUDE.md`，编辑它。
- 否则若存在 `AGENTS.md`，编辑它。
- 若都不存在，问用户创建哪个——不要替他们选。

已有 `CLAUDE.md` 时不要创建 `AGENTS.md`（反之亦然）——始终编辑已有的。

若所选文件已有 `## Agent skills` 块，就地更新内容而非追加重复。不要覆盖用户对其他章节的编辑。

块：

```markdown
## Agent skills

### Issue 跟踪器

[issue 跟踪方式一行摘要]。见 `docs/agents/issue-tracker.md`。

### Triage 标签

[标签词汇一行摘要]。见 `docs/agents/triage-labels.md`。

### Domain 领域文档

[布局一行摘要 — "single-context" 或 "multi-context"]。见 `docs/agents/domain.md`。

### UI 设计治理

[enabled 或 disabled — 一行]。（若 disabled 省略此子节）
```

然后用本 skill 文件夹种子模板写 docs 文件：

- [issue-tracker-github.md](./issue-tracker-github.md) — GitHub issue 跟踪器
- [issue-tracker-gitlab.md](./issue-tracker-gitlab.md) — GitLab issue 跟踪器
- [issue-tracker-local.md](./issue-tracker-local.md) — 本地 markdown issue 跟踪器
- [triage-labels.md](./triage-labels.md) — 标签映射
- [domain.md](./domain.md) — 领域文档消费规则 + 布局
- [design-governance.md](./design-governance.md) — UI 设计门禁（若 **UI 设计治理** 启用）

「其他」跟踪器，根据用户描述从零写 `docs/agents/issue-tracker.md`。

### 5. 完成

告诉用户设置完成，哪些工程 skills 现在将从这些文件读取。说明可稍后直接编辑 `docs/agents/*.md` — 仅当要换 Issue 跟踪器或从头重来时才需重跑本 skill。