---
name: zoom-out
description: 告诉 Agent 拉远视角，提供更广泛的上下文或更高层次的视角。当你不熟悉某段代码，或者需要理解它如何融入更大的整体架构时使用。
disable-model-invocation: true
---

我对这部分代码不太熟悉。请向上抽象一层。使用项目的领域术语表词汇，给我一张包含所有相关模块及调用者的地图。