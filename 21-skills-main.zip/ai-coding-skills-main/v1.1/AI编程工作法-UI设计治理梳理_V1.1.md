# AI 编程工作法 — UI 设计治理梳理

> 基于 `skills/` 目录下各 Skill 定义梳理而成，帮助理解整套工作法中 **UI 设计** 的实现方式。

## 核心思想（一句话）

UI 设计不是 `/tdd` 里的即兴发挥，而是一套 **「文档 → Design Issue → references/ PNG → UI Issue 门禁 → 1:1 复刻」** 的流水线。后端 API 切片可与 `#D-global` 并行推进；UI 页面必须等对应 `#D-xxx` 的设计输入就绪，才能进入 `ready-for-agent` 并执行 `/tdd`。

---

## 涉及 UI 的 Skill 分工


| 阶段  | Skill              | UI 设计职责                                                          |
| --- | ------------------ | ---------------------------------------------------------------- |
| 基建  | `/setup-skills`    | 可选启用 UI 设计治理，生成 `docs/design/` 骨架与标签映射                           |
| 对齐  | `/grill-with-docs` | 拷问顺序第三段：品牌色、组件库、核心页面 → 写入 `docs/design/`*                        |
| 探索  | `/prototype`       | UI 分支：同路由多变体对比布局（**不能替代**正式 `references/`）                       |
| 规划  | `/to-prd`          | PRD 含「UI 与设计要求」章节，列出 Design Issue 分层                             |
| 拆解  | `/to-issues`       | 拆三层 Design Issue + 功能 UI Issue，标注设计依赖                            |
| 分拣  | `/triage`          | UI 门禁：缺 `references/` → `ready-for-human`，齐了 → `ready-for-agent` |
| 实现  | `/tdd`             | 编码前读 `ui-issues.md` 预检清单，1:1 复刻 `references/`                    |


---

## 知识底座：`docs/design/` 文档体系

启用设计治理后，`/setup-skills` 会种子化一套设计文档树：

```
docs/design/
├── tokens.md          ← 颜色/字体/间距（禁止硬编码字面量）
├── components.md      ← 组件库约定
├── page-templates.md  ← §admin-web / §mobile-customer / §system / §privacy
├── states.md          ← Loading/Empty/Error/禁用/上传态
├── platforms.md       ← Web vs 移动端组件映射
├── patterns.md        ← Toast/Modal/危险操作
├── navigation.md      ← 导航/面包屑/深链接
├── content.md         ← 文案/按钮动词
├── motion.md          ← 动效
├── i18n.md            ← 国际化（若适用）
├── accessibility.md   ← 无障碍
├── acceptance.md      ← 设计 QA + 代码侧验收
├── anti-patterns.md   ← 禁止模式（从 PR 返工中积累）
└── references/        ← 页面 PNG 视觉稿（实现时的 1:1 依据）
```

`/grill-with-docs` 按 **三类文档路由** 写入：

- 业务规则 → `CONTEXT.md`
- 架构决策 → `docs/adr/*.md`
- **视觉/交互基线 → `docs/design/*`**

**拷问顺序（固定）**：领域规格 → 技术规格 → UI 规格。

---

## 双轨 Issue 体系（核心机制）

设计文档维护与页面代码实现 **分离**：

```mermaid
flowchart TB
    subgraph TRACK1["🎨 设计轨（design-input 标签）"]
        D1["#D-global<br/>tokens · components · platforms<br/>patterns · navigation · content<br/>accessibility · acceptance 框架"]
        D2["#D-templates<br/>page-templates.md 各 §<br/>states.md"]
        D3["#D-xxx<br/>references/ 单页 PNG<br/>acceptance 核心页清单"]
        D1 --> D2 --> D3
    end

    subgraph TRACK2["⚙️ 实现轨（功能 Issue）"]
        API["#5 API 预约<br/>可与 #D-global 并行"]
        UI1["#8 小程序预约列表<br/>依赖 #5 + #D-mini-预约列表"]
        UI2["#9 管理后台预约列表<br/>依赖 #5 + #D-admin-预约列表"]
    end

    D3 --> UI1
    D3 --> UI2
    D1 -.->|"并行，无 UI 依赖"| API

    style D1 fill:#d1e7dd
    style D2 fill:#d1e7dd
    style D3 fill:#d1e7dd
    style API fill:#cfe2ff
    style UI1 fill:#fff3cd
    style UI2 fill:#fff3cd
```



### 三层 Design Issue 速查


| Issue          | 产出物                                                                | 依赖             | 谁需要它     |
| -------------- | ------------------------------------------------------------------ | -------------- | -------- |
| `#D-global`    | 全局设计基线：`tokens.md`、`platforms.md`、`components.md` 等；及代码层 token（如有） | 无              | 所有 UI 工作 |
| `#D-templates` | 页面与状态模板：`page-templates.md` 各 §、`states.md`                        | `#D-global`    | 所有 UI 工作 |
| `#D-xxx`       | 单页视觉输入：`references/` 中该页的 PNG                                      | `#D-templates` | 该 UI 页面  |


### 关键纪律

- 功能 UI 的 PR **不得修改**全局 token 定义 → 须单独开 Design Issue
- 缺 `references/` 的页面 → 初始状态 `ready-for-human`，**禁止** `/tdd`
- **垂直切片**：不要「先设计全部页面，再实现全部页面」
- API/后端切片可与 `#D-global` **并行** —— 无设计依赖

---

## UI 设计全流程图（从想法到代码）

```mermaid
flowchart TB
    START(["新功能 / 新页面想法"])

    subgraph P0["阶段 0：基建（每仓一次）"]
        SETUP["/setup-skills"]
        SETUP -->|"UI 项目选 Enabled"| DOCS["生成 docs/design/ 骨架<br/>+ design-input 标签<br/>+ design-governance 配置"]
    end

    subgraph P1["阶段 1：需求对齐"]
        GRILL["/grill-with-docs"]
        GRILL -->|"领域 → 技术 → UI 顺序"| Q1["品牌色 / 组件库 / 核心页面"]
        Q1 --> DESIGN_DOC["惰性写入 docs/design/*<br/>（DESIGN-SKELETON.md）"]

        UNCERTAIN{"布局/信息架构<br/>还不确定？"}
        GRILL --> UNCERTAIN
        UNCERTAIN -->|"是"| PROTO["/prototype UI 分支<br/>同路由 3 个结构变体<br/>?variant=A/B/C 切换"]
        PROTO -->|"验证结论写回"| DESIGN_DOC
        UNCERTAIN -->|"否"| DESIGN_DOC
    end

    subgraph P2["阶段 2：规划拆解"]
        PRD["/to-prd<br/>含 UI 与设计要求章节"]
        ISSUES["/to-issues"]
        PRD --> ISSUES
        ISSUES --> D_GLOBAL["#D-global Issue"]
        ISSUES --> D_TEMPL["#D-templates Issue"]
        ISSUES --> D_PAGE["#D-xxx Issues<br/>产出 references/*.png"]
        ISSUES --> FUNC_UI["功能 UI Issues<br/>附 UI 输入清单"]
    end

    subgraph P3["阶段 3：门禁与实现"]
        TRIAGE["/triage"]
        CHECK{"UI 输入齐全？<br/>references/ 存在？"}
        TRIAGE --> CHECK
        CHECK -->|"缺设计稿/待评审"| HUMAN["ready-for-human<br/>❌ 禁止 /tdd"]
        CHECK -->|"设计输入就绪"| READY["ready-for-agent<br/>Agent 简报含 UI 输入章节"]
        READY --> TDD["/tdd"]
        TDD --> PRECHECK["ui-issues.md 预检<br/>读 docs/design/ + references/"]
        PRECHECK --> CODE["红→绿→重构<br/>1:1 复刻 references/<br/>实现 states.md 各状态<br/>禁止硬编码 token"]
        CODE --> PR["PR 含 UI 验收标准"]
        PR --> REVIEW["代码检查 lint<br/>+ 人工设计 QA"]
    end

    START --> SETUP
    DOCS --> GRILL
    DESIGN_DOC --> PRD
    D_GLOBAL --> D_TEMPL --> D_PAGE
    D_PAGE --> FUNC_UI
    FUNC_UI --> TRIAGE
    REVIEW --> MERGE(["合并 main"])

    style PROTO fill:#fff3cd
    style HUMAN fill:#f8d7da
    style READY fill:#d4edda
    style DESIGN_DOC fill:#e2e3e5
    style D_GLOBAL fill:#d1e7dd
    style D_TEMPL fill:#d1e7dd
    style D_PAGE fill:#d1e7dd
```



---

## 三个关键「闸门」

```mermaid
flowchart LR
    subgraph GATE1["闸门 1：文档路由"]
        Q["每个 UI 决策"]
        Q -->|"颜色/组件/布局?"| DES["docs/design/*"]
        Q -->|"业务规则?"| CTX["CONTEXT.md"]
        Q -->|"架构选型?"| ADR["docs/adr/*"]
    end

    subgraph GATE2["闸门 2：Issue 状态"]
        S1["needs_triage"]
        S1 -->|"references/ 缺失"| S2["ready-for-human"]
        S1 -->|"UI 输入 checklist 全绿"| S3["ready-for-agent"]
        S2 -->|"人工补齐 PNG"| S3
    end

    subgraph GATE3["闸门 3：TDD 预检"]
        T1["/tdd 启动前"]
        T1 --> T2["读 references/ PNG"]
        T1 --> T3["确认 ready-for-agent"]
        T1 --> T4["覆盖 states.md 状态"]
        T2 & T3 & T4 --> T5["才开始写测试/代码"]
    end
```



---

## Triage 状态机（UI 相关）

```mermaid
stateDiagram-v2
    [*] --> needs_triage: 新 Issue 进入

    needs_triage --> needs_info: 信息不足
    needs_triage --> ready_for_agent: 规范完整，设计输入就绪
    needs_triage --> ready_for_human: 缺 references/ 或设计评审待办
    needs_triage --> wontfix: 不予处理

    needs_info --> needs_triage: 报告人回复后

    ready_for_agent --> [*]: /tdd 实现
    ready_for_human --> ready_for_agent: 人工补齐设计稿后
    wontfix --> [*]

    note right of ready_for_agent
        UI Issue：设计资料已齐
        类别标签：design-input（仅设计 Issue）
    end note
```



### UI 工作流标签映射


| 情况                    | 状态标签                     | 含义                 |
| --------------------- | ------------------------ | ------------------ |
| 设计输入完成，Agent 可 `/tdd` | `ready-for-agent`        | 所需设计输入已就绪          |
| 缺 references，或设计评审待办  | `ready-for-human`        | 不要对 UI 页面开 `/tdd`  |
| 仅设计 issue             | `design-input`（类别）+ 适当状态 | 仅产出 `docs/design/` |


---

## UI 实现 Issue 的输入清单

标记 `ready-for-agent` 前必须满足：

- [ ] `page-templates.md` 对应 § 节已存在
- [ ] `references/` 中该页 PNG 已就绪
- [ ] `states.md` 覆盖此流程（含上传态，若适用）
- [ ] `patterns.md` 已覆盖反馈/浮层/危险操作（若适用）
- [ ] `navigation.md` 已覆盖导航/返回/深链接（若适用）
- [ ] `content.md` 已覆盖文案规则（若适用）
- [ ] UI 验收标准：代码检查 + 人工审查（见 `acceptance.md`）

### 按页面类型的最小引用


| 页面类型         | 通常必需的参考资料                                                                                                            |
| ------------ | -------------------------------------------------------------------------------------------------------------------- |
| 管理后台列表/表单    | `page-templates §admin-web`、`references/`、`tokens.md`、`platforms.md`、`components.md`、`states.md`、`patterns.md`       |
| 移动端页面        | `page-templates §mobile-customer`、`references/`、`tokens.md`、`platforms.md`、`components.md`、`states.md`、`patterns.md` |
| 系统页（403/登录等） | `page-templates §system`、`content.md`、`patterns.md`                                                                  |
| 含敏感信息展示      | 另加 `page-templates §privacy`、`content.md § 敏感信息`                                                                     |
| H5 / 小程序     | 另加 `platforms.md §h5-miniprogram`                                                                                    |


---

## `/tdd` 中的 Agent 规则（UI Issue）

编码前须完成 `skills/tdd/ui-issues.md` 预检清单：

1. 阅读 issue 引用的 `docs/design/` 章节及 `references/` 文件
2. 确认状态为 `ready-for-agent`，非 `ready-for-human`
3. 对 `references/` 中的页面 UI 设计图，编码时 **1:1 复刻**，确保像素级还原
4. **禁止**硬编码颜色/间距等字面量；语义值见 `tokens.md`
5. **禁止**裸用 button 或 div 画表格；遵循 `platforms.md` 中的组件映射
6. 列表页和表单页须实现 `states.md` 中对应状态（Loading / Empty / Error / 禁用等）
7. 交互反馈、浮层、危险操作遵循 `patterns.md`
8. 偏离 `references/` 的实现须按 `acceptance.md` § 例外流程 批准
9. **不得**在同一个 PR 中修改全局 token 定义 —— 改用 Design Issue

### 验收标准


| 项          | 谁负责        | 说明                                                                    |
| ---------- | ---------- | --------------------------------------------------------------------- |
| 代码检查（lint） | CI / Agent | 见 `acceptance.md` § 代码侧验收                                             |
| 人工审查       | PR 评审者     | 对照 `page-templates`、`references/`、`states.md` 与 issue 引用的其他 design 章节 |


---

## 相关 Skill 源文件索引


| 主题              | 路径                                                      |
| --------------- | ------------------------------------------------------- |
| 设计治理配置          | `skills/setup-skills/design-governance.md`              |
| 设计文档骨架          | `skills/grill-with-docs/DESIGN-SKELETON.md`             |
| Design Issue 模板 | `skills/to-issues/DESIGN-ISSUES.md`                     |
| UI 原型           | `skills/prototype/UI.md`                                |
| TDD UI 门禁       | `skills/tdd/ui-issues.md`                               |
| Triage UI 规则    | `skills/triage/SKILL.md`、`skills/triage/AGENT-BRIEF.md` |


