# AI 编程工作法 — Skills 全景图

> 基于 `skills/` 目录下 11 个 Skill 梳理而成，帮助快速理解整套 AI 编程协作工作法。

## 核心思想（一句话）

把 AI 编程拆成**可组合的小步骤**，每步都有**可检查产物**；用 **Issue 跟踪器** 做工作流中枢，用 **垂直切片（tracer-bullet）** 贯穿 schema → API → UI → 测试，避免「先写完全部测试/设计再实现」的水平切片陷阱。

---

## 总览图：全流程 Skill 地图

```mermaid
flowchart TB
    subgraph P0["🏗️ 阶段 0：工程基建（每仓一次）"]
        SETUP["/setup-skills"]
        SETUP --> AGENTS["AGENTS.md / CLAUDE.md"]
        SETUP --> DOCS_AGENTS["docs/agents/<br/>issue-tracker · triage-labels · domain"]
    end

    subgraph P1["💬 阶段 1：需求对齐"]
        IDEA["想法 / Bug / 功能请求"]
        GRILL_ME["/grill-me<br/>纯拷问，不写文档"]
        GRILL_DOCS["/grill-with-docs<br/>拷问 + 同步写文档"]
        PROTO["/prototype<br/>可丢弃的探索代码"]
        IDEA --> GRILL_ME
        IDEA --> GRILL_DOCS
        GRILL_DOCS --> CTX["CONTEXT.md<br/>领域术语表"]
        GRILL_DOCS --> ADR["docs/adr/<br/>架构决策记录"]
        GRILL_DOCS --> DESIGN["docs/design/<br/>UI 设计治理"]
        GRILL_ME -.->|"想清楚后再沉淀"| GRILL_DOCS
        GRILL_DOCS -.->|"逻辑/UI 不确定"| PROTO
        PROTO -.->|"验证结论写回"| CTX
        PROTO -.->|"验证结论写回"| ADR
        PROTO -.->|"验证结论写回"| DESIGN
    end

    subgraph P2["📋 阶段 2：规划与拆解"]
        TOPRD["/to-prd"]
        TOISS["/to-issues"]
        PRD["PRD Issue"]
        SLICES["垂直切片 Issues<br/>AFK / HITL"]
        D_ISSUES["Design Issues<br/>#D-global → #D-templates → #D-xxx"]
        GRILL_DOCS --> TOPRD
        TOPRD --> PRD
        PRD --> TOISS
        TOISS --> SLICES
        TOISS --> D_ISSUES
    end

    subgraph P3["⚙️ 阶段 3：分拣与实现"]
        TRIAGE["/triage<br/>Issue 状态机"]
        READY["ready-for-agent"]
        BRANCH["拉分支 issue/N-xxx"]
        TDD["/tdd<br/>红→绿→重构"]
        PR["PR + CI"]
        MERGE["合并 main"]
        SLICES --> TRIAGE
        D_ISSUES --> TRIAGE
        TRIAGE --> READY
        READY --> BRANCH
        BRANCH --> TDD
        TDD --> PR
        PR --> MERGE
        MERGE -.->|"下一个 Issue"| TRIAGE
    end

    subgraph P4["🔧 横切能力（随时可用）"]
        DIAG["/diagnose<br/>复现→假设→探针→修复"]
        ZOOM["/zoom-out<br/>拉高视角看代码"]
        ARCH["/improve-codebase-architecture<br/>加深模块重构"]
    end

    P0 --> P1
    P1 --> P2
    P2 --> P3
    TDD -.->|"出 Bug"| DIAG
    DIAG -.->|"架构根因"| ARCH
    TDD -.->|"看不懂代码"| ZOOM
    MERGE -.->|"v1 后维护"| ARCH

    style SETUP fill:#e8f4fd
    style GRILL_DOCS fill:#fff3cd
    style TDD fill:#d4edda
    style TRIAGE fill:#f8d7da
    style CTX fill:#e2e3e5
    style ADR fill:#e2e3e5
    style DESIGN fill:#e2e3e5
```



---

## 三类文档的分工（`grill-with-docs` 的路由规则）

这是整套工作法的**知识底座**——不同决策写进不同文件，避免 `CONTEXT.md` 变成大杂烩：

```mermaid
flowchart LR
    Q["每个决策问自己"]
    Q --> Q1{"业务含义<br/>状态/角色/规则?"}
    Q --> Q2{"难以逆转的<br/>技术/架构选择?"}
    Q --> Q3{"视觉/交互<br/>页面基线?"}

    Q1 -->|是| CTX["CONTEXT.md<br/>纯词汇表，无实现细节"]
    Q2 -->|是| ADR["docs/adr/*.md<br/>ADR 格式"]
    Q3 -->|是| DES["docs/design/*<br/>tokens · components · references"]

    style CTX fill:#cfe2ff
    style ADR fill:#fff3cd
    style DES fill:#d1e7dd
```



**拷问顺序（固定）**：领域规格 → 技术规格 → UI 规格。

---

## Triage 状态机 + Issue 类型

Issue 跟踪器是整套流程的**中枢**；`/triage` 负责把 issue 推到正确状态：

```mermaid
stateDiagram-v2
    [*] --> needs_triage: 新 Issue 进入

    needs_triage --> needs_info: 信息不足
    needs_triage --> ready_for_agent: 规范完整，AFK 可接
    needs_triage --> ready_for_human: 需人工（设计稿缺失等）
    needs_triage --> wontfix: 不予处理

    needs_info --> needs_triage: 报告人回复后

    ready_for_agent --> [*]: /tdd 实现
    ready_for_human --> ready_for_agent: 人工补齐后
    wontfix --> [*]

    note right of ready_for_agent
        类别标签：
        bug / enhancement / design-input
        每个 Issue 恰好 1 类别 + 1 状态
    end note
```



---

## 11 个 Skill 速查表


| Skill                            | 阶段  | 一句话                    | 产出物                         |
| -------------------------------- | --- | ---------------------- | --------------------------- |
| `/setup-skills`                  | 基建  | 配置 Issue 跟踪器、标签、领域文档布局 | `docs/agents/*`             |
| `/grill-me`                      | 对齐  | 纯拷问，压力测试想法             | 对话共识（不写文件）                  |
| `/grill-with-docs`               | 对齐  | 拷问 + 实时写文档             | `CONTEXT.md` / ADR / design |
| `/prototype`                     | 探索  | 可丢弃的原型（逻辑终端 / UI 变体）   | 验证结论 → 写回文档                 |
| `/to-prd`                        | 规划  | 会话 → PRD               | PRD Issue                   |
| `/to-issues`                     | 规划  | PRD → 垂直切片 Issues      | 功能 Issue + Design Issue     |
| `/triage`                        | 协作  | Issue 分拣、写 Agent 简报    | 状态标签 + 评论                   |
| `/tdd`                           | 实现  | 红-绿-重构，一次一个测试          | 代码 + 测试 + PR                |
| `/diagnose`                      | 排错  | 建立反馈回路 → 假设 → 修复       | 回归测试                        |
| `/zoom-out`                      | 理解  | 拉高视角，画模块调用图            | 架构地图（对话）                    |
| `/improve-codebase-architecture` | 维护  | 找「加深模块」重构机会            | HTML 架构报告                   |


---

## 四个痛点 ↔ Skill 对应


| 痛点  | 现象           | 对应 Skill + 产物                                              |
| --- | ------------ | ---------------------------------------------------------- |
| 没听懂 | AI 做出来的不是你要的 | `/grill-me` · `/grill-with-docs`                           |
| 太啰嗦 | 对话和代码都冗长     | `CONTEXT.md` 统一术语                                          |
| 跑不通 | 看起来对，一运行就挂   | `/tdd` · `/diagnose`                                       |
| 变泥球 | 越改越不敢动       | `/zoom-out` · `/to-prd` · `/improve-codebase-architecture` |


---

## 两条关键纪律

### 1. 垂直切片，不要水平切片

```
❌ 错误：先写 test1~5，再写 impl1~5
✅ 正确：test1→impl1 → test2→impl2 → …（每条路径端到端可演示）
```

### 2. UI 设计治理（若启用）的三层 Design Issue

```
#D-global（tokens/组件基线）
    ↓
#D-templates（页面模板 + 状态）
    ↓
#D-xxx（单页 references/ PNG）
    ↓
功能 UI Issue（ready-for-agent 后才能 /tdd）
```

API 切片可与 `#D-global` **并行**——后端不依赖设计稿。

---

## 典型新功能路径（最短闭环）

```
/setup-skills（首次）
  → /grill-with-docs（对齐 + 写 CONTEXT/ADR/design）
  → /to-prd（出 PRD）
  → /to-issues（拆垂直切片）
  → /triage（推到 ready-for-agent）
  → 拉分支 → /tdd → push → PR → 合并
  → 重复下一个 Issue
```

出 Bug 时插入 `/diagnose`；看不懂旧代码用 `/zoom-out`；v1 跑通后用 `/improve-codebase-architecture` 做架构体检。